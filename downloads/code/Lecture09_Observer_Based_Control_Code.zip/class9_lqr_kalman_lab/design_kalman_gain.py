import numpy as np
from scipy.linalg import solve_discrete_are

# ============================================================
# Steady-state Kalman observer gain design for RIP
# Students tune Qn and Rn, then copy K to .ino.
# ============================================================

Ad = np.array([
    [1.00000000, 0.00486127, -0.00061123, 0.00000487],
    [0.00000000, 0.94505030, -0.24196125, 0.00172377],
    [0.00000000, 0.00020708, 1.00211620, 0.00498311],
    [0.00000000, 0.08197315, 0.84220195, 0.99398863],
], dtype=float)

C = np.array([
    [1.0, 0.0, 0.0, 0.0],
    [0.0, 0.0, 1.0, 0.0],
], dtype=float)

# TODO: tune these values.
# Qn: process noise covariance, larger means less trust in model.
# Rn: measurement noise covariance, larger means less trust in sensors.
Qn = np.diag([1e-6, 1e-3, 1e-6, 1e-3])
Rn = np.diag([1e-5, 1e-5])

Pi = solve_discrete_are(Ad.T, C.T, Qn, Rn)
K = Pi @ C.T @ np.linalg.inv(C @ Pi @ C.T + Rn)

print("Qn =")
print(Qn)
print("\nRn =")
print(Rn)
print("\nSteady-state Kalman gain K =")
print(K)
print("\nEigenvalues of (I-KC)Ad:")
print(np.linalg.eigvals((np.eye(4) - K @ C) @ Ad))

print("\nCopy to firmware:")
print("static const float K_KALMAN[4][2] = {")
for i in range(4):
    print("  {" + ", ".join(f"{K[i,j]:.8f}f" for j in range(2)) + "},")
print("};")
