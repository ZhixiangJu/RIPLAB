Class 9 observer-based RIP control lab

Important:
1. These firmware files remove the low-pass finite-difference velocity estimate from the controller state.
2. The controller state is now the observer estimate xhat = [theta_hat, theta_dot_hat, alpha_hat, alpha_dot_hat]^T.
3. Observer gain matrices are intentionally left as student parameters.
4. The firmware will refuse GO until OBSERVER_PARAMS_FILLED is set to true.
5. There is no DQN and no automatic swing-up. Hold the pendulum close to upright by hand, then press Enter in the Python terminal.

Workflow:
1. Calibrate POT_ZERO.
2. Compute LQR gain or use the current controller parameters.
3. Design observer gain using the provided design script.
4. Copy the gain matrix into the .ino file.
5. Set OBSERVER_PARAMS_FILLED = true.
6. Upload firmware.
7. Run the Python script and press Enter to send GO.
8. Compare CSV and plots.
