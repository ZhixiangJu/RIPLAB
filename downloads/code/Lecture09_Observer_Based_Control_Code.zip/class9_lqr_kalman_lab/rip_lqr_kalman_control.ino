#include <Arduino.h>
#include <math.h>

static const int PIN_POT   = A0;
static const int PIN_ENC_A = 2;
static const int PIN_ENC_B = 3;
static const int PIN_IN1  = 4;
static const int PIN_IN2  = 5;
static const int PIN_STBY = 7;
static const int PIN_PWM  = 10;

static const uint32_t BAUD = 921600;
static const uint32_t CTRL_HZ = 200;
static const uint32_t DT_US = 1000000UL / CTRL_HZ;
static const float DT_CTRL = 1.0f / (float)CTRL_HZ;

static const float PI_F = 3.14159265358979323846f;
static const int32_t POT_MOD = 4096;
static const float THETA_SIGN = +1.0f;
static const float THETA_CAL_ONE_TURN_MEAS_RAD = 6.503f;
static const float THETA_SCALE_NOMINAL = THETA_SIGN * (PI_F / 520.0f);
static const float THETA_SCALE = THETA_SCALE_NOMINAL * ((2.0f * PI_F) / THETA_CAL_ONE_TURN_MEAS_RAD);

static volatile int32_t POT_ZERO = 3132;
static volatile int32_t POT_DOWN_RAW = 1036;
static const bool POT_CW_DECREASES = true;
static volatile int32_t ENC_ZERO = 10000;
static volatile int32_t g_enc = 10000;

// Exact ZOH-discretized model at Ts = 0.005 s.
static const float Ad[4][4] = {
  {1.00000000f, 0.00486127f, -0.00061123f, 0.00000487f},
  {0.00000000f, 0.94505030f, -0.24196125f, 0.00172377f},
  {0.00000000f, 0.00020708f, 1.00211620f, 0.00498311f},
  {0.00000000f, 0.08197315f, 0.84220195f, 0.99398863f}
};
static const float Bd[4] = {0.00001002f, 0.00397030f, -0.00001496f, -0.00592283f};

// Students must fill observer parameters and set this to true.
static const bool OBSERVER_PARAMS_FILLED = false;

static const float MOTOR_SIGN = +1.0f;
static const int PWM_MAX = 180;
static const float START_ALPHA_MAX_RAD = 25.0f * PI_F / 180.0f;
static const float FALLEN_ALPHA_RAD = 35.0f * PI_F / 180.0f;

static bool g_armed = false;
static bool g_fallen = false;
static uint32_t g_step = 0;
static int g_last_pwm = 0;
static float g_xhat[4] = {0,0,0,0};

static inline int32_t mod4096(int32_t x) { x %= POT_MOD; if (x < 0) x += POT_MOD; return x; }
static inline int32_t cwDistCounts(int32_t ref, int32_t x) {
  ref = mod4096(ref); x = mod4096(x);
  if (POT_CW_DECREASES) return mod4096(ref - x); else return mod4096(x - ref);
}
static inline float alphaFromPotRawBranchCutAtDown(int32_t pot_raw) {
  const int32_t up = mod4096(POT_ZERO), dn = mod4096(POT_DOWN_RAW), x = mod4096(pot_raw);
  int32_t cw_to_down = cwDistCounts(up, dn);
  if (cw_to_down <= 0 || cw_to_down >= POT_MOD) return 0.0f;
  int32_t cw_to_x = cwDistCounts(up, x);
  if (cw_to_x <= cw_to_down) return PI_F * ((float)cw_to_x / (float)cw_to_down);
  int32_t rem = POT_MOD - cw_to_down;
  if (rem <= 0) return 0.0f;
  return -PI_F * ((float)(POT_MOD - cw_to_x) / (float)rem);
}
static inline int clampInt(int v, int lo, int hi) { if (v < lo) return lo; if (v > hi) return hi; return v; }

void isr_enc_a() { bool A=digitalRead(PIN_ENC_A), B=digitalRead(PIN_ENC_B); if(A) g_enc += (B?1:-1); else g_enc += (B?-1:1); }
void isr_enc_b() { bool A=digitalRead(PIN_ENC_A), B=digitalRead(PIN_ENC_B); if(B) g_enc += (A?-1:1); else g_enc += (A?1:-1); }

void motorWritePWM(int pwm) {
  pwm = clampInt(pwm, -PWM_MAX, PWM_MAX);
  if (pwm == 0) { analogWrite(PIN_PWM,0); digitalWrite(PIN_IN1,LOW); digitalWrite(PIN_IN2,LOW); digitalWrite(PIN_STBY,LOW); return; }
  digitalWrite(PIN_STBY,HIGH);
  if (pwm > 0) { digitalWrite(PIN_IN1,HIGH); digitalWrite(PIN_IN2,LOW); analogWrite(PIN_PWM,pwm); }
  else { digitalWrite(PIN_IN1,LOW); digitalWrite(PIN_IN2,HIGH); analogWrite(PIN_PWM,-pwm); }
}
void stopAndDisarm(const char* msg) { motorWritePWM(0); g_last_pwm=0; g_armed=false; Serial.print("[STOP] "); Serial.println(msg); }

void matVecAd(const float x[4], float y[4]) {
  for (int i=0;i<4;++i) { y[i]=0.0f; for (int j=0;j<4;++j) y[i]+=Ad[i][j]*x[j]; }
}


// TODO: replace all zeros using design_kalman_gain.py, then set OBSERVER_PARAMS_FILLED=true.
static const float K_KALMAN[4][2] = {
  {0.0f, 0.0f},
  {0.0f, 0.0f},
  {0.0f, 0.0f},
  {0.0f, 0.0f}
};

void observerReset(float theta_meas, float alpha_meas) {
  g_xhat[0] = theta_meas; g_xhat[1] = 0.0f; g_xhat[2] = alpha_meas; g_xhat[3] = 0.0f;
}

void observerUpdate(float theta_meas, float alpha_meas, float u_prev) {
  // Steady-state Kalman observer: prediction first, then measurement correction.
  float xprev[4] = {g_xhat[0], g_xhat[1], g_xhat[2], g_xhat[3]};
  float pred[4];
  matVecAd(xprev, pred);
  for (int i=0;i<4;++i) pred[i] += Bd[i] * u_prev;

  float innov0 = theta_meas - pred[0];
  float innov1 = alpha_meas - pred[2];
  for (int i=0;i<4;++i) g_xhat[i] = pred[i] + K_KALMAN[i][0]*innov0 + K_KALMAN[i][1]*innov1;
}

// LQR gain: students replace these values after Class 8 calculation.
static const float K_THETA     = 0.0f;
static const float K_THETA_DOT = 0.0f;
static const float K_ALPHA     = 120.0f;
static const float K_ALPHA_DOT = 12.0f;

float computeControl() {
  return -(K_THETA*g_xhat[0] + K_THETA_DOT*g_xhat[1] + K_ALPHA*g_xhat[2] + K_ALPHA_DOT*g_xhat[3]);
}
const char* CTRL_NAME = "LQR";

void handleLine(String s) {
  s.trim();
  if (s == "GO") {
    if (!OBSERVER_PARAMS_FILLED) {
      Serial.println("[ERROR] observer_parameters_not_filled");
      Serial.println("Set OBSERVER_PARAMS_FILLED=true after copying observer gain matrix.");
      motorWritePWM(0); g_armed=false; return;
    }
    int pot_raw = analogRead(PIN_POT);
    float alpha = alphaFromPotRawBranchCutAtDown(pot_raw);
    if (fabs(alpha) > START_ALPHA_MAX_RAD) {
      Serial.print("[REFUSE] alpha_not_near_upright, alpha="); Serial.println(alpha, 6);
      motorWritePWM(0); g_armed=false; return;
    }
    noInterrupts(); ENC_ZERO = g_enc; interrupts();
    float theta0 = 0.0f;
    observerReset(theta0, alpha);
    g_step=0; g_fallen=false; g_last_pwm=0; g_armed=true;
    Serial.print("[ARMED] ENC_ZERO="); Serial.println((long)ENC_ZERO);
    Serial.println("HEADER,step,t_ms,tick_dt_us,armed,fallen,pwm,u_ctrl,pot,enc,theta_meas,alpha_meas,xhat_theta,xhat_theta_dot,xhat_alpha,xhat_alpha_dot");
    return;
  }
  if (s == "STOP" || s == "S") { stopAndDisarm("command"); return; }
}

void setup() {
  Serial.begin(BAUD); delay(300);
  pinMode(PIN_POT, INPUT); pinMode(PIN_ENC_A, INPUT_PULLUP); pinMode(PIN_ENC_B, INPUT_PULLUP);
  pinMode(PIN_IN1, OUTPUT); pinMode(PIN_IN2, OUTPUT); pinMode(PIN_STBY, OUTPUT); pinMode(PIN_PWM, OUTPUT);
  analogReadResolution(12); analogWriteResolution(8); motorWritePWM(0);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), isr_enc_a, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), isr_enc_b, CHANGE);
#ifdef USE_MPC_GAIN_COMPUTE
  computeMpcGain();
#endif
  Serial.print("=== RIP "); Serial.print(CTRL_NAME); Serial.println(" OBSERVER CONTROL READY ===");
  Serial.println("Fill observer gain matrix, set OBSERVER_PARAMS_FILLED=true, then upload again.");
  Serial.println("Hold pendulum near upright. Python script will send GO after Enter.");
}

void loop() {
  if (Serial.available()) {
    String s = Serial.readStringUntil('\n');
    handleLine(s);
  }

  static uint32_t last_us = 0;
  static uint32_t last_raw_print = 0;
  uint32_t now_us = micros();
  if ((uint32_t)(now_us - last_us) < DT_US) return;
  uint32_t tick_dt = now_us - last_us;
  last_us += DT_US;

  int pot_raw = analogRead(PIN_POT);
  noInterrupts(); int32_t enc_now = g_enc; int32_t enc_zero = ENC_ZERO; interrupts();
  float theta_meas = (float)(enc_now - enc_zero) * THETA_SCALE;
  float alpha_meas = alphaFromPotRawBranchCutAtDown(pot_raw);

  if (!g_armed) {
    motorWritePWM(0);
    if (millis() - last_raw_print > 500) {
      last_raw_print = millis();
      Serial.print("RAW,pot="); Serial.print(pot_raw);
      Serial.print(",enc="); Serial.print((long)enc_now);
      Serial.print(",alpha="); Serial.println(alpha_meas, 6);
    }
    return;
  }

  observerUpdate(theta_meas, alpha_meas, (float)g_last_pwm);

  if (fabs(g_xhat[2]) > FALLEN_ALPHA_RAD || fabs(alpha_meas) > FALLEN_ALPHA_RAD) {
    g_fallen = true;
    stopAndDisarm("fallen_alpha_limit");
    return;
  }

  float u_ctrl = computeControl();
  int pwm = clampInt((int)roundf(MOTOR_SIGN * u_ctrl), -PWM_MAX, PWM_MAX);
  motorWritePWM(pwm);
  g_last_pwm = pwm;

  Serial.print("LOG,");
  Serial.print(g_step++); Serial.print(",");
  Serial.print(millis()); Serial.print(",");
  Serial.print(tick_dt); Serial.print(",");
  Serial.print(g_armed ? 1 : 0); Serial.print(",");
  Serial.print(g_fallen ? 1 : 0); Serial.print(",");
  Serial.print(pwm); Serial.print(",");
  Serial.print(u_ctrl, 6); Serial.print(",");
  Serial.print(pot_raw); Serial.print(",");
  Serial.print((long)enc_now); Serial.print(",");
  Serial.print(theta_meas, 6); Serial.print(",");
  Serial.print(alpha_meas, 6); Serial.print(",");
  Serial.print(g_xhat[0], 6); Serial.print(",");
  Serial.print(g_xhat[1], 6); Serial.print(",");
  Serial.print(g_xhat[2], 6); Serial.print(",");
  Serial.println(g_xhat[3], 6);
}
