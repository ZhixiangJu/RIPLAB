import numpy as np
from scipy.signal import place_poles

# ============================================================
# Luenberger observer gain design for RIP
# Students should modify the desired poles and copy Ld to .ino.
# ============================================================

Ad = np.array([
    [1.00000000, 0.00486127, -0.00061123, 0.00000487],
    [0.00000000, 0.94505030, -0.24196125, 0.00172377],
    [0.00000000, 0.00020708, 1.00211620, 0.00498311],
    [0.00000000, 0.08197315, 0.84220195, 0.99398863],
], dtype=float)

C = np.array([
    [1.0, 0.0, 0.0, 0.0],
    [0.0, 0.0, 1.0, 0.0],
], dtype=float)

# Try several pole sets. They must be inside the unit circle.
poles = np.array([0.55+0.20j, 0.55-0.20j, 0.72, 0.82])

res = place_poles(Ad.T, C.T, poles)
Ld = res.gain_matrix.T

print("Desired poles:")
print(poles)
print("\nLd =")
print(Ld)
print("\nEigenvalues of Ad - Ld C:")
print(np.linalg.eigvals(Ad - Ld @ C))

print("\nCopy to firmware:")
print("static const float L_OBS[4][2] = {")
for i in range(4):
    print("  {" + ", ".join(f"{Ld[i,j]:.8f}f" for j in range(2)) + "},")
print("};")
