import csv
import glob
import os
import sys
import time
from datetime import datetime

import serial
import matplotlib.pyplot as plt

BAUD = 921600
DURATION_S = 10.0

HEADER = [
    "step", "t_ms", "tick_dt_us", "armed", "fallen", "pwm", "u_ctrl",
    "pot", "enc", "theta_meas", "alpha_meas", "xhat_theta", "xhat_theta_dot", "xhat_alpha", "xhat_alpha_dot"
]

PREFIX = "lqr_luenberger_log"
TITLE = "RIP LQR with Luenberger Observer"

def find_port_auto():
    plat = sys.platform.lower()
    cands = []
    if "darwin" in plat:
        cands += sorted(glob.glob("/dev/cu.usbmodem*"))
        cands += sorted(glob.glob("/dev/cu.usbserial*"))
    elif "linux" in plat:
        cands += sorted(glob.glob("/dev/ttyACM*"))
        cands += sorted(glob.glob("/dev/ttyUSB*"))
    elif "win" in plat:
        return ""
    cands = list(dict.fromkeys(cands))
    return cands[0] if cands else ""

def make_paths(prefix=PREFIX):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return os.path.abspath(f"lqr_luenberger_log_{ts}.csv"), os.path.abspath(f"lqr_luenberger_log_{ts}.png")

def wait_for_armed(ser, timeout=4.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        line = ser.readline().decode(errors="ignore").strip()
        if line:
            print(line)
        if line.startswith("[ARMED]"):
            return True
        if line.startswith("[REFUSE]") or line.startswith("[ERROR]"):
            return False
    return False

def parse_log(line):
    if not line.startswith("LOG,"):
        return None
    parts = line.split(",")[1:]
    if len(parts) != len(HEADER):
        return None
    try:
        return {
            "step": int(parts[0]), "t_ms": int(parts[1]), "tick_dt_us": int(parts[2]),
            "armed": int(parts[3]), "fallen": int(parts[4]), "pwm": int(parts[5]),
            "u_ctrl": float(parts[6]), "pot": int(parts[7]), "enc": int(parts[8]),
            "theta_meas": float(parts[9]), "alpha_meas": float(parts[10]),
            "xhat_theta": float(parts[11]), "xhat_theta_dot": float(parts[12]),
            "xhat_alpha": float(parts[13]), "xhat_alpha_dot": float(parts[14]),
        }
    except ValueError:
        return None

def plot_csv(csv_path, png_path):
    rows = []
    with open(csv_path, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append(row)
    if not rows:
        print("[WARN] No rows to plot.")
        return
    t0 = float(rows[0]["t_ms"])
    t = [(float(r["t_ms"]) - t0) / 1000.0 for r in rows]
    theta_m = [float(r["theta_meas"]) for r in rows]
    alpha_m = [float(r["alpha_meas"]) for r in rows]
    theta_h = [float(r["xhat_theta"]) for r in rows]
    alpha_h = [float(r["xhat_alpha"]) for r in rows]
    theta_dot = [float(r["xhat_theta_dot"]) for r in rows]
    alpha_dot = [float(r["xhat_alpha_dot"]) for r in rows]
    pwm = [float(r["pwm"]) for r in rows]

    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
    axes[0].plot(t, theta_m, label="theta_meas")
    axes[0].plot(t, theta_h, label="theta_hat", linestyle="--")
    axes[0].plot(t, alpha_m, label="alpha_meas")
    axes[0].plot(t, alpha_h, label="alpha_hat", linestyle="--")
    axes[0].set_ylabel("angle [rad]")
    axes[0].grid(True)
    axes[0].legend()

    axes[1].plot(t, theta_dot, label="theta_dot_hat")
    axes[1].plot(t, alpha_dot, label="alpha_dot_hat")
    axes[1].set_ylabel("estimated velocity [rad/s]")
    axes[1].grid(True)
    axes[1].legend()

    axes[2].plot(t, pwm, label="PWM")
    axes[2].set_xlabel("time [s]")
    axes[2].set_ylabel("PWM")
    axes[2].grid(True)
    axes[2].legend()

    fig.suptitle(TITLE)
    fig.tight_layout()
    fig.savefig(png_path, dpi=200)
    print(f"[OK] Figure saved: {png_path}")
    plt.show()

def main():
    port = sys.argv[1] if len(sys.argv) >= 2 else find_port_auto()
    if not port:
        print("[ERR] No serial port found. Usage:")
        print(f"  python {os.path.basename(sys.argv[0])} /dev/cu.usbmodemXXXX")
        print(f"  python {os.path.basename(sys.argv[0])} COM5")
        sys.exit(1)

    print(f"[OK] Port={port}, baud={BAUD}")
    try:
        ser = serial.Serial(port, BAUD, timeout=0.2)
    except Exception as e:
        print(f"[ERR] Cannot open serial port: {e}")
        print("Close Arduino Serial Monitor first.")
        sys.exit(1)

    time.sleep(0.5)
    ser.reset_input_buffer()

    print("\nBefore starting:")
    print("  1. Fill observer gain matrix in the firmware.")
    print("  2. Upload firmware to STM32.")
    print("  3. Hold the pendulum near upright by hand.")
    print("  4. Release gently immediately after pressing Enter.")
    input("\nPress Enter to send GO and start 10 s observer-control test ... ")

    ser.write(b"GO\n")
    ser.flush()
    if not wait_for_armed(ser):
        print("[ERR] STM32 did not arm. Check observer parameters, alpha near upright, baud rate, and firmware.")
        ser.write(b"STOP\n")
        ser.close()
        sys.exit(1)

    csv_path, png_path = make_paths()
    rows = []
    t_start = time.time()
    last_print = t_start
    print("[OK] Logging...")
    while time.time() - t_start < DURATION_S:
        line = ser.readline().decode(errors="ignore").strip()
        row = parse_log(line)
        if row is None:
            continue
        rows.append(row)
        if time.time() - last_print > 1.0:
            last_print = time.time()
            print(f"[LOG] t={time.time()-t_start:5.2f}s samples={len(rows)} alpha_hat={row['xhat_alpha']:+.3f} pwm={row['pwm']:+4d}")
        if row.get("fallen", 0):
            print("[WARN] Fallen flag received, stopping early.")
            break

    ser.write(b"STOP\n")
    ser.flush()
    ser.close()

    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=HEADER)
        w.writeheader()
        w.writerows(rows)
    print(f"[OK] CSV saved: {csv_path}")
    plot_csv(csv_path, png_path)

if __name__ == "__main__":
    main()
