This compact package keeps only the course example scripts. Install Gymnasium, PyTorch, and Stable-Baselines3 separately.
