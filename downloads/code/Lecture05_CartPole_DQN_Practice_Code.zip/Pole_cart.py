import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

LOCAL_GYM_REPO = os.path.join(PROJECT_ROOT, "gymnasium")
LOCAL_SB3_REPO = os.path.join(PROJECT_ROOT, "stable_baselines3")

if LOCAL_GYM_REPO not in sys.path:
    sys.path.insert(0, LOCAL_GYM_REPO)

if LOCAL_SB3_REPO not in sys.path:
    sys.path.insert(0, LOCAL_SB3_REPO)

import gymnasium as gym
from stable_baselines3.dqn.dqn import DQN
from stable_baselines3.common.env_util import make_vec_env
from torch import nn

# 1. create training environment
train_env = make_vec_env("CartPole-v1", n_envs=1)

# 2. define network architecture
policy_kwargs = dict(
    net_arch=[64,64],
    activation_fn=nn.ReLU
)

# 3. create model
model = DQN(
    policy="MlpPolicy",
    env=train_env,
    learning_rate=1e-3,
    buffer_size=50000,
    learning_starts=2000,
    batch_size=256,
    gamma=0.99,
    train_freq=1,
    target_update_interval=500,
    verbose=1,
    policy_kwargs=policy_kwargs
)

# 4. train
model.learn(total_timesteps=50000)

# 5. test
test_env = gym.make("CartPole-v1", render_mode="human")
total_score = 0
num_episodes = 20

for episode in range(1, num_episodes + 1):
    obs, _ = test_env.reset()
    done = False
    score = 0

    while not done:
        action, _ = model.predict(obs, deterministic=True)
        obs, reward, terminated, truncated, _ = test_env.step(action)
        score += reward
        done = terminated or truncated

    print(f"Episode {episode} score = {score}")
    total_score += score

avg_score = total_score / num_episodes
print(f"\nAverage score: {avg_score:.2f}")

test_env.close()

# 6. save model
model.save("dqn_cartpole_model")