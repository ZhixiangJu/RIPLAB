import os
import sys
import csv

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

LOCAL_GYM_REPO = os.path.join(PROJECT_ROOT, "gymnasium")
LOCAL_SB3_REPO = os.path.join(PROJECT_ROOT, "stable_baselines3")

if LOCAL_GYM_REPO not in sys.path:
    sys.path.insert(0, LOCAL_GYM_REPO)

if LOCAL_SB3_REPO not in sys.path:
    sys.path.insert(0, LOCAL_SB3_REPO)

import gymnasium as gym
from stable_baselines3.dqn.dqn import DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from torch import nn
import pandas as pd
import matplotlib.pyplot as plt


# =========================================================
# 0. 基本参数
# =========================================================
TOTAL_TIMESTEPS = 50000
NUM_TEST_EPISODES = 20
SAVE_MODEL_NAME = "dqn_cartpole_model"

# DQN 
LEARNING_RATE = 1e-3
BUFFER_SIZE = 50000
LEARNING_STARTS = 2000
BATCH_SIZE = 256
GAMMA = 0.99
TRAIN_FREQ = 1
TARGET_UPDATE_INTERVAL = 500

# epsilon-greedy
EXPLORATION_INITIAL_EPS = 1.0
EXPLORATION_FINAL_EPS = 0.05
EXPLORATION_FRACTION = 0.2

# network
NET_ARCH = [64, 64]

# reward design
USE_CUSTOM_REWARD = True

# reward weights
W_THETA = 5.0
W_X = 0.5
W_THETA_DOT = 0.1
BASE_REWARD = 1.0

# logging
LOG_DIR = os.path.join(PROJECT_ROOT, "test_logs")
PLOT_DIR = os.path.join(PROJECT_ROOT, "test_plots")
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(PLOT_DIR, exist_ok=True)


# =========================================================
# 1. 外部增加了一个奖励函数，除了存活基本奖励又加入：偏离越大对奖励的减少更多
# =========================================================
class CustomRewardWrapper(gym.Wrapper):
    """
    A wrapper that replaces the default reward with a shaped reward.

    Original CartPole default reward:
        reward = 1 for each valid step

    Here we use:
        reward = BASE_REWARD
                 - W_THETA * theta^2
                 - W_X * x^2
                 - W_THETA_DOT * theta_dot^2

    This encourages:
        - smaller pole angle
        - cart staying near the center
        - smaller angular velocity
    """

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)

        x = float(obs[0])
        theta = float(obs[2])
        theta_dot = float(obs[3])

        custom_reward = (
            BASE_REWARD
            - W_THETA * (theta ** 2)
            - W_X * (x ** 2)
            - W_THETA_DOT * (theta_dot ** 2)
        )

        info["original_reward"] = reward
        info["custom_reward"] = custom_reward

        return obs, custom_reward, terminated, truncated, info


# =========================================================
# 2. 调用
# =========================================================
def make_train_env():
    env = gym.make("CartPole-v1")
    if USE_CUSTOM_REWARD:
        env = CustomRewardWrapper(env)
    return env


def make_test_env(render_mode="human"):
    env = gym.make("CartPole-v1", render_mode=render_mode)
    if USE_CUSTOM_REWARD:
        env = CustomRewardWrapper(env)
    return env


# =========================================================
# 3. 创造训练环境
# =========================================================
train_env = DummyVecEnv([make_train_env])

policy_kwargs = dict(
    net_arch=NET_ARCH,
    activation_fn=nn.ReLU
)

model = DQN(
    policy="MlpPolicy",
    env=train_env,
    learning_rate=LEARNING_RATE,
    buffer_size=BUFFER_SIZE,
    learning_starts=LEARNING_STARTS,
    batch_size=BATCH_SIZE,
    gamma=GAMMA,
    train_freq=TRAIN_FREQ,
    target_update_interval=TARGET_UPDATE_INTERVAL,
    exploration_initial_eps=EXPLORATION_INITIAL_EPS,
    exploration_final_eps=EXPLORATION_FINAL_EPS,
    exploration_fraction=EXPLORATION_FRACTION,
    verbose=1,
    policy_kwargs=policy_kwargs
)

# =========================================================
# 4. 训练
# =========================================================
print("========== Start Training ==========")
model.learn(total_timesteps=TOTAL_TIMESTEPS)
print("========== Training Finished ==========")


# =========================================================
# 5. 测试以及日志
# =========================================================
print("========== Start Testing ==========")

test_env = make_test_env(render_mode="human")
total_score = 0.0

for episode in range(1, NUM_TEST_EPISODES + 1):
    obs, _ = test_env.reset()
    done = False
    score = 0.0
    step_idx = 0

    # rows to save into csv
    episode_rows = []

    while not done:
        # current state before action
        x = float(obs[0])
        x_dot = float(obs[1])
        theta = float(obs[2])
        theta_dot = float(obs[3])

        action, _ = model.predict(obs, deterministic=True)

        next_obs, reward, terminated, truncated, info = test_env.step(action)

        original_reward = info.get("original_reward", reward)
        custom_reward = info.get("custom_reward", reward)

        episode_rows.append([
            step_idx,
            x,
            x_dot,
            theta,
            theta_dot,
            int(action),
            float(reward),
            float(original_reward),
            float(custom_reward),
            int(terminated),
            int(truncated),
        ])

        obs = next_obs
        score += reward
        done = terminated or truncated
        step_idx += 1

    print(f"Episode {episode} score = {score:.3f}")
    total_score += score

    # -----------------------------------------------------
    # save csv
    # -----------------------------------------------------
    csv_path = os.path.join(LOG_DIR, f"episode_{episode:02d}.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "step",
            "x",
            "x_dot",
            "theta",
            "theta_dot",
            "action",
            "used_reward",
            "original_reward",
            "custom_reward",
            "terminated",
            "truncated",
        ])
        writer.writerows(episode_rows)

    # -----------------------------------------------------
    # save theta plot
    # -----------------------------------------------------
    df = pd.DataFrame(
        episode_rows,
        columns=[
            "step",
            "x",
            "x_dot",
            "theta",
            "theta_dot",
            "action",
            "used_reward",
            "original_reward",
            "custom_reward",
            "terminated",
            "truncated",
        ]
    )

    plt.figure(figsize=(8, 4))
    plt.plot(df["step"], df["theta"])
    plt.xlabel("Step")
    plt.ylabel("Theta (rad)")
    plt.title(f"Theta trajectory - Episode {episode}")
    plt.grid(True)
    plot_path = os.path.join(PLOT_DIR, f"episode_{episode:02d}_theta.png")
    plt.savefig(plot_path, dpi=150, bbox_inches="tight")
    plt.close()

avg_score = total_score / NUM_TEST_EPISODES
print(f"\nAverage score: {avg_score:.3f}")

test_env.close()
print("========== Testing Finished ==========")


# =========================================================
# 6. 保存
# =========================================================
print("========== Saving Model ==========")
model.save(SAVE_MODEL_NAME)
print(f"Model saved as: {SAVE_MODEL_NAME}")