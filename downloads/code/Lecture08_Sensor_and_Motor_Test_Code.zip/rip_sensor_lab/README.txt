RIP Sensor Lab Files
====================

Files:
1. rip_sensor_logger.ino
   - Upload this firmware to STM32 using Arduino IDE.
   - Before GO, it prints RAW potentiometer and encoder values slowly.
   - After receiving GO, it sets current encoder count as theta = 0.
   - Then it sends DATA lines at 200 Hz.

2. rip_record_10s.py
   - Run this script on PC.
   - It automatically sends GO after a 3-second countdown.
   - It records 10 seconds of data.
   - It saves CSV and PNG plots.

Important calibration:
- Hold the vertical pendulum upright and read the RAW potentiometer value.
- Modify POT_ZERO in rip_sensor_logger.ino.
- Upload the firmware again.

Python usage:
    python rip_record_10s.py

If the serial port cannot be found automatically:
    python rip_record_10s.py /dev/cu.usbmodemXXXX
    python rip_record_10s.py /dev/ttyACM0
    python rip_record_10s.py COM5

Required Python packages:
    pip install pyserial pandas matplotlib
