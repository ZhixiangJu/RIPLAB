import os
import sys
import csv
import glob
import time
from datetime import datetime

import serial
import pandas as pd
import matplotlib.pyplot as plt


BAUD = 921600
DURATION_S = 10.0

# Safe motor-test sequence.
# Each command is (time_from_start_s, pwm, duration_ms).
# The PWM value is intentionally small for the first hardware test.
MOTOR_SEQUENCE = [
    (1.0,  70, 400),
    (3.0, -70, 400),
    (5.0,  90, 400),
    (7.0, -90, 400),
]

CSV_HEADER = [
    "t_ms",
    "pot_raw",
    "enc",
    "theta",
    "alpha",
    "theta_dot",
    "alpha_dot",
    "pwm",
]


def find_port_auto():
    plat = sys.platform.lower()
    candidates = []

    if "darwin" in plat:
        candidates += sorted(glob.glob("/dev/cu.usbmodem*"))
        candidates += sorted(glob.glob("/dev/cu.usbserial*"))
    elif "linux" in plat:
        candidates += sorted(glob.glob("/dev/ttyACM*"))
        candidates += sorted(glob.glob("/dev/ttyUSB*"))
    elif "win" in plat:
        return ""

    candidates = list(dict.fromkeys(candidates))

    if not candidates:
        return ""

    if len(candidates) == 1:
        return candidates[0]

    print("[INFO] Multiple serial ports found:")
    for i, p in enumerate(candidates):
        print(f"  [{i}] {p}")

    print(f"[INFO] Auto-pick: {candidates[0]}")
    return candidates[0]


def make_output_paths():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = f"rip_motor_test_log_{ts}"
    csv_path = os.path.abspath(base + ".csv")
    fig_path = os.path.abspath(base + ".png")
    return csv_path, fig_path


def wait_for_armed(ser, timeout_s=3.0):
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        line = ser.readline().decode(errors="ignore").strip()
        if not line:
            continue
        print(line)
        if line.startswith("[ARMED]"):
            return True
    return False


def parse_data_line(line):
    # Expected:
    # DATA,t_ms,pot,enc,theta,alpha,theta_dot,alpha_dot,pwm
    if not line.startswith("DATA,"):
        return None

    parts = line.split(",")
    if len(parts) != 9:
        return None

    try:
        return [
            int(parts[1]),
            int(parts[2]),
            int(parts[3]),
            float(parts[4]),
            float(parts[5]),
            float(parts[6]),
            float(parts[7]),
            int(parts[8]),
        ]
    except ValueError:
        return None


def plot_latest_csv(csv_path, fig_path):
    df = pd.read_csv(csv_path)

    if df.empty:
        print("[WARN] CSV is empty. No figure generated.")
        return

    t = (df["t_ms"] - df["t_ms"].iloc[0]) / 1000.0

    fig, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)

    axes[0].plot(t, df["theta"], label=r"$\theta$ arm angle")
    axes[0].plot(t, df["alpha"], label=r"$\alpha$ pendulum angle")
    axes[0].set_ylabel("Angle [rad]")
    axes[0].grid(True)
    axes[0].legend()

    axes[1].plot(t, df["theta_dot"], label=r"$\dot{\theta}$")
    axes[1].plot(t, df["alpha_dot"], label=r"$\dot{\alpha}$")
    axes[1].set_ylabel("Angular velocity [rad/s]")
    axes[1].grid(True)
    axes[1].legend()

    axes[2].step(t, df["pwm"], where="post", label="PWM command")
    axes[2].set_xlabel("Time [s]")
    axes[2].set_ylabel("PWM")
    axes[2].grid(True)
    axes[2].legend()

    fig.suptitle("RIP Motor Test: Sensor Response and PWM Command")
    fig.tight_layout()
    fig.savefig(fig_path, dpi=200)
    print(f"[OK] Figure saved to: {fig_path}")
    plt.show()


def main():
    port = sys.argv[1] if len(sys.argv) >= 2 else ""
    if not port:
        port = find_port_auto()

    if not port:
        print("[ERR] No serial port found automatically.")
        print("Usage examples:")
        print("  python rip_motor_test_10s.py /dev/cu.usbmodemXXXX")
        print("  python rip_motor_test_10s.py /dev/ttyACM0")
        print("  python rip_motor_test_10s.py COM5")
        sys.exit(1)

    print(f"[OK] Serial port: {port}")
    print(f"[OK] Baud rate: {BAUD}")

    try:
        ser = serial.Serial(port, BAUD, timeout=0.05)
    except Exception as e:
        print(f"[ERR] Failed to open serial port: {e}")
        print("Tip: close Arduino Serial Monitor before running Python.")
        sys.exit(1)

    time.sleep(0.5)
    ser.reset_input_buffer()

    csv_path, fig_path = make_output_paths()

    print(f"[OK] CSV will be saved to: {csv_path}")
    print("[WARN] Keep hands away from the rotary arm during motor test.")
    print("[WARN] Make sure the motor power supply is connected only after wiring is checked.")
    print("[INFO] Countdown before GO:")

    for k in [3, 2, 1]:
        print(f"  {k} ...")
        time.sleep(1.0)

    ser.write(b"GO\n")
    ser.flush()
    print("[SENT] GO")

    if not wait_for_armed(ser, timeout_s=3.0):
        print("[ERR] Did not receive [ARMED].")
        print("Check firmware, baud rate, and serial port.")
        ser.close()
        sys.exit(1)

    rows = []
    t_start = time.time()
    last_print = t_start
    seq_index = 0

    print("[OK] Start 10-second motor test ...")

    while time.time() - t_start < DURATION_S:
        elapsed = time.time() - t_start

        if seq_index < len(MOTOR_SEQUENCE):
            cmd_time, pwm, dur_ms = MOTOR_SEQUENCE[seq_index]
            if elapsed >= cmd_time:
                cmd = f"PWM,{pwm},{dur_ms}\n"
                ser.write(cmd.encode("ascii"))
                ser.flush()
                print(f"[SENT] {cmd.strip()} at t={elapsed:.2f}s")
                seq_index += 1

        line = ser.readline().decode(errors="ignore").strip()
        if line:
            row = parse_data_line(line)
            if row is not None:
                rows.append(row)
            elif line.startswith("["):
                print(line)

        now = time.time()
        if now - last_print > 1.0:
            last_print = now
            print(f"[LOG] t={elapsed:5.2f}s, samples={len(rows)}")

    ser.write(b"STOP\n")
    ser.flush()
    ser.close()

    print(f"[OK] Motor test finished. Samples: {len(rows)}")

    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(CSV_HEADER)
        writer.writerows(rows)

    print(f"[OK] CSV saved to: {csv_path}")
    plot_latest_csv(csv_path, fig_path)


if __name__ == "__main__":
    main()
