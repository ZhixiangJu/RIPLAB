RIP motor test package
======================

Files:
  1. rip_motor_test.ino
     STM32 firmware. It is based on the sensor logger firmware and adds safe timed motor PWM commands.

  2. rip_motor_test_10s.py
     Python script. It sends GO, sends a small motor PWM sequence, records data for 10 seconds, saves CSV, and plots angle/angular-velocity/PWM curves.

  3. motor_test_slides.tex
     Two Beamer slides that can be inserted into the lecture slides.

Basic usage:
  1. Check wiring carefully. Make sure STM32 logic is 3.3 V and all grounds are common.
  2. Upload rip_motor_test.ino to STM32.
  3. Close Arduino Serial Monitor.
  4. Run:
       python rip_motor_test_10s.py
     If the serial port is not found automatically, specify it manually, for example:
       python rip_motor_test_10s.py COM5
       python rip_motor_test_10s.py /dev/ttyACM0
       python rip_motor_test_10s.py /dev/cu.usbmodemXXXX

Safety:
  - This is not a closed-loop balancing test.
  - The motor PWM is limited in the firmware.
  - Each PWM command has a maximum duration of 1 second.
  - Keep hands and objects away from the rotary arm while running the motor test.
