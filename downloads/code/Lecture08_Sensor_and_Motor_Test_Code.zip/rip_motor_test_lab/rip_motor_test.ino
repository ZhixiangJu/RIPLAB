#include <Arduino.h>
#include <math.h>

// ============================================================
// RIP motor test firmware
// File name: rip_motor_test.ino
//
// Based on the sensor logger firmware, with safe motor-test commands added.
// Function:
//   1. Before GO: print raw potentiometer and encoder values slowly.
//   2. After GO: set current encoder count as theta = 0.
//   3. Send calibrated theta, alpha, theta_dot, alpha_dot at 200 Hz.
//   4. Accept safe motor commands from PC:
//        PWM,<value>,<duration_ms>
//      Example:
//        PWM,80,500
//        PWM,-80,500
//   5. Motor automatically stops after the command duration.
// ============================================================

// -------------------------
// Pin definition
// -------------------------
static const int PIN_POT   = A0;
static const int PIN_ENC_A = 2;
static const int PIN_ENC_B = 3;

// TB6612 pins
static const int PIN_IN1  = 4;
static const int PIN_IN2  = 5;
static const int PIN_STBY = 7;
static const int PIN_PWM  = 10;

// -------------------------
// Sampling
// -------------------------
static const uint32_t BAUD = 921600;
static const uint32_t CTRL_HZ = 200;
static const uint32_t DT_US = 1000000UL / CTRL_HZ;
static const float DT_CTRL = 1.0f / (float)CTRL_HZ;

// -------------------------
// Constants
// -------------------------
static const float PI_F = 3.14159265358979323846f;
static const int32_t POT_MOD = 4096;

// ============================================================
// Calibration values
// Students usually only need to modify POT_ZERO and POT_DOWN_RAW.
// ============================================================

static const float THETA_SIGN = +1.0f;
static const float THETA_CAL_ONE_TURN_MEAS_RAD = 6.503f;

static const float THETA_SCALE_NOMINAL =
    THETA_SIGN * (PI_F / 520.0f);

static const float THETA_SCALE =
    THETA_SCALE_NOMINAL *
    ((2.0f * PI_F) / THETA_CAL_ONE_TURN_MEAS_RAD);

// IMPORTANT:
//   POT_ZERO is the raw value when the pendulum is upright.
//   POT_DOWN_RAW is the raw value when the pendulum is naturally hanging down.
static volatile int32_t POT_ZERO = 3132;
static volatile int32_t POT_DOWN_RAW = 1036;

// If pot_raw decreases when rotating clockwise from upright, set true.
static const bool POT_CW_DECREASES = true;

// Velocity low-pass filter coefficient
static const float VEL_DIFF_LPF = 0.25f;

// -------------------------
// Motor safety settings
// -------------------------
static const int PWM_LIMIT = 120;                 // do not use large PWM in this test
static const uint32_t MAX_CMD_DURATION_MS = 1000; // each command <= 1 s
static const float ALPHA_SAFE_LIMIT_RAD = 2.6f;   // stop if pendulum is too close to singular region

// -------------------------
// Global variables
// -------------------------
static volatile int32_t g_enc = 10000;
static volatile int32_t ENC_ZERO = 10000;

static bool g_armed = false;

static float g_theta_prev = 0.0f;
static float g_alpha_prev = 0.0f;
static float g_theta_dot_lpf = 0.0f;
static float g_alpha_dot_lpf = 0.0f;
static bool g_vel_inited = false;

static int g_motor_pwm_cmd = 0;
static uint32_t g_motor_stop_ms = 0;

// ============================================================
// Utility functions
// ============================================================

static inline float wrapToPi(float x) {
    while (x > PI_F)  x -= 2.0f * PI_F;
    while (x < -PI_F) x += 2.0f * PI_F;
    return x;
}

static inline int32_t mod4096(int32_t x) {
    x %= POT_MOD;
    if (x < 0) x += POT_MOD;
    return x;
}

static inline int32_t cwDistCounts(int32_t ref, int32_t x) {
    ref = mod4096(ref);
    x   = mod4096(x);

    if (POT_CW_DECREASES) {
        return mod4096(ref - x);
    } else {
        return mod4096(x - ref);
    }
}

// alpha = 0 at upright.
// The branch cut is placed near the natural hanging-down position.
static inline float alphaFromPotRawBranchCutAtDown(int32_t pot_raw) {
    const int32_t up = mod4096(POT_ZERO);
    const int32_t dn = mod4096(POT_DOWN_RAW);
    const int32_t x  = mod4096(pot_raw);

    int32_t cw_to_down = cwDistCounts(up, dn);
    if (cw_to_down <= 0 || cw_to_down >= POT_MOD) {
        return 0.0f;
    }

    int32_t cw_to_x = cwDistCounts(up, x);

    if (cw_to_x <= cw_to_down) {
        return PI_F * ((float)cw_to_x / (float)cw_to_down);
    }

    int32_t rem = POT_MOD - cw_to_down;
    if (rem <= 0) return 0.0f;

    return -PI_F * ((float)(POT_MOD - cw_to_x) / (float)rem);
}

// ============================================================
// Encoder interrupt
// ============================================================

void isr_enc_a() {
    bool A = digitalRead(PIN_ENC_A);
    bool B = digitalRead(PIN_ENC_B);

    if (A) {
        g_enc += (B ? 1 : -1);
    } else {
        g_enc += (B ? -1 : 1);
    }
}

void isr_enc_b() {
    bool A = digitalRead(PIN_ENC_A);
    bool B = digitalRead(PIN_ENC_B);

    if (B) {
        g_enc += (A ? -1 : 1);
    } else {
        g_enc += (A ? 1 : -1);
    }
}

// ============================================================
// Motor functions
// ============================================================

void motorSafeOff() {
    g_motor_pwm_cmd = 0;
    g_motor_stop_ms = 0;
    digitalWrite(PIN_STBY, LOW);
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, LOW);
    analogWrite(PIN_PWM, 0);
}

void motorWritePWM(int pwm) {
    pwm = constrain(pwm, -PWM_LIMIT, PWM_LIMIT);

    if (pwm == 0) {
        motorSafeOff();
        return;
    }

    digitalWrite(PIN_STBY, HIGH);

    if (pwm > 0) {
        digitalWrite(PIN_IN1, HIGH);
        digitalWrite(PIN_IN2, LOW);
        analogWrite(PIN_PWM, pwm);
    } else {
        digitalWrite(PIN_IN1, LOW);
        digitalWrite(PIN_IN2, HIGH);
        analogWrite(PIN_PWM, -pwm);
    }
}

void startTimedPWM(int pwm, uint32_t duration_ms) {
    pwm = constrain(pwm, -PWM_LIMIT, PWM_LIMIT);
    duration_ms = constrain(duration_ms, 1UL, MAX_CMD_DURATION_MS);

    g_motor_pwm_cmd = pwm;
    g_motor_stop_ms = millis() + duration_ms;
    motorWritePWM(pwm);

    Serial.print("[MOTOR] PWM=");
    Serial.print(pwm);
    Serial.print(", duration_ms=");
    Serial.println(duration_ms);
}

// ============================================================
// Serial command
// ============================================================

void handleLine(String s) {
    s.trim();

    if (s == "GO") {
        noInterrupts();
        ENC_ZERO = g_enc;
        interrupts();

        g_theta_prev = 0.0f;
        g_alpha_prev = 0.0f;
        g_theta_dot_lpf = 0.0f;
        g_alpha_dot_lpf = 0.0f;
        g_vel_inited = false;

        motorSafeOff();
        g_armed = true;

        Serial.print("[ARMED] ENC_ZERO=");
        Serial.println((long)ENC_ZERO);
        Serial.println("HEADER,t_ms,pot,enc,theta,alpha,theta_dot,alpha_dot,pwm");
        return;
    }

    if (s == "S" || s == "STOP") {
        g_armed = false;
        motorSafeOff();
        Serial.println("[STOP]");
        return;
    }

    // Motor command format: PWM,<value>,<duration_ms>
    // Example: PWM,80,500
    if (s.startsWith("PWM,")) {
        int comma1 = s.indexOf(',');
        int comma2 = s.indexOf(',', comma1 + 1);

        if (comma1 < 0 || comma2 < 0) {
            Serial.println("[ERR] Bad PWM command. Use PWM,<value>,<duration_ms>");
            return;
        }

        int pwm = s.substring(comma1 + 1, comma2).toInt();
        uint32_t dur = (uint32_t)s.substring(comma2 + 1).toInt();

        if (!g_armed) {
            Serial.println("[ERR] Send GO before PWM command.");
            return;
        }

        startTimedPWM(pwm, dur);
        return;
    }
}

// ============================================================
// Setup
// ============================================================

void setup() {
    Serial.begin(BAUD);
    delay(300);

    pinMode(PIN_POT, INPUT);
    pinMode(PIN_ENC_A, INPUT_PULLUP);
    pinMode(PIN_ENC_B, INPUT_PULLUP);

    pinMode(PIN_IN1, OUTPUT);
    pinMode(PIN_IN2, OUTPUT);
    pinMode(PIN_STBY, OUTPUT);
    pinMode(PIN_PWM, OUTPUT);

    analogReadResolution(12);
    analogWriteResolution(8);

    motorSafeOff();

    attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), isr_enc_a, CHANGE);
    attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), isr_enc_b, CHANGE);

    Serial.println("=== RIP MOTOR TEST READY ===");
    Serial.print("[CAL] POT_ZERO=");
    Serial.println((int)POT_ZERO);
    Serial.print("[CAL] POT_DOWN_RAW=");
    Serial.println((int)POT_DOWN_RAW);
    Serial.println("[INFO] Send GO first. Then send PWM,<value>,<duration_ms>.");
    Serial.println("[INFO] Example: PWM,80,500 or PWM,-80,500");
}

// ============================================================
// Loop
// ============================================================

void loop() {
    if (Serial.available()) {
        String s = Serial.readStringUntil('\n');
        handleLine(s);
    }

    static uint32_t last_us = 0;
    uint32_t now_us = micros();

    if (now_us - last_us < DT_US) {
        return;
    }
    last_us += DT_US;

    int pot_raw = analogRead(PIN_POT);

    noInterrupts();
    int32_t enc_now = g_enc;
    int32_t enc_zero = ENC_ZERO;
    interrupts();

    float theta = (float)(enc_now - enc_zero) * THETA_SCALE;
    float alpha = alphaFromPotRawBranchCutAtDown(pot_raw);

    if (!g_vel_inited) {
        g_theta_prev = theta;
        g_alpha_prev = alpha;
        g_theta_dot_lpf = 0.0f;
        g_alpha_dot_lpf = 0.0f;
        g_vel_inited = true;
    }

    float theta_dot_raw = (theta - g_theta_prev) / DT_CTRL;
    float alpha_dot_raw = wrapToPi(alpha - g_alpha_prev) / DT_CTRL;

    g_theta_dot_lpf =
        (1.0f - VEL_DIFF_LPF) * g_theta_dot_lpf + VEL_DIFF_LPF * theta_dot_raw;

    g_alpha_dot_lpf =
        (1.0f - VEL_DIFF_LPF) * g_alpha_dot_lpf + VEL_DIFF_LPF * alpha_dot_raw;

    g_theta_prev = theta;
    g_alpha_prev = alpha;

    // Automatic motor timeout
    if (g_motor_pwm_cmd != 0 && millis() >= g_motor_stop_ms) {
        motorSafeOff();
        Serial.println("[MOTOR] auto stop");
    }

    // Safety stop if alpha is too large in magnitude
    if (fabs(alpha) > ALPHA_SAFE_LIMIT_RAD && g_motor_pwm_cmd != 0) {
        motorSafeOff();
        Serial.println("[MOTOR] safety stop: alpha too large");
    }

    if (g_armed) {
        Serial.print("DATA,");
        Serial.print(millis());
        Serial.print(",");
        Serial.print(pot_raw);
        Serial.print(",");
        Serial.print((long)enc_now);
        Serial.print(",");
        Serial.print(theta, 6);
        Serial.print(",");
        Serial.print(alpha, 6);
        Serial.print(",");
        Serial.print(g_theta_dot_lpf, 6);
        Serial.print(",");
        Serial.print(g_alpha_dot_lpf, 6);
        Serial.print(",");
        Serial.println(g_motor_pwm_cmd);
    } else {
        static uint32_t raw_count = 0;
        raw_count++;

        if (raw_count >= 100) {
            raw_count = 0;
            Serial.print("RAW,pot=");
            Serial.print(pot_raw);
            Serial.print(",enc=");
            Serial.println((long)enc_now);
        }
    }
}
