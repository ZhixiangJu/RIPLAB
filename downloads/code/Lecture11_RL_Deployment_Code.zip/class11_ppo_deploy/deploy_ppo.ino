#include <Arduino.h>
#include <math.h>
#include <HardwareTimer.h>

// 兼容非法写法 0f / 1f / 2f ... （把它当作 float）
constexpr float operator"" f(unsigned long long v) { return (float)v; }
constexpr float operator"" f(long double v) { return (float)v; }

// ============================================================
// 两个模型头文件
// 请把连续动作 PPO 头文件重命名为：ppo_model_weights.h
// 请把 DQN 起摆头文件重命名为：dqn_model_weights.h
// 两个文件和本 ino 放在同一个 Arduino 工程目录下
// ============================================================
#include "ppo_model_weights.h"
#include "dqn_model_weights.h"

// ============================================================
// 模型维度检查
// PPO：连续动作，6维或7维都兼容
// DQN：起摆，4维或6维都兼容；你当前上传的是6维
// ============================================================
#ifndef PPO_STATE_DIM
  #ifdef PPO_OBS_DIM
    #define PPO_STATE_DIM PPO_OBS_DIM
  #endif
#endif

#if !defined(PPO_STATE_DIM)
  #error "PPO header missing PPO_STATE_DIM or PPO_OBS_DIM."
#endif

#if (PPO_STATE_DIM != 6) && (PPO_STATE_DIM != 7)
  #error "This firmware expects PPO_STATE_DIM == 6 or 7."
#endif

#ifndef PPO_ACT_DIM
  #define PPO_ACT_DIM 1
#endif

#if PPO_ACT_DIM != 1
  #error "This firmware expects PPO_ACT_DIM == 1."
#endif

#if !defined(DQN_STATE_DIM)
  #ifdef DQN_OBS_DIM
    #define DQN_STATE_DIM DQN_OBS_DIM
  #endif
#endif

#if !defined(DQN_STATE_DIM) || !defined(DQN_ACT_DIM)
  #error "DQN header missing DQN_STATE_DIM/DQN_OBS_DIM or DQN_ACT_DIM."
#endif

#if (DQN_STATE_DIM != 4) && (DQN_STATE_DIM != 6)
  #error "This firmware expects DQN_STATE_DIM == 4 or 6."
#endif

// 注意：DQN_ACTIONS 是 static const 数组，不是宏，不能用 #if defined(DQN_ACTIONS) 检查。
// 如果头文件中没有 DQN_ACTIONS，编译器会在 dqn_policy_pwm() 使用处直接报错。

// ============================================================
// 引脚定义：与现有 TD3 / PPO / DQN 部署代码对齐
// ============================================================
static const int PIN_POT   = A0;
static const int PIN_ENC_A = 2;
static const int PIN_ENC_B = 3;

static const int PIN_IN1  = 4;
static const int PIN_IN2  = 5;
static const int PIN_STBY = 7;
static const int PIN_PWM  = 10;

static const uint32_t CTRL_HZ = 200;
static const float DT_CTRL = 1.0f / (float)CTRL_HZ;

static const float PI_F = 3.14159265358979323846f;
static const int32_t POT_MOD = 4096;
static const float THETA_SIGN = +1.0f;

// ============================================================
// 部署 PWM 总限幅
// 为了和你当前 PPO / DQN 训练导出保持一致，统一限制 [-150, 150]
// ============================================================
static const int16_t PWM_LIMIT_DEPLOY = 150;
static const float PWM_LIMIT_DEPLOY_F = 150.0f;

#ifdef PPO_CONTINUOUS_PWM_LIMIT
static const float PPO_HEADER_PWM_LIMIT = PPO_CONTINUOUS_PWM_LIMIT;
#else
static const float PPO_HEADER_PWM_LIMIT = 150.0f;
#endif

static const float PPO_PWM_LIMIT_RUNTIME = PWM_LIMIT_DEPLOY_F;

// ============================================================
// 新机器快速部署参数
// ============================================================
static const float THETA_CAL_ONE_TURN_MEAS_RAD = 6.503f;

static volatile int32_t POT_ZERO = 3120;
static volatile int32_t POT_DOWN_RAW = 996;

static const bool POT_CW_DECREASES = true;
static volatile int32_t ENC_ZERO = 10000;

static const float THETA_SCALE_NOMINAL = THETA_SIGN * (PI_F / 520.0f);
static const float THETA_SCALE =
    THETA_SCALE_NOMINAL * ((2.0f * PI_F) / THETA_CAL_ONE_TURN_MEAS_RAD);

static const float ALPHA_LIM = 2.0f * PI_F;

// ============================================================
// Sim-to-real sign alignment
// ============================================================
static const float MOTOR_PWM_SIGN = +1.0f;
static const float THETA_OBS_SIGN = +1.0f;
static const float ALPHA_OBS_SIGN = +1.0f;

// ============================================================
// Hybrid 切换逻辑
// 大角度：DQN 起摆
// 进入 |alpha| <= 15 deg 后：PPO 连续动作稳定
// 若 PPO 后又甩出 |alpha| >= 25 deg：切回 DQN
// ============================================================
static const float PPO_ENTER_RAD = 15.0f * PI_F / 180.0f;
static const float PPO_EXIT_RAD  = 15.0f * PI_F / 180.0f;
static const bool  RESET_OBSERVER_WHEN_ENTER_PPO = true;

// ============================================================
// 两段式预起摆：保留你原来的设置
// 若想完全由 DQN 从下垂开始起摆，可把 ENABLE_PRE_SWING 改为 false
// ============================================================
static const bool ENABLE_PRE_SWING = true;
static const int16_t PRE_PWM_1 = +150;
static const int16_t PRE_PWM_2 = -150;
static const uint32_t PRE_SWING_STEPS_1 = 100;
static const uint32_t PRE_SWING_STEPS_2 = 100;

// ============================================================
// 差分 + 低通角速度
// DQN 和 PPO 都使用同一套速度估计；PPO 进入小角度后可用观测器状态
// ============================================================
static const float VEL_DIFF_LPF = 0.25f;
static const bool USE_OBS_VEL_CLIP = false;
static const float THETA_DOT_OBS_LIMIT = 45.0f;
static const float ALPHA_DOT_OBS_LIMIT = 40.0f;

// PPO 小角度状态源：进入 PPO 后默认使用观测器状态
static const bool ENABLE_OBSERVER_FOR_PPO = true;

// ============================================================
// 观测器参数：与 TD3 对齐
// ============================================================
static const float OBS_Ad[4][4] = {
  { 0.82469568f,  0.00438721f, -0.31915638f, -0.00085553f },
  { -1.75095359f, 0.94056709f, -0.04181246f,  0.00193564f },
  { -0.05215683f, 0.00005656f,  0.76549687f,  0.00439733f },
  { -1.38405407f, 0.07685667f, -15.83946960f, 0.95027468f },
};

static const float OBS_Bd_u[4] = {
   0.00001119f,
   0.00396389f,
  -0.00001398f,
  -0.00583846f
};

static const float OBS_Bd_y[4][2] = {
  { 0.17530432f,  0.31833008f },
  { 1.75095359f, -0.19974721f },
  { 0.05215683f,  0.23646539f },
  { 1.38405407f, 16.66931771f },
};

static const float VEL_CLIP = 500.0f;
static const float OBS_RESET_ERR_LIM = 35.0f * PI_F / 180.0f;

// ============================================================
// 风火轮保护：触发后 PWM=0 持续 1s，然后恢复控制
// ============================================================
static const bool  ENABLE_SPIN_PROTECT = true;
static const float SPIN_PROTECT_MAX_EXCURSION_RAD = 300.0f * PI_F / 180.0f;
static const bool  SPIN_PROTECT_AFTER_PRE_SWING_ONLY = true;
static const uint32_t SPIN_PROTECT_COOLDOWN_STEPS = 200;

// ============================================================
// 全局状态
// ============================================================
static volatile int32_t g_enc = 10000;

static volatile bool g_armed = false;
static volatile bool g_tick_flag = false;
static volatile bool g_fallen = false;

static volatile int16_t  g_pot_raw = 0;
static volatile int32_t  g_enc_raw = 10000;

static volatile float g_theta_meas = 0.0f;
static volatile float g_alpha_meas = 0.0f;
static volatile float g_alpha_meas_obs = 0.0f;

static volatile float g_xhat[4] = {0, 0, 0, 0};

// 上一拍“网络坐标系”下 PWM；7维 PPO 时作为 obs[6]
static volatile float g_u_prev = 0.0f;

static volatile int16_t g_pwm_cmd = 0;
static volatile bool    g_brake = true;

static volatile uint32_t g_t_cmd_cyc = 0;
static volatile uint32_t g_tick_dt_us = 0;
static volatile uint32_t g_lat_total_us = 0;
static volatile uint32_t g_lat_comp_us = 0;

static volatile uint32_t g_step = 0;
static volatile bool g_obs_inited = false;
static volatile uint32_t g_arm_step = 0;

static volatile bool  g_diff_vel_inited = false;
static volatile float g_theta_prev_meas = 0.0f;
static volatile float g_alpha_prev_meas = 0.0f;
static volatile float g_thetaDot_diff_lpf = 0.0f;
static volatile float g_alphaDot_diff_lpf = 0.0f;

// 混合控制模式：false = DQN，true = PPO
static volatile bool g_ppo_mode = false;

// alpha 连续展开角，用于风火轮保护
static volatile bool  g_alpha_unwrap_inited = false;
static volatile float g_alpha_cont = 0.0f;
static volatile float g_alpha_cont_ref = 0.0f;

static volatile bool g_spin_cooldown_active = false;
static volatile uint32_t g_spin_cooldown_left = 0;

// ============================================================
// DWT 计时
// ============================================================
static inline void dwt_init_user() {
#if defined(DWT)
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
#endif
}

static inline uint32_t dwt_cycles_user() {
#if defined(DWT)
  return DWT->CYCCNT;
#else
  return 0;
#endif
}

static inline uint32_t cycles_to_us_user(uint32_t cyc) {
  return (uint32_t)((uint64_t)cyc * 1000000ULL / (uint64_t)F_CPU);
}

// ============================================================
// 工具函数
// ============================================================
static inline int32_t mod4096(int32_t x) {
  x %= POT_MOD;
  if (x < 0) x += POT_MOD;
  return x;
}

static inline float wrapToPiUser(float x) {
  while (x > PI_F)  x -= 2.0f * PI_F;
  while (x < -PI_F) x += 2.0f * PI_F;
  return x;
}

static inline float clip_user(float x, float lo, float hi) {
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

static inline int16_t clamp_pwm_deploy_int16(int16_t x) {
  if (x > PWM_LIMIT_DEPLOY) return PWM_LIMIT_DEPLOY;
  if (x < -PWM_LIMIT_DEPLOY) return -PWM_LIMIT_DEPLOY;
  return x;
}

static inline float clamp_pwm_deploy_float(float x) {
  if (x > PWM_LIMIT_DEPLOY_F) return PWM_LIMIT_DEPLOY_F;
  if (x < -PWM_LIMIT_DEPLOY_F) return -PWM_LIMIT_DEPLOY_F;
  return x;
}

static inline float relu_user(float x) {
  return x > 0.0f ? x : 0.0f;
}

// 从 ref 到 x 的“顺时针物理距离（计数）”
static inline int32_t cwDistCounts(int32_t ref, int32_t x) {
  ref = mod4096(ref);
  x   = mod4096(x);
  if (POT_CW_DECREASES) return mod4096(ref - x);
  return mod4096(x - ref);
}

// alpha 定义：branch cut 放在自然下垂
static inline float alphaFromPotRawBranchCutAtDown(int32_t pot_raw) {
  const int32_t up = mod4096(POT_ZERO);
  const int32_t dn = mod4096(POT_DOWN_RAW);
  const int32_t x  = mod4096(pot_raw);

  int32_t cw_to_down = cwDistCounts(up, dn);
  if (cw_to_down <= 0 || cw_to_down >= POT_MOD) return 0.0f;

  int32_t cw_to_x = cwDistCounts(up, x);

  if (cw_to_x <= cw_to_down) {
    return PI_F * ((float)cw_to_x / (float)cw_to_down);
  }

  int32_t rem = POT_MOD - cw_to_down;
  if (rem <= 0) return 0.0f;

  return -PI_F * ((float)(POT_MOD - cw_to_x) / (float)rem);
}

// ============================================================
// 电机控制
// ============================================================
static inline void motorStandby(bool standby) {
  digitalWrite(PIN_STBY, standby ? LOW : HIGH);
}

static inline void motorBrake() {
  digitalWrite(PIN_IN1, HIGH);
  digitalWrite(PIN_IN2, HIGH);
  analogWrite(PIN_PWM, 0);
  motorStandby(true);
}

static inline void motorDriveSigned(int16_t pwm_signed) {
  int16_t p = clamp_pwm_deploy_int16(pwm_signed);

  motorStandby(false);

  if (p == 0) {
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, LOW);
    analogWrite(PIN_PWM, 0);
    return;
  }

  if (p > 0) {
    digitalWrite(PIN_IN1, HIGH);
    digitalWrite(PIN_IN2, LOW);
    analogWrite(PIN_PWM, (uint8_t)p);
  } else {
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, HIGH);
    analogWrite(PIN_PWM, (uint8_t)(-p));
  }
}

// ============================================================
// 编码器中断
// ============================================================
void isr_enc_a() {
  bool A = digitalRead(PIN_ENC_A);
  bool B = digitalRead(PIN_ENC_B);
  if (A) g_enc += (B ? 1 : -1);
  else   g_enc += (B ? -1 : 1);
}

void isr_enc_b() {
  bool A = digitalRead(PIN_ENC_A);
  bool B = digitalRead(PIN_ENC_B);
  if (B) g_enc += (A ? -1 : 1);
  else   g_enc += (A ? 1 : -1);
}

// ============================================================
// 观测器
// ============================================================
static inline void obs_init_from_meas(float theta, float alpha, float xhat_local[4]) {
  xhat_local[0] = theta;
  xhat_local[1] = 0.0f;
  xhat_local[2] = alpha;
  xhat_local[3] = 0.0f;
}

static inline void obs_update_one_step(float u_prev, float theta_meas, float alpha_meas, float xhat_local[4]) {
  float y0 = theta_meas;
  float y1 = alpha_meas;
  float xn[4];

  for (int i = 0; i < 4; i++) {
    float s = 0.0f;
    s += OBS_Ad[i][0] * xhat_local[0]
       + OBS_Ad[i][1] * xhat_local[1]
       + OBS_Ad[i][2] * xhat_local[2]
       + OBS_Ad[i][3] * xhat_local[3];
    s += OBS_Bd_u[i] * u_prev;
    s += OBS_Bd_y[i][0] * y0 + OBS_Bd_y[i][1] * y1;
    xn[i] = s;
  }

  if (!isfinite(xn[0]) || !isfinite(xn[1]) || !isfinite(xn[2]) || !isfinite(xn[3])) {
    obs_init_from_meas(y0, y1, xhat_local);
    return;
  }

  if (xn[1] >  VEL_CLIP) xn[1] =  VEL_CLIP;
  if (xn[1] < -VEL_CLIP) xn[1] = -VEL_CLIP;
  if (xn[3] >  VEL_CLIP) xn[3] =  VEL_CLIP;
  if (xn[3] < -VEL_CLIP) xn[3] = -VEL_CLIP;

  if (fabsf(xn[2] - alpha_meas) > OBS_RESET_ERR_LIM) {
    obs_init_from_meas(y0, y1, xhat_local);
    return;
  }

  xhat_local[0] = xn[0];
  xhat_local[1] = xn[1];
  xhat_local[2] = xn[2];
  xhat_local[3] = xn[3];
}

// ============================================================
// DQN 推理：兼容 legacy DQN 头文件
// 你当前上传的 DQN 头文件就是 DQN_W1/DQN_b1/DQN_W2/DQN_b2/DQN_W3/DQN_b3
// ============================================================
#if defined(DQN_H1) && defined(DQN_H2)
static float dqn_h1_buf[DQN_H1];
static float dqn_h2_buf[DQN_H2];

static inline int dqn_argmax_action(const float s[DQN_STATE_DIM]) {
  for (int i = 0; i < DQN_H1; i++) {
    float z = DQN_b1[i];
    for (int j = 0; j < DQN_STATE_DIM; j++) z += DQN_W1[i][j] * s[j];
    dqn_h1_buf[i] = relu_user(z);
  }

  for (int i = 0; i < DQN_H2; i++) {
    float z = DQN_b2[i];
    for (int j = 0; j < DQN_H1; j++) z += DQN_W2[i][j] * dqn_h1_buf[j];
    dqn_h2_buf[i] = relu_user(z);
  }

  int best = 0;
  float bestQ = -1.0e30f;
  for (int a = 0; a < DQN_ACT_DIM; a++) {
    float q = DQN_b3[a];
    for (int j = 0; j < DQN_H2; j++) q += DQN_W3[a][j] * dqn_h2_buf[j];
    if (q > bestQ) {
      bestQ = q;
      best = a;
    }
  }
  return best;
}
#else
  #error "This firmware currently expects legacy DQN header with DQN_H1/DQN_H2."
#endif

static inline int16_t dqn_policy_pwm(float theta, float theta_dot, float alpha, float alpha_dot) {
  float s[DQN_STATE_DIM];

#if DQN_STATE_DIM == 4
  s[0] = theta;
  s[1] = theta_dot;
  s[2] = alpha;
  s[3] = alpha_dot;
#elif DQN_STATE_DIM == 6
  s[0] = sinf(theta);
  s[1] = cosf(theta);
  s[2] = theta_dot;
  s[3] = sinf(alpha);
  s[4] = cosf(alpha);
  s[5] = alpha_dot;
#endif

  int aidx = dqn_argmax_action(s);
  int16_t pwm = (int16_t)DQN_ACTIONS[aidx];
  return clamp_pwm_deploy_int16(pwm);
}

// ============================================================
// PPO 推理：连续动作 action_norm in [-1, 1] -> PWM [-150, 150]
// ============================================================
static inline int16_t ppo_action_to_pwm(float a) {
  a = clip_user(a, -1.0f, 1.0f);
  float pwm_f = a * PPO_PWM_LIMIT_RUNTIME;
  pwm_f = clamp_pwm_deploy_float(pwm_f);
  return (int16_t)lroundf(pwm_f);
}

static inline int16_t ppo_policy_pwm(float theta, float theta_dot, float alpha, float alpha_dot, float u_prev) {
  float s[PPO_STATE_DIM];

  s[0] = sinf(theta);
  s[1] = cosf(theta);
  s[2] = theta_dot;
  s[3] = sinf(alpha);
  s[4] = cosf(alpha);
  s[5] = alpha_dot;

#if PPO_STATE_DIM >= 7
  s[6] = clip_user(u_prev / PPO_PWM_LIMIT_RUNTIME, -1.0f, 1.0f);
#endif

  float action_norm = PPO_predict_action_norm(s);
  action_norm = clip_user(action_norm, -1.0f, 1.0f);
  return ppo_action_to_pwm(action_norm);
}

// ============================================================
// 采样 ISR
// ============================================================
void control_tick_isr_cb() {
  uint32_t now = dwt_cycles_user();

  static uint32_t last = 0;
  if (last != 0) g_tick_dt_us = cycles_to_us_user(now - last);
  last = now;

  g_t_cmd_cyc = now;

  int pot = analogRead(PIN_POT);
  int32_t enc = g_enc;

  g_pot_raw = (int16_t)pot;
  g_enc_raw = enc;

  int32_t enc0 = ENC_ZERO;
  g_theta_meas = (float)(enc - enc0) * THETA_SCALE;

  float alpha_branch = alphaFromPotRawBranchCutAtDown(pot);
  g_alpha_meas = alpha_branch;
  g_alpha_meas_obs = alpha_branch;

  g_tick_flag = true;
}

// ============================================================
// 串口命令
// ============================================================
static inline void handle_line(const String& s) {
  String t = s;
  t.trim();
  if (t.length() == 0) return;

  if (t == "GO") {
    noInterrupts();

    ENC_ZERO = g_enc;
    g_step = 0;
    g_arm_step = 0;
    g_fallen = false;
    g_u_prev = 0.0f;
    g_pwm_cmd = 0;
    g_brake = false;
    g_armed = true;
    g_obs_inited = false;
    g_ppo_mode = false;

    g_diff_vel_inited = false;
    g_theta_prev_meas = 0.0f;
    g_alpha_prev_meas = 0.0f;
    g_thetaDot_diff_lpf = 0.0f;
    g_alphaDot_diff_lpf = 0.0f;

    g_alpha_unwrap_inited = false;
    g_alpha_cont = 0.0f;
    g_alpha_cont_ref = 0.0f;

    g_spin_cooldown_active = false;
    g_spin_cooldown_left = 0;

    interrupts();

    Serial.print("[ARMED] ENC_ZERO=");
    Serial.println((long)ENC_ZERO);
    return;
  }

  if (t == "S") {
    noInterrupts();

    g_armed = false;
    g_pwm_cmd = 0;
    g_brake = true;
    g_u_prev = 0.0f;
    g_obs_inited = false;
    g_ppo_mode = false;

    g_diff_vel_inited = false;
    g_thetaDot_diff_lpf = 0.0f;
    g_alphaDot_diff_lpf = 0.0f;

    g_alpha_unwrap_inited = false;
    g_alpha_cont = 0.0f;
    g_alpha_cont_ref = 0.0f;

    g_spin_cooldown_active = false;
    g_spin_cooldown_left = 0;

    interrupts();

    motorBrake();
    Serial.println("[STOP]");
    return;
  }

  if (t.startsWith("PREF=")) {
    int v = t.substring(5).toInt();
    if (v >= 0 && v <= 4095) {
      POT_ZERO = v;
      Serial.print("[OK] POT_ZERO=");
      Serial.println((int)POT_ZERO);
    }
    return;
  }

  if (t.startsWith("PDOWN=")) {
    int v = t.substring(6).toInt();
    if (v >= 0 && v <= 4095) {
      POT_DOWN_RAW = v;
      Serial.print("[OK] POT_DOWN_RAW=");
      Serial.println((int)POT_DOWN_RAW);
    }
    return;
  }

  if (t.startsWith("EREF=")) {
    long v = t.substring(5).toInt();
    ENC_ZERO = (int32_t)v;
    Serial.print("[OK] ENC_ZERO=");
    Serial.println((long)ENC_ZERO);
    return;
  }
}

HardwareTimer* g_tim = nullptr;

// ============================================================
// setup
// ============================================================
void setup() {
  Serial.begin(921600);
  delay(200);

  pinMode(PIN_POT, INPUT);
  pinMode(PIN_ENC_A, INPUT);
  pinMode(PIN_ENC_B, INPUT);

  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  pinMode(PIN_STBY, OUTPUT);
  pinMode(PIN_PWM, OUTPUT);

  analogReadResolution(12);
  analogWriteResolution(8);

  motorBrake();

  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), isr_enc_a, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), isr_enc_b, CHANGE);

  dwt_init_user();

  g_tim = new HardwareTimer(TIM2);
  g_tim->setOverflow(CTRL_HZ, HERTZ_FORMAT);
  g_tim->attachInterrupt(control_tick_isr_cb);
  g_tim->setInterruptPriority(1, 0);
  g_tim->resume();

  Serial.println("=== HYBRID DEPLOY READY: DQN START + PPO CONTINUOUS STABILIZATION ===");
  Serial.print("[PPO] STATE_DIM = "); Serial.println((int)PPO_STATE_DIM);
  Serial.print("[PPO] ACT_DIM   = "); Serial.println((int)PPO_ACT_DIM);
  Serial.print("[PPO] HEADER_PWM_LIMIT = "); Serial.println(PPO_HEADER_PWM_LIMIT, 3);
  Serial.print("[DQN] STATE_DIM = "); Serial.println((int)DQN_STATE_DIM);
  Serial.print("[DQN] ACT_DIM   = "); Serial.println((int)DQN_ACT_DIM);
  Serial.print("[DEPLOY] PWM_LIMIT_DEPLOY = "); Serial.println((int)PWM_LIMIT_DEPLOY);

  Serial.print("[HYBRID] PPO_ENTER_DEG = "); Serial.println(PPO_ENTER_RAD * 180.0f / PI_F, 2);
  Serial.print("[HYBRID] PPO_EXIT_DEG  = "); Serial.println(PPO_EXIT_RAD * 180.0f / PI_F, 2);

  Serial.print("[PRE] enabled = "); Serial.println(ENABLE_PRE_SWING ? 1 : 0);
  Serial.print("[PRE] PWM1 = "); Serial.println((int)PRE_PWM_1);
  Serial.print("[PRE] PWM2 = "); Serial.println((int)PRE_PWM_2);

  Serial.println("CALIBRATION:");
  Serial.println("  1) rotate arm one turn, read theta, set THETA_CAL_ONE_TURN_MEAS_RAD");
  Serial.println("  2) upright pendulum, read pot raw, set POT_ZERO");
  Serial.println("  3) hanging-down pendulum, read pot raw, set POT_DOWN_RAW");
  Serial.println("COMMANDS: GO / S / PREF=xxxx / PDOWN=xxxx / EREF=xxxx");

  // 必须和你的 Python HEADER 完全一致：16列，不额外输出 obs_mode/controller_mode
  Serial.println("LOG_HEADER,step,tick_dt_us,lat_total_us,lat_compute_us,armed,brake,fallen,pwm,pot,enc,theta,alpha,x0,x1,x2,x3");
}

// ============================================================
// loop
// ============================================================
void loop() {
  if (Serial.available()) {
    String s = Serial.readStringUntil('\n');
    handle_line(s);
  }

  if (!g_tick_flag) return;

  noInterrupts();
  g_tick_flag = false;

  uint32_t t_cmd = g_t_cmd_cyc;
  uint32_t tick_dt_us = g_tick_dt_us;

  int pot = g_pot_raw;
  int32_t enc = g_enc_raw;

  float theta = g_theta_meas;
  float alpha = g_alpha_meas;
  float alpha_obs = g_alpha_meas_obs;

  bool armed = g_armed;
  float u_prev = g_u_prev;

  float xhat_local[4] = {g_xhat[0], g_xhat[1], g_xhat[2], g_xhat[3]};

  bool obs_inited = g_obs_inited;
  uint32_t arm_step = g_arm_step;

  bool diff_vel_inited = g_diff_vel_inited;
  float theta_prev_meas = g_theta_prev_meas;
  float alpha_prev_meas = g_alpha_prev_meas;
  float thetaDot_diff_lpf = g_thetaDot_diff_lpf;
  float alphaDot_diff_lpf = g_alphaDot_diff_lpf;

  bool ppo_mode = g_ppo_mode;

  bool alpha_unwrap_inited = g_alpha_unwrap_inited;
  float alpha_cont = g_alpha_cont;
  float alpha_cont_ref = g_alpha_cont_ref;

  bool spin_cooldown_active = g_spin_cooldown_active;
  uint32_t spin_cooldown_left = g_spin_cooldown_left;
  interrupts();

  uint32_t t0 = dwt_cycles_user();

  // ======================================================
  // 差分 + 低通速度估计
  // ======================================================
  float thetaDot_diff = 0.0f;
  float alphaDot_diff = 0.0f;
  float dalpha_wrapped = 0.0f;

  if (!diff_vel_inited) {
    theta_prev_meas = theta;
    alpha_prev_meas = alpha;
    thetaDot_diff_lpf = 0.0f;
    alphaDot_diff_lpf = 0.0f;
    diff_vel_inited = true;
    dalpha_wrapped = 0.0f;
  } else {
    float thetaDot_raw = (theta - theta_prev_meas) / DT_CTRL;
    dalpha_wrapped = wrapToPiUser(alpha - alpha_prev_meas);
    float alphaDot_raw = dalpha_wrapped / DT_CTRL;

    thetaDot_diff_lpf =
        (1.0f - VEL_DIFF_LPF) * thetaDot_diff_lpf
        + VEL_DIFF_LPF * thetaDot_raw;

    alphaDot_diff_lpf =
        (1.0f - VEL_DIFF_LPF) * alphaDot_diff_lpf
        + VEL_DIFF_LPF * alphaDot_raw;

    theta_prev_meas = theta;
    alpha_prev_meas = alpha;
  }

  thetaDot_diff = thetaDot_diff_lpf;
  alphaDot_diff = alphaDot_diff_lpf;

  if (USE_OBS_VEL_CLIP) {
    thetaDot_diff = clip_user(thetaDot_diff, -THETA_DOT_OBS_LIMIT, THETA_DOT_OBS_LIMIT);
    alphaDot_diff = clip_user(alphaDot_diff, -ALPHA_DOT_OBS_LIMIT, ALPHA_DOT_OBS_LIMIT);
  }

  // ======================================================
  // alpha 连续展开角：风火轮保护
  // ======================================================
  if (!alpha_unwrap_inited) {
    alpha_cont = alpha;
    alpha_cont_ref = alpha;
    alpha_unwrap_inited = true;
  } else {
    alpha_cont += dalpha_wrapped;
  }

  if (!armed) {
    obs_init_from_meas(theta, alpha_obs, xhat_local);
    motorBrake();

    noInterrupts();
    g_pwm_cmd = 0;
    g_brake = true;
    g_u_prev = 0.0f;
    g_xhat[0] = xhat_local[0];
    g_xhat[1] = xhat_local[1];
    g_xhat[2] = xhat_local[2];
    g_xhat[3] = xhat_local[3];
    g_obs_inited = false;
    g_diff_vel_inited = false;
    g_theta_prev_meas = theta;
    g_alpha_prev_meas = alpha;
    g_thetaDot_diff_lpf = 0.0f;
    g_alphaDot_diff_lpf = 0.0f;
    g_ppo_mode = false;
    g_alpha_unwrap_inited = false;
    g_alpha_cont = 0.0f;
    g_alpha_cont_ref = 0.0f;
    g_spin_cooldown_active = false;
    g_spin_cooldown_left = 0;
    interrupts();

  } else {
    // 观测器始终更新
    if (!obs_inited) {
      obs_init_from_meas(theta, alpha_obs, xhat_local);
      obs_inited = true;
    } else {
      obs_update_one_step(u_prev, theta, alpha_obs, xhat_local);
    }

    arm_step++;

    // 风火轮保护触发判定
    bool spin_protect_armed = true;
    if (SPIN_PROTECT_AFTER_PRE_SWING_ONLY) {
      spin_protect_armed = (arm_step > (PRE_SWING_STEPS_1 + PRE_SWING_STEPS_2));
    }

    if ((!spin_cooldown_active) && ENABLE_SPIN_PROTECT && spin_protect_armed) {
      float spin_excursion = fabsf(alpha_cont - alpha_cont_ref);
      if (spin_excursion >= SPIN_PROTECT_MAX_EXCURSION_RAD) {
        spin_cooldown_active = true;
        spin_cooldown_left = SPIN_PROTECT_COOLDOWN_STEPS;
        alpha_cont_ref = alpha_cont;
        ppo_mode = false;
        Serial.println("[PROTECT] SPIN_RUNAWAY_COOLDOWN_START");
      }
    }

    if (fabsf(alpha) > ALPHA_LIM) {
      motorBrake();

      noInterrupts();
      g_pwm_cmd = 0;
      g_brake = true;
      g_u_prev = 0.0f;
      g_armed = false;
      g_fallen = true;
      g_obs_inited = false;
      g_ppo_mode = false;
      g_alpha_unwrap_inited = false;
      g_alpha_cont = 0.0f;
      g_alpha_cont_ref = 0.0f;
      g_spin_cooldown_active = false;
      g_spin_cooldown_left = 0;
      interrupts();

    } else if (spin_cooldown_active) {
      motorDriveSigned(0);

      if (spin_cooldown_left > 0) spin_cooldown_left--;
      if (spin_cooldown_left == 0) {
        spin_cooldown_active = false;
        alpha_cont_ref = alpha_cont;
        ppo_mode = false;
        Serial.println("[PROTECT] SPIN_RUNAWAY_COOLDOWN_END");
      }

      noInterrupts();
      g_pwm_cmd = 0;
      g_brake = false;
      g_u_prev = 0.0f;
      g_obs_inited = obs_inited;
      g_arm_step = arm_step;
      g_diff_vel_inited = diff_vel_inited;
      g_theta_prev_meas = theta_prev_meas;
      g_alpha_prev_meas = alpha_prev_meas;
      g_thetaDot_diff_lpf = thetaDot_diff_lpf;
      g_alphaDot_diff_lpf = alphaDot_diff_lpf;
      g_ppo_mode = ppo_mode;
      g_alpha_unwrap_inited = alpha_unwrap_inited;
      g_alpha_cont = alpha_cont;
      g_alpha_cont_ref = alpha_cont_ref;
      g_spin_cooldown_active = spin_cooldown_active;
      g_spin_cooldown_left = spin_cooldown_left;
      interrupts();

    } else {
      // ======================================================
      // Hybrid controller：预起摆 -> DQN -> PPO
      // ======================================================
      int16_t pwm_model = 0;

      if (ENABLE_PRE_SWING && arm_step <= PRE_SWING_STEPS_1) {
        pwm_model = clamp_pwm_deploy_int16(PRE_PWM_1);
        ppo_mode = false;
      } else if (ENABLE_PRE_SWING && arm_step <= (PRE_SWING_STEPS_1 + PRE_SWING_STEPS_2)) {
        pwm_model = clamp_pwm_deploy_int16(PRE_PWM_2);
        ppo_mode = false;
      } else {
        bool ppo_prev = ppo_mode;
        float abs_alpha = fabsf(alpha);

        // DQN -> PPO：进入15度
        if (!ppo_mode && abs_alpha <= PPO_ENTER_RAD) {
          ppo_mode = true;
        }
        // PPO -> DQN：甩出25度
        else if (ppo_mode && abs_alpha >= PPO_EXIT_RAD) {
          ppo_mode = false;
        }

        if ((!ppo_prev) && ppo_mode && RESET_OBSERVER_WHEN_ENTER_PPO) {
          obs_init_from_meas(theta, alpha_obs, xhat_local);
        }

        if (ppo_mode) {
          float theta_use = theta;
          float theta_dot_use = thetaDot_diff;
          float alpha_use = alpha;
          float alpha_dot_use = alphaDot_diff;

          if (ENABLE_OBSERVER_FOR_PPO) {
            theta_use = xhat_local[0];
            theta_dot_use = xhat_local[1];
            alpha_use = xhat_local[2];
            alpha_dot_use = xhat_local[3];
          }

          if (USE_OBS_VEL_CLIP) {
            theta_dot_use = clip_user(theta_dot_use, -THETA_DOT_OBS_LIMIT, THETA_DOT_OBS_LIMIT);
            alpha_dot_use = clip_user(alpha_dot_use, -ALPHA_DOT_OBS_LIMIT, ALPHA_DOT_OBS_LIMIT);
          }

          float theta_policy = THETA_OBS_SIGN * theta_use;
          float theta_dot_policy = THETA_OBS_SIGN * theta_dot_use;
          float alpha_policy = wrapToPiUser(ALPHA_OBS_SIGN * alpha_use);
          float alpha_dot_policy = ALPHA_OBS_SIGN * alpha_dot_use;

          pwm_model = ppo_policy_pwm(
              theta_policy,
              theta_dot_policy,
              alpha_policy,
              alpha_dot_policy,
              u_prev);

        } else {
          float theta_policy = THETA_OBS_SIGN * theta;
          float theta_dot_policy = THETA_OBS_SIGN * thetaDot_diff;
          float alpha_policy = wrapToPiUser(ALPHA_OBS_SIGN * alpha);
          float alpha_dot_policy = ALPHA_OBS_SIGN * alphaDot_diff;

          pwm_model = dqn_policy_pwm(
              theta_policy,
              theta_dot_policy,
              alpha_policy,
              alpha_dot_policy);
        }
      }

      pwm_model = clamp_pwm_deploy_int16(pwm_model);

      int16_t pwm_motor = (int16_t)lroundf(MOTOR_PWM_SIGN * (float)pwm_model);
      pwm_motor = clamp_pwm_deploy_int16(pwm_motor);

      motorDriveSigned(pwm_motor);

      noInterrupts();
      g_pwm_cmd = pwm_motor;
      g_brake = false;
      g_u_prev = (float)pwm_model;
      g_obs_inited = obs_inited;
      g_arm_step = arm_step;
      g_diff_vel_inited = diff_vel_inited;
      g_theta_prev_meas = theta_prev_meas;
      g_alpha_prev_meas = alpha_prev_meas;
      g_thetaDot_diff_lpf = thetaDot_diff_lpf;
      g_alphaDot_diff_lpf = alphaDot_diff_lpf;
      g_ppo_mode = ppo_mode;
      g_alpha_unwrap_inited = alpha_unwrap_inited;
      g_alpha_cont = alpha_cont;
      g_alpha_cont_ref = alpha_cont_ref;
      g_spin_cooldown_active = spin_cooldown_active;
      g_spin_cooldown_left = spin_cooldown_left;
      interrupts();
    }

    noInterrupts();
    g_xhat[0] = xhat_local[0];
    g_xhat[1] = xhat_local[1];
    g_xhat[2] = xhat_local[2];
    g_xhat[3] = xhat_local[3];
    interrupts();
  }

  uint32_t t1 = dwt_cycles_user();
  uint32_t lat_comp  = cycles_to_us_user(t1 - t0);
  uint32_t lat_total = cycles_to_us_user(dwt_cycles_user() - t_cmd);

  noInterrupts();
  g_lat_comp_us = lat_comp;
  g_lat_total_us = lat_total;
  g_step++;

  uint32_t step = g_step;
  bool armed2  = g_armed;
  bool brake2  = g_brake;
  bool fallen2 = g_fallen;
  int  cmd     = g_pwm_cmd;

  float hx0 = g_xhat[0];
  float hx1 = g_xhat[1];
  float hx2 = g_xhat[2];
  float hx3 = g_xhat[3];
  interrupts();

  // 必须严格匹配 Python HEADER：
  // step,tick_dt_us,lat_total_us,lat_compute_us,armed,brake,fallen,
  // pwm,pot,enc,theta,alpha,x0,x1,x2,x3
  Serial.print("LOG,");
  Serial.print(step);       Serial.print(",");
  Serial.print(tick_dt_us); Serial.print(",");
  Serial.print(lat_total);  Serial.print(",");
  Serial.print(lat_comp);   Serial.print(",");
  Serial.print(armed2 ? 1 : 0);  Serial.print(",");
  Serial.print(brake2 ? 1 : 0);  Serial.print(",");
  Serial.print(fallen2 ? 1 : 0); Serial.print(",");
  Serial.print(cmd);        Serial.print(",");
  Serial.print(pot);        Serial.print(",");
  Serial.print(enc);        Serial.print(",");
  Serial.print(theta, 6);   Serial.print(",");
  Serial.print(alpha, 6);   Serial.print(",");
  Serial.print(hx0, 6);     Serial.print(",");
  Serial.print(hx1, 6);     Serial.print(",");
  Serial.print(hx2, 6);     Serial.print(",");
  Serial.println(hx3, 6);
}
