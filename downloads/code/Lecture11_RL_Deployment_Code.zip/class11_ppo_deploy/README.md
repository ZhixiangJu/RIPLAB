# Class 11 PPO deployment package

Files:
- `deploy_ppo.ino`: STM32 firmware for PPO deployment.
- `deploy_ppo.py`: PC-side serial logger and GO command sender.

Required model header file(s):
- `ppo_model_weights.h`
- `dqn_model_weights.h`

Place the required model header file(s) in the same Arduino sketch folder before compiling.

Deployment mode:
Provided PPO deployment is a hybrid version: DQN is used for the large-angle approach and PPO is used near the upright region. If students use a pure balance-only PPO, manually hold the pendulum near upright before pressing Enter.

Basic workflow:
1. Calibrate the potentiometer zero value `POT_ZERO`.
2. Put the model header file(s) beside `deploy_ppo.ino`.
3. Upload firmware to STM32.
4. Close Arduino Serial Monitor.
5. Run `python deploy_ppo.py`.
6. Press Enter in the terminal to send `GO`.
7. The script records logs to the local `logs/` folder.

Safety:
- Check wiring and common ground before connecting motor power.
- Keep fingers away from the rotating arm.
- Be ready to stop the program or cut motor power if the pendulum behaves abnormally.
