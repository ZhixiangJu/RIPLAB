import os, sys, time, csv, glob
import serial  # pyserial

OUT_PATH = os.path.join(os.path.dirname(__file__), "logs", "deploy_dqn_log.csv")
BAUD = 921600
MAX_STEPS =20000

HEADER = [
    "step","tick_dt_us","lat_total_us","lat_compute_us",
    "armed","brake","fallen",
    "pwm","pot","enc","theta","alpha","x0","x1","x2","x3"
]

def find_port_auto():
    plat = sys.platform.lower()
    cands = []
    if "darwin" in plat:
        cands += sorted(glob.glob("/dev/cu.usbmodem*"))
        cands += sorted(glob.glob("/dev/cu.usbserial*"))
    elif "linux" in plat:
        cands += sorted(glob.glob("/dev/ttyACM*"))
        cands += sorted(glob.glob("/dev/ttyUSB*"))
    else:
        return ""
    cands = list(dict.fromkeys(cands))
    if not cands:
        return ""
    if len(cands) == 1:
        return cands[0]
    print("Multiple ports found, auto-pick first:")
    for i,p in enumerate(cands):
        print(f"  [{i}] {p}")
    return cands[0]

def main():
    port = sys.argv[1] if len(sys.argv) >= 2 else ""
    if not port:
        port = find_port_auto()
    if not port:
        print("[ERR] No serial port found. Try: ls /dev/cu.usbmodem* /dev/cu.usbserial*")
        sys.exit(1)

    print(f"[OK] Port={port} Baud={BAUD}")
    try:
        ser = serial.Serial(port, BAUD, timeout=1)
    except Exception as e:
        print(f"[ERR] Open serial failed: {e}")
        print("Tip: close Arduino Serial Monitor / other apps occupying the port.")
        sys.exit(1)

    time.sleep(0.2)
    ser.reset_input_buffer()

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with open(OUT_PATH, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["# start_time", time.strftime("%Y-%m-%d %H:%M:%S")])
        w.writerow(["# port", port])
        w.writerow(["# baud", BAUD])
        w.writerow(["# max_steps", MAX_STEPS])
        w.writerow(HEADER)
        f.flush()

        print(f"[OK] Logging to {OUT_PATH}")
        print("1) 把摆臂自然下垂（准备让模型自行起摆并稳定）")
        input("2) 按回车开始（将自动发送 GO）...")

        ser.write(b"GO\n")
        ser.flush()
        print("[SENT] GO, waiting for [ARMED]...")

        t_wait = time.time()
        armed_ok = False
        while time.time() - t_wait < 3.0:
            line = ser.readline().decode(errors="ignore").strip()
            if not line:
                continue
            if "[ARMED]" in line:
                print(line)
                armed_ok = True
                break
        if not armed_ok:
            print("[ERR] Did not receive [ARMED]. Check baud matches STM and port is correct.")
            ser.close()
            sys.exit(1)

        print("[OK] ARMED confirmed. Start logging...")

        logged = 0
        start_time = time.time()

        try:
            while True:
                line = ser.readline().decode(errors="ignore").strip()
                if not line:
                    continue

                if line.startswith("LOG,"):
                    parts = line.split(",")[1:]
                    if len(parts) != len(HEADER):
                        continue

                    try:
                        step = int(parts[0])
                        fallen = int(parts[6])
                    except Exception:
                        continue

                    w.writerow(parts)
                    logged += 1

                    if logged % 50 == 0:
                        f.flush()

                    if fallen == 1:
                        print(f"[STOP] Fallen detected at step={step}. Sending S.")
                        ser.write(b"S\n"); ser.flush()
                        break

                    if logged >= MAX_STEPS:
                        print(f"[DONE] Logged {logged} steps. Sending S.")
                        ser.write(b"S\n"); ser.flush()
                        break

        except KeyboardInterrupt:
            print("\n[INTERRUPT] Ctrl+C. Sending S.")
            try:
                ser.write(b"S\n"); ser.flush()
            except Exception:
                pass

        dt = time.time() - start_time
        f.flush()
        ser.close()
        print(f"[OK] Saved {OUT_PATH}")
        print(f"[OK] Logged={logged} duration={dt:.2f}s (~{logged/dt:.1f} Hz)")

if __name__ == "__main__":
    main()