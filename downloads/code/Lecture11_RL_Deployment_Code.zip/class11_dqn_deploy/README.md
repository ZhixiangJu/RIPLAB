# Class 11 DQN deployment package

Files:
- `deploy_dqn.ino`: STM32 firmware for DQN deployment.
- `deploy_dqn.py`: PC-side serial logger and GO command sender.

Required model header file(s):
- `model_weights.h`

Place the required model header file(s) in the same Arduino sketch folder before compiling.

Deployment mode:
Provided DQN deployment is intended to start from the natural hanging-down state and perform autonomous large-angle control. If students replace it with a balance-only DQN, manually hold the pendulum near upright before pressing Enter.

Basic workflow:
1. Calibrate the potentiometer zero value `POT_ZERO`.
2. Put the model header file(s) beside `deploy_dqn.ino`.
3. Upload firmware to STM32.
4. Close Arduino Serial Monitor.
5. Run `python deploy_dqn.py`.
6. Press Enter in the terminal to send `GO`.
7. The script records logs to the local `logs/` folder.

Safety:
- Check wiring and common ground before connecting motor power.
- Keep fingers away from the rotating arm.
- Be ready to stop the program or cut motor power if the pendulum behaves abnormally.
