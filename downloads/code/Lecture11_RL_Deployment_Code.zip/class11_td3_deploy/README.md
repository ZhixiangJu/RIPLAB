# Class 11 TD3 deployment package

Files:
- `deploy_td3.ino`: STM32 firmware for TD3 deployment.
- `deploy_td3.py`: PC-side serial logger and GO command sender.

Required model header file(s):
- `td3_model_weights.h`

Place the required model header file(s) in the same Arduino sketch folder before compiling.

Deployment mode:
Provided TD3 deployment uses a continuous-action actor and includes the initial deployment logic in the firmware. If students use a balance-only TD3 policy, manually hold the pendulum near upright before pressing Enter.

Basic workflow:
1. Calibrate the potentiometer zero value `POT_ZERO`.
2. Put the model header file(s) beside `deploy_td3.ino`.
3. Upload firmware to STM32.
4. Close Arduino Serial Monitor.
5. Run `python deploy_td3.py`.
6. Press Enter in the terminal to send `GO`.
7. The script records logs to the local `logs/` folder.

Safety:
- Check wiring and common ground before connecting motor power.
- Keep fingers away from the rotating arm.
- Be ready to stop the program or cut motor power if the pendulum behaves abnormally.
