#include <Arduino.h>
#include <math.h>
#include <HardwareTimer.h>

// 兼容非法写法 0f / 1f / 2f ... （把它当作 float）
constexpr float operator"" f(unsigned long long v) { return (float)v; }
constexpr float operator"" f(long double v) { return (float)v; }

#include "td3_model_weights.h"

// ============================================================
// TD3 模型头文件检查
// ============================================================

#if !defined(TD3_OBS_DIM) || !defined(TD3_STATE_DIM) || !defined(TD3_ACT_DIM)
  #error "td3_model_weights.h missing required TD3 dimension macros."
#endif

#if !defined(TD3_CONTINUOUS_PWM_LIMIT)
  #error "td3_model_weights.h missing TD3_CONTINUOUS_PWM_LIMIT."
#endif

#if !defined(TD3_L0_IN) || !defined(TD3_L0_OUT) || !defined(TD3_L1_IN) || !defined(TD3_L1_OUT) || !defined(TD3_L2_IN) || !defined(TD3_L2_OUT)
  #error "td3_model_weights.h missing required TD3 layer dimension macros."
#endif

#if TD3_ACT_DIM != 1
  #error "Current TD3 deployment firmware expects TD3_ACT_DIM == 1."
#endif

#if TD3_STATE_DIM != 7
  #error "Current TD3 deployment firmware expects TD3_STATE_DIM == 7."
#endif

// ============================================================
// 引脚定义
// ============================================================
static const int PIN_POT   = A0;
static const int PIN_ENC_A = 2;
static const int PIN_ENC_B = 3;

static const int PIN_IN1  = 4;
static const int PIN_IN2  = 5;
static const int PIN_STBY = 7;
static const int PIN_PWM  = 10;

static const uint32_t CTRL_HZ = 200;
static const float DT_CTRL = 1.0f / (float)CTRL_HZ;

static const float PI_F = 3.14159265358979323846f;
static const int32_t POT_MOD = 4096;
static const float THETA_SIGN = +1.0f;

// ============================================================
// 部署 PWM 总限幅
// 现在所有控制输出最终都会限制在 [-150, 150]
// ============================================================
static const int16_t PWM_LIMIT_DEPLOY = 150;
static const float PWM_LIMIT_DEPLOY_F = 150.0f;

// ============================================================
// 新机器快速部署：只改下面几个量
// ============================================================

static const float THETA_CAL_ONE_TURN_MEAS_RAD = 6.503f;

static volatile int32_t POT_ZERO = 3090;
static volatile int32_t POT_DOWN_RAW = 990;

static const bool POT_CW_DECREASES = true;

static volatile int32_t ENC_ZERO = 10000;

static const float THETA_SCALE_NOMINAL = THETA_SIGN * (PI_F / 520.0f);

static const float THETA_SCALE =
    THETA_SCALE_NOMINAL * ((2.0f * PI_F) / THETA_CAL_ONE_TURN_MEAS_RAD);

static const float ALPHA_LIM = 2.0f * PI_F;

// ============================================================
// 两段式预起摆
// ============================================================
static const bool ENABLE_PRE_SWING = true;
static const int16_t PRE_PWM_1 = 150;
static const int16_t PRE_PWM_2 = -150;
static const uint32_t PRE_SWING_STEPS_1 = 100;
static const uint32_t PRE_SWING_STEPS_2 = 100;

// ============================================================
// 差分速度参数（给 TD3 用）
// ============================================================
static const float VEL_DIFF_LPF = 0.25f;

// ============================================================
// LQR 参数
// ============================================================
static const float K1 = -2.9905f;
static const float K2 = -27.9829f;
static const float K3 = -442.1647f;
static const float K4 = -36.4818f;

// ============================================================
// 切换参数
// ============================================================
static const float UPRIGHT_ENTER_RAD = 0.0f * PI_F / 180.0f;
static const float UPRIGHT_EXIT_RAD  = 0.0f * PI_F / 180.0f;

static const float MIX_LQR_WEIGHT = 10.0f;
static const float MIX_RL_WEIGHT  = 10.0f;

static const bool RESET_OBSERVER_WHEN_ENTER_UPRIGHT = true;

// ============================================================
// 软切换参数
// ============================================================
static const bool  ENABLE_SOFT_SWITCH = true;
static const float SOFT_BLEND_ALPHA = 0.18f;

// ============================================================
// 风火轮保护参数
// ============================================================
static const bool  ENABLE_SPIN_PROTECT = true;
static const float SPIN_PROTECT_MAX_EXCURSION_RAD = 300.0f * PI_F / 180.0f;
static const bool  SPIN_PROTECT_AFTER_PRE_SWING_ONLY = true;
static const uint32_t SPIN_PROTECT_COOLDOWN_STEPS = 200;

// ============================================================
// 全局状态
// ============================================================
static volatile int32_t g_enc = 10000;

static volatile bool g_armed = false;
static volatile bool g_tick_flag = false;
static volatile bool g_fallen = false;

static volatile int16_t  g_pot_raw = 0;
static volatile int32_t  g_enc_raw = 10000;

static volatile float g_theta_meas = 0.0f;
static volatile float g_alpha_meas = 0.0f;
static volatile float g_alpha_meas_obs = 0.0f;

static volatile float g_xhat[4] = {0, 0, 0, 0};
static volatile float g_u_prev = 0.0f;

static volatile int16_t g_pwm_cmd = 0;
static volatile bool    g_brake = true;

static volatile uint32_t g_t_cmd_cyc = 0;
static volatile uint32_t g_tick_dt_us = 0;
static volatile uint32_t g_lat_total_us = 0;
static volatile uint32_t g_lat_comp_us = 0;

static volatile uint32_t g_step = 0;
static volatile bool g_obs_inited = false;

static volatile uint32_t g_arm_step = 0;

static volatile bool  g_diff_vel_inited = false;
static volatile float g_theta_prev_meas = 0.0f;
static volatile float g_alpha_prev_meas = 0.0f;
static volatile float g_thetaDot_diff_lpf = 0.0f;
static volatile float g_alphaDot_diff_lpf = 0.0f;

static volatile bool  g_upright_mode = false;
static volatile float g_upright_blend = 0.0f;

static volatile bool  g_alpha_unwrap_inited = false;
static volatile float g_alpha_cont = 0.0f;
static volatile float g_alpha_cont_ref = 0.0f;

static volatile bool     g_spin_cooldown_active = false;
static volatile uint32_t g_spin_cooldown_left = 0;

// ============================================================
// DWT 计时
// ============================================================
static inline void dwt_init_user() {
#if defined(DWT)
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
#endif
}

static inline uint32_t dwt_cycles_user() {
#if defined(DWT)
  return DWT->CYCCNT;
#else
  return 0;
#endif
}

static inline uint32_t cycles_to_us_user(uint32_t cyc) {
  return (uint32_t)((uint64_t)cyc * 1000000ULL / (uint64_t)F_CPU);
}

// ============================================================
// 工具函数
// ============================================================
static inline int32_t mod4096(int32_t x) {
  x %= POT_MOD;
  if (x < 0) x += POT_MOD;
  return x;
}

static inline float wrapToPiUser(float x) {
  while (x > PI_F)  x -= 2.0f * PI_F;
  while (x < -PI_F) x += 2.0f * PI_F;
  return x;
}

static inline float relu_user(float x) {
  return (x > 0.0f) ? x : 0.0f;
}

static inline float clampf_user(float x, float lo, float hi) {
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}

static inline int16_t clamp_pwm_deploy_int16(int16_t x) {
  if (x > PWM_LIMIT_DEPLOY) return PWM_LIMIT_DEPLOY;
  if (x < -PWM_LIMIT_DEPLOY) return -PWM_LIMIT_DEPLOY;
  return x;
}

static inline float clamp_pwm_deploy_float(float x) {
  if (x > PWM_LIMIT_DEPLOY_F) return PWM_LIMIT_DEPLOY_F;
  if (x < -PWM_LIMIT_DEPLOY_F) return -PWM_LIMIT_DEPLOY_F;
  return x;
}

static inline int32_t cwDistCounts(int32_t ref, int32_t x) {
  ref = mod4096(ref);
  x   = mod4096(x);

  if (POT_CW_DECREASES) {
    return mod4096(ref - x);
  } else {
    return mod4096(x - ref);
  }
}

static inline float alphaFromPotRawBranchCutAtDown(int32_t pot_raw) {
  const int32_t up = mod4096(POT_ZERO);
  const int32_t dn = mod4096(POT_DOWN_RAW);
  const int32_t x  = mod4096(pot_raw);

  int32_t cw_to_down = cwDistCounts(up, dn);
  if (cw_to_down <= 0 || cw_to_down >= POT_MOD) {
    return 0.0f;
  }

  int32_t cw_to_x = cwDistCounts(up, x);

  if (cw_to_x <= cw_to_down) {
    return PI_F * ((float)cw_to_x / (float)cw_to_down);
  }

  int32_t rem = POT_MOD - cw_to_down;
  if (rem <= 0) return 0.0f;

  return -PI_F * ((float)(POT_MOD - cw_to_x) / (float)rem);
}

// ============================================================
// 电机控制
// ============================================================
static inline void motorStandby(bool standby) {
  digitalWrite(PIN_STBY, standby ? LOW : HIGH);
}

static inline void motorBrake() {
  digitalWrite(PIN_IN1, HIGH);
  digitalWrite(PIN_IN2, HIGH);
  analogWrite(PIN_PWM, 0);
  motorStandby(true);
}

static inline void motorDriveSigned(int16_t pwm_signed) {
  int16_t p = clamp_pwm_deploy_int16(pwm_signed);

  motorStandby(false);

  if (p == 0) {
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, LOW);
    analogWrite(PIN_PWM, 0);
    return;
  }

  if (p > 0) {
    digitalWrite(PIN_IN1, HIGH);
    digitalWrite(PIN_IN2, LOW);
    analogWrite(PIN_PWM, (uint8_t)p);
  } else {
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, HIGH);
    analogWrite(PIN_PWM, (uint8_t)(-p));
  }
}

// ============================================================
// 编码器中断
// ============================================================
void isr_enc_a() {
  bool A = digitalRead(PIN_ENC_A);
  bool B = digitalRead(PIN_ENC_B);
  if (A) g_enc += (B ? 1 : -1);
  else   g_enc += (B ? -1 : 1);
}

void isr_enc_b() {
  bool A = digitalRead(PIN_ENC_A);
  bool B = digitalRead(PIN_ENC_B);
  if (B) g_enc += (A ? -1 : 1);
  else   g_enc += (A ? 1 : -1);
}

// ============================================================
// 观测器参数
// ============================================================
static const float OBS_Ad[4][4] = {
  { 0.82469568f,  0.00438721f, -0.31915638f, -0.00085553f },
  { -1.75095359f, 0.94056709f, -0.04181246f,  0.00193564f },
  { -0.05215683f, 0.00005656f,  0.76549687f,  0.00439733f },
  { -1.38405407f, 0.07685667f, -15.83946960f, 0.95027468f },
};

static const float OBS_Bd_u[4] = {
   0.00001119f,
   0.00396389f,
  -0.00001398f,
  -0.00583846f
};

static const float OBS_Bd_y[4][2] = {
  { 0.17530432f,  0.31833008f },
  { 1.75095359f, -0.19974721f },
  { 0.05215683f,  0.23646539f },
  { 1.38405407f, 16.66931771f },
};

static const float VEL_CLIP = 500.0f;
static const float OBS_RESET_ERR_LIM = 35.0f * PI_F / 180.0f;

static inline void obs_init_from_meas(float theta, float alpha, float xhat_local[4]) {
  xhat_local[0] = theta;
  xhat_local[1] = 0.0f;
  xhat_local[2] = alpha;
  xhat_local[3] = 0.0f;
}

static inline void obs_update_one_step(float u_prev, float theta_meas, float alpha_meas, float xhat_local[4]) {
  float y0 = theta_meas;
  float y1 = alpha_meas;

  float xn[4];

  for (int i = 0; i < 4; i++) {
    float s = 0.0f;
    s += OBS_Ad[i][0] * xhat_local[0]
       + OBS_Ad[i][1] * xhat_local[1]
       + OBS_Ad[i][2] * xhat_local[2]
       + OBS_Ad[i][3] * xhat_local[3];
    s += OBS_Bd_u[i] * u_prev;
    s += OBS_Bd_y[i][0] * y0 + OBS_Bd_y[i][1] * y1;
    xn[i] = s;
  }

  if (!isfinite(xn[0]) || !isfinite(xn[1]) || !isfinite(xn[2]) || !isfinite(xn[3])) {
    obs_init_from_meas(y0, y1, xhat_local);
    return;
  }

  if (xn[1] >  VEL_CLIP) xn[1] =  VEL_CLIP;
  if (xn[1] < -VEL_CLIP) xn[1] = -VEL_CLIP;
  if (xn[3] >  VEL_CLIP) xn[3] =  VEL_CLIP;
  if (xn[3] < -VEL_CLIP) xn[3] = -VEL_CLIP;

  if (fabsf(xn[2] - alpha_meas) > OBS_RESET_ERR_LIM) {
    obs_init_from_meas(y0, y1, xhat_local);
    return;
  }

  xhat_local[0] = xn[0];
  xhat_local[1] = xn[1];
  xhat_local[2] = xn[2];
  xhat_local[3] = xn[3];
}

// ============================================================
// TD3 Actor 前向
// ============================================================
static inline int16_t td3_policy_pwm(const float s[TD3_STATE_DIM]) {
  int16_t pwm = TD3_predict_pwm_int16(s);
  pwm = clamp_pwm_deploy_int16(pwm);
  return pwm;
}

// ============================================================
// LQR 控制
// ============================================================
static inline int16_t lqr_control_pwm(float theta, float theta_dot, float alpha, float alpha_dot) {
  float u = -(K1 * theta + K2 * theta_dot + K3 * alpha + K4 * alpha_dot);
  u = clamp_pwm_deploy_float(u);
  return (int16_t)lroundf(u);
}

// ============================================================
// 采样 ISR
// ============================================================
void control_tick_isr_cb() {
  uint32_t now = dwt_cycles_user();

  static uint32_t last = 0;
  if (last != 0) g_tick_dt_us = cycles_to_us_user(now - last);
  last = now;

  g_t_cmd_cyc = now;

  int pot = analogRead(PIN_POT);
  int32_t enc = g_enc;

  g_pot_raw = (int16_t)pot;
  g_enc_raw = enc;

  int32_t enc0 = ENC_ZERO;
  g_theta_meas = (float)(enc - enc0) * THETA_SCALE;

  float alpha_branch = alphaFromPotRawBranchCutAtDown(pot);
  g_alpha_meas = alpha_branch;
  g_alpha_meas_obs = alpha_branch;

  g_tick_flag = true;
}

// ============================================================
// 串口命令
// ============================================================
static inline void handle_line(const String& s) {
  String t = s;
  t.trim();
  if (t.length() == 0) return;

  if (t == "GO") {
    noInterrupts();
    ENC_ZERO = g_enc;
    g_step = 0;
    g_arm_step = 0;
    g_fallen = false;
    g_u_prev = 0.0f;
    g_pwm_cmd = 0;
    g_brake = false;
    g_armed = true;
    g_obs_inited = false;

    g_diff_vel_inited = false;
    g_theta_prev_meas = 0.0f;
    g_alpha_prev_meas = 0.0f;
    g_thetaDot_diff_lpf = 0.0f;
    g_alphaDot_diff_lpf = 0.0f;

    g_upright_mode = false;
    g_upright_blend = 0.0f;

    g_alpha_unwrap_inited = false;
    g_alpha_cont = 0.0f;
    g_alpha_cont_ref = 0.0f;

    g_spin_cooldown_active = false;
    g_spin_cooldown_left = 0;
    interrupts();

    Serial.print("[ARMED] ENC_ZERO=");
    Serial.println((long)ENC_ZERO);
    return;
  }

  if (t == "S") {
    noInterrupts();
    g_armed = false;
    g_pwm_cmd = 0;
    g_brake = true;
    g_u_prev = 0.0f;
    g_obs_inited = false;

    g_diff_vel_inited = false;
    g_thetaDot_diff_lpf = 0.0f;
    g_alphaDot_diff_lpf = 0.0f;

    g_upright_mode = false;
    g_upright_blend = 0.0f;

    g_alpha_unwrap_inited = false;
    g_alpha_cont = 0.0f;
    g_alpha_cont_ref = 0.0f;

    g_spin_cooldown_active = false;
    g_spin_cooldown_left = 0;
    interrupts();

    motorBrake();
    Serial.println("[STOP]");
    return;
  }

  if (t.startsWith("PREF=")) {
    int v = t.substring(5).toInt();
    if (v >= 0 && v <= 4095) {
      POT_ZERO = v;
      Serial.print("[OK] POT_ZERO=");
      Serial.println((int)POT_ZERO);
    }
    return;
  }

  if (t.startsWith("PDOWN=")) {
    int v = t.substring(6).toInt();
    if (v >= 0 && v <= 4095) {
      POT_DOWN_RAW = v;
      Serial.print("[OK] POT_DOWN_RAW=");
      Serial.println((int)POT_DOWN_RAW);
    }
    return;
  }

  if (t.startsWith("EREF=")) {
    long v = t.substring(5).toInt();
    ENC_ZERO = (int32_t)v;
    Serial.print("[OK] ENC_ZERO=");
    Serial.println((long)ENC_ZERO);
    return;
  }
}

HardwareTimer* g_tim = nullptr;

// ============================================================
// setup
// ============================================================
void setup() {
  Serial.begin(921600);
  delay(200);

  pinMode(PIN_POT, INPUT);
  pinMode(PIN_ENC_A, INPUT);
  pinMode(PIN_ENC_B, INPUT);

  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  pinMode(PIN_STBY, OUTPUT);
  pinMode(PIN_PWM, OUTPUT);

  analogReadResolution(12);
  analogWriteResolution(8);

  motorBrake();

  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), isr_enc_a, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), isr_enc_b, CHANGE);

  dwt_init_user();

  g_tim = new HardwareTimer(TIM2);
  g_tim->setOverflow(CTRL_HZ, HERTZ_FORMAT);
  g_tim->attachInterrupt(control_tick_isr_cb);
  g_tim->setInterruptPriority(1, 0);
  g_tim->resume();

  Serial.println("=== TD3 + OBSERVER-LQR + SOFT_SWITCH + SPIN_PROTECT READY ===");
  Serial.print("[MODEL] STATE_DIM = "); Serial.println((int)TD3_STATE_DIM);
  Serial.print("[MODEL] H1        = "); Serial.println((int)TD3_L0_OUT);
  Serial.print("[MODEL] H2        = "); Serial.println((int)TD3_L1_OUT);
  Serial.print("[MODEL] ACT_DIM   = "); Serial.println((int)TD3_ACT_DIM);
  Serial.print("[MODEL] HEADER_PWM_LIMIT = "); Serial.println((float)TD3_CONTINUOUS_PWM_LIMIT, 3);
  Serial.print("[DEPLOY] PWM_LIMIT_DEPLOY = "); Serial.println((int)PWM_LIMIT_DEPLOY);
  Serial.println("[MODEL] obs = [sin(theta), cos(theta), theta_dot, sin(alpha), cos(alpha), alpha_dot, last_action_norm]");
  Serial.println("CALIBRATION:");
  Serial.println("  1) rotate arm one turn, read theta, set THETA_CAL_ONE_TURN_MEAS_RAD");
  Serial.println("  2) upright pendulum, read pot raw, set POT_ZERO");
  Serial.println("  3) hanging-down pendulum, read pot raw, set POT_DOWN_RAW");
  Serial.println("COMMANDS: GO / S / PREF=xxxx / PDOWN=xxxx / EREF=xxxx");
  Serial.println("LOG_HEADER,step,tick_dt_us,lat_total_us,lat_compute_us,armed,brake,fallen,pwm,pot,enc,theta,alpha,x0,x1,x2,x3");
}

// ============================================================
// loop
// ============================================================
void loop() {
  if (Serial.available()) {
    String s = Serial.readStringUntil('\n');
    handle_line(s);
  }

  if (!g_tick_flag) return;

  noInterrupts();
  g_tick_flag = false;

  uint32_t t_cmd = g_t_cmd_cyc;
  uint32_t tick_dt_us = g_tick_dt_us;

  int pot = g_pot_raw;
  int32_t enc = g_enc_raw;

  float theta = g_theta_meas;
  float alpha = g_alpha_meas;
  float alpha_obs = g_alpha_meas_obs;

  bool armed = g_armed;

  float u_prev = g_u_prev;
  float xhat_local[4] = { g_xhat[0], g_xhat[1], g_xhat[2], g_xhat[3] };
  bool obs_inited = g_obs_inited;
  uint32_t arm_step = g_arm_step;

  bool diff_vel_inited = g_diff_vel_inited;
  float theta_prev_meas = g_theta_prev_meas;
  float alpha_prev_meas = g_alpha_prev_meas;
  float thetaDot_diff_lpf = g_thetaDot_diff_lpf;
  float alphaDot_diff_lpf = g_alphaDot_diff_lpf;

  bool upright_mode = g_upright_mode;
  float upright_blend = g_upright_blend;

  bool alpha_unwrap_inited = g_alpha_unwrap_inited;
  float alpha_cont = g_alpha_cont;
  float alpha_cont_ref = g_alpha_cont_ref;

  bool spin_cooldown_active = g_spin_cooldown_active;
  uint32_t spin_cooldown_left = g_spin_cooldown_left;
  interrupts();

  uint32_t t0 = dwt_cycles_user();

  // ======================================================
  // 差分 + 低通速度估计
  // ======================================================
  float thetaDot_diff = 0.0f;
  float alphaDot_diff = 0.0f;
  float dalpha_wrapped = 0.0f;

  if (!diff_vel_inited) {
    theta_prev_meas = theta;
    alpha_prev_meas = alpha;
    thetaDot_diff_lpf = 0.0f;
    alphaDot_diff_lpf = 0.0f;
    diff_vel_inited = true;
    dalpha_wrapped = 0.0f;
  } else {
    float thetaDot_raw = (theta - theta_prev_meas) / DT_CTRL;
    dalpha_wrapped = wrapToPiUser(alpha - alpha_prev_meas);
    float alphaDot_raw = dalpha_wrapped / DT_CTRL;

    thetaDot_diff_lpf = (1.0f - VEL_DIFF_LPF) * thetaDot_diff_lpf + VEL_DIFF_LPF * thetaDot_raw;
    alphaDot_diff_lpf = (1.0f - VEL_DIFF_LPF) * alphaDot_diff_lpf + VEL_DIFF_LPF * alphaDot_raw;

    theta_prev_meas = theta;
    alpha_prev_meas = alpha;
  }

  thetaDot_diff = thetaDot_diff_lpf;
  alphaDot_diff = alphaDot_diff_lpf;

  // ======================================================
  // alpha 连续展开角
  // ======================================================
  if (!alpha_unwrap_inited) {
    alpha_cont = alpha;
    alpha_cont_ref = alpha;
    alpha_unwrap_inited = true;
  } else {
    alpha_cont += dalpha_wrapped;
  }

  if (!armed) {
    obs_init_from_meas(theta, alpha_obs, xhat_local);
    motorBrake();

    noInterrupts();
    g_pwm_cmd = 0;
    g_brake = true;
    g_u_prev = 0.0f;

    g_xhat[0] = xhat_local[0];
    g_xhat[1] = xhat_local[1];
    g_xhat[2] = xhat_local[2];
    g_xhat[3] = xhat_local[3];

    g_obs_inited = false;

    g_diff_vel_inited = false;
    g_theta_prev_meas = theta;
    g_alpha_prev_meas = alpha;
    g_thetaDot_diff_lpf = 0.0f;
    g_alphaDot_diff_lpf = 0.0f;

    g_upright_mode = false;
    g_upright_blend = 0.0f;

    g_alpha_unwrap_inited = false;
    g_alpha_cont = 0.0f;
    g_alpha_cont_ref = 0.0f;

    g_spin_cooldown_active = false;
    g_spin_cooldown_left = 0;
    interrupts();

  } else {
    // 观测器始终更新
    if (!obs_inited) {
      obs_init_from_meas(theta, alpha_obs, xhat_local);
      obs_inited = true;
    } else {
      obs_update_one_step(u_prev, theta, alpha_obs, xhat_local);
    }

    arm_step++;

    // ======================================================
    // 风火轮保护
    // ======================================================
    bool spin_protect_armed = true;
    if (SPIN_PROTECT_AFTER_PRE_SWING_ONLY) {
      spin_protect_armed = (arm_step > (PRE_SWING_STEPS_1 + PRE_SWING_STEPS_2));
    }

    if ((!spin_cooldown_active) && ENABLE_SPIN_PROTECT && spin_protect_armed) {
      float spin_excursion = fabsf(alpha_cont - alpha_cont_ref);
      if (spin_excursion >= SPIN_PROTECT_MAX_EXCURSION_RAD) {
        spin_cooldown_active = true;
        spin_cooldown_left = SPIN_PROTECT_COOLDOWN_STEPS;

        upright_mode = false;
        upright_blend = 0.0f;

        alpha_cont_ref = alpha_cont;

        Serial.println("[PROTECT] SPIN_RUNAWAY_COOLDOWN_START");
      }
    }

    if (fabsf(alpha) > ALPHA_LIM) {
      motorBrake();

      noInterrupts();
      g_pwm_cmd = 0;
      g_brake = true;
      g_u_prev = 0.0f;
      g_armed = false;
      g_fallen = true;
      g_obs_inited = false;
      g_upright_mode = false;
      g_upright_blend = 0.0f;
      g_spin_cooldown_active = false;
      g_spin_cooldown_left = 0;
      interrupts();
    }

    noInterrupts();
    bool armed_after_guard = g_armed;
    interrupts();

    if (armed_after_guard) {
      if (spin_cooldown_active) {
        motorDriveSigned(0);

        if (spin_cooldown_left > 0) {
          spin_cooldown_left--;
        }

        if (spin_cooldown_left == 0) {
          spin_cooldown_active = false;
          upright_mode = false;
          upright_blend = 0.0f;
          alpha_cont_ref = alpha_cont;

          Serial.println("[PROTECT] SPIN_RUNAWAY_COOLDOWN_END");
        }

        noInterrupts();
        g_pwm_cmd = 0;
        g_brake = false;
        g_u_prev = 0.0f;
        g_obs_inited = obs_inited;
        g_arm_step = arm_step;

        g_diff_vel_inited = diff_vel_inited;
        g_theta_prev_meas = theta_prev_meas;
        g_alpha_prev_meas = alpha_prev_meas;
        g_thetaDot_diff_lpf = thetaDot_diff_lpf;
        g_alphaDot_diff_lpf = alphaDot_diff_lpf;

        g_upright_mode = upright_mode;
        g_upright_blend = upright_blend;

        g_alpha_unwrap_inited = alpha_unwrap_inited;
        g_alpha_cont = alpha_cont;
        g_alpha_cont_ref = alpha_cont_ref;

        g_spin_cooldown_active = spin_cooldown_active;
        g_spin_cooldown_left = spin_cooldown_left;
        interrupts();

      } else {
        // ======================================================
        // TD3 输入
        // 注意：last_action_norm 现在按部署实际限幅 150 归一化
        // ======================================================
        float thd_use_td3 = thetaDot_diff;
        float ald_use_td3 = alphaDot_diff;

        float s_in[TD3_STATE_DIM];

#if (TD3_STATE_DIM == 7)
        float th = theta;
        float al = alpha;

        s_in[0] = sinf(th);
        s_in[1] = cosf(th);
        s_in[2] = thd_use_td3;
        s_in[3] = sinf(al);
        s_in[4] = cosf(al);
        s_in[5] = ald_use_td3;
        s_in[6] = clampf_user(g_u_prev / PWM_LIMIT_DEPLOY_F, -1.0f, 1.0f);
#else
        #error "Unsupported TD3_STATE_DIM. Expect 7."
#endif

        int16_t pwm = 0;

        if (ENABLE_PRE_SWING && arm_step <= PRE_SWING_STEPS_1) {
          pwm = clamp_pwm_deploy_int16(PRE_PWM_1);
        } else if (ENABLE_PRE_SWING && arm_step <= (PRE_SWING_STEPS_1 + PRE_SWING_STEPS_2)) {
          pwm = clamp_pwm_deploy_int16(PRE_PWM_2);
        } else {
          float abs_alpha = fabsf(alpha);

          bool upright_mode_prev = upright_mode;

          if (!upright_mode) {
            if (abs_alpha <= UPRIGHT_ENTER_RAD) {
              upright_mode = true;
            }
          } else {
            if (abs_alpha >= UPRIGHT_EXIT_RAD) {
              upright_mode = false;
            }
          }

          if ((!upright_mode_prev) && upright_mode && RESET_OBSERVER_WHEN_ENTER_UPRIGHT) {
            obs_init_from_meas(theta, alpha_obs, xhat_local);
          }

          int16_t pwm_td3 = td3_policy_pwm(s_in);

          float theta_lqr     = xhat_local[0];
          float theta_dot_lqr = xhat_local[1];
          float alpha_lqr     = xhat_local[2];
          float alpha_dot_lqr = xhat_local[3];

          int16_t pwm_lqr = lqr_control_pwm(
              theta_lqr,
              theta_dot_lqr,
              alpha_lqr,
              alpha_dot_lqr);

          float pwm_inner =
              MIX_LQR_WEIGHT * (float)pwm_lqr +
              MIX_RL_WEIGHT  * (float)pwm_td3;

          float blend_target = 0.0f;
          if (upright_mode) {
            if (abs_alpha <= UPRIGHT_ENTER_RAD) {
              blend_target = 1.0f;
            } else if (abs_alpha >= UPRIGHT_EXIT_RAD) {
              blend_target = 0.0f;
            } else {
              blend_target = (UPRIGHT_EXIT_RAD - abs_alpha) / (UPRIGHT_EXIT_RAD - UPRIGHT_ENTER_RAD);
            }
          } else {
            blend_target = 0.0f;
          }

          if (ENABLE_SOFT_SWITCH) {
            upright_blend += SOFT_BLEND_ALPHA * (blend_target - upright_blend);
          } else {
            upright_blend = blend_target;
          }

          upright_blend = clampf_user(upright_blend, 0.0f, 1.0f);

          float pwm_total =
              (1.0f - upright_blend) * (float)pwm_td3 +
              upright_blend * pwm_inner;

          pwm_total = clamp_pwm_deploy_float(pwm_total);
          pwm = (int16_t)lroundf(pwm_total);
          pwm = clamp_pwm_deploy_int16(pwm);
        }

        pwm = clamp_pwm_deploy_int16(pwm);

        motorDriveSigned(pwm);

        noInterrupts();
        g_pwm_cmd = pwm;
        g_brake = false;
        g_u_prev = (float)pwm;
        g_obs_inited = obs_inited;
        g_arm_step = arm_step;

        g_diff_vel_inited = diff_vel_inited;
        g_theta_prev_meas = theta_prev_meas;
        g_alpha_prev_meas = alpha_prev_meas;
        g_thetaDot_diff_lpf = thetaDot_diff_lpf;
        g_alphaDot_diff_lpf = alphaDot_diff_lpf;

        g_upright_mode = upright_mode;
        g_upright_blend = upright_blend;

        g_alpha_unwrap_inited = alpha_unwrap_inited;
        g_alpha_cont = alpha_cont;
        g_alpha_cont_ref = alpha_cont_ref;

        g_spin_cooldown_active = spin_cooldown_active;
        g_spin_cooldown_left = spin_cooldown_left;
        interrupts();
      }
    }

    noInterrupts();
    g_xhat[0] = xhat_local[0];
    g_xhat[1] = xhat_local[1];
    g_xhat[2] = xhat_local[2];
    g_xhat[3] = xhat_local[3];
    interrupts();
  }

  uint32_t t1 = dwt_cycles_user();

  uint32_t lat_comp  = cycles_to_us_user(t1 - t0);
  uint32_t lat_total = cycles_to_us_user(dwt_cycles_user() - t_cmd);

  noInterrupts();
  g_lat_comp_us = lat_comp;
  g_lat_total_us = lat_total;
  g_step++;
  uint32_t step = g_step;

  bool armed2  = g_armed;
  bool brake2  = g_brake;
  bool fallen2 = g_fallen;
  int  cmd     = g_pwm_cmd;

  float hx0 = g_xhat[0];
  float hx1 = g_xhat[1];
  float hx2 = g_xhat[2];
  float hx3 = g_xhat[3];
  interrupts();

  Serial.print("LOG,");
  Serial.print(step);       Serial.print(",");
  Serial.print(tick_dt_us); Serial.print(",");
  Serial.print(lat_total);  Serial.print(",");
  Serial.print(lat_comp);   Serial.print(",");
  Serial.print(armed2 ? 1 : 0);  Serial.print(",");
  Serial.print(brake2 ? 1 : 0);  Serial.print(",");
  Serial.print(fallen2 ? 1 : 0); Serial.print(",");
  Serial.print(cmd);        Serial.print(",");
  Serial.print(pot);        Serial.print(",");
  Serial.print(enc);        Serial.print(",");
  Serial.print(theta, 6);   Serial.print(",");
  Serial.print(alpha, 6);   Serial.print(",");
  Serial.print(hx0, 6);     Serial.print(",");
  Serial.print(hx1, 6);     Serial.print(",");
  Serial.print(hx2, 6);     Serial.print(",");
  Serial.println(hx3, 6);
}