Class 8 LQR experiment package

Files:
  calc_lqr_gain.py       Compute continuous-time LQR gain K from A, B, Q, R.
  rip_lqr_control.ino    STM32 firmware. No DQN and no swing-up. Upright LQR only.
  rip_lqr_run_10s.py     PC script. Press Enter to send GO, record 10 s, save CSV and plot.

Workflow:
  1. Use Class 7 sensor logger to calibrate POT_ZERO and POT_DOWN_RAW.
  2. Run: python calc_lqr_gain.py
  3. Copy the printed K values into rip_lqr_control.ino.
  4. Upload rip_lqr_control.ino to STM32.
  5. Close Arduino Serial Monitor.
  6. Hold the pendulum near upright by hand.
  7. Run: python rip_lqr_run_10s.py
  8. Press Enter in the terminal to send GO and start the 10 s experiment.

Safety:
  - This firmware refuses GO if alpha is not near upright.
  - If alpha exceeds the fallen threshold, the motor is disabled.
  - If motor pushes in the wrong direction, stop immediately and change MOTOR_SIGN.
