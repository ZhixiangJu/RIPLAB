Class 8/9 Linear MPC experiment package

Files:
  rip_mpc_control.ino    STM32 firmware. No DQN and no swing-up. Upright linear MPC only.
  rip_mpc_run_10s.py     PC script. Press Enter to send GO, record 10 s, save CSV and plot.

Workflow:
  1. Use Class 7 sensor logger to calibrate POT_ZERO and POT_DOWN_RAW.
  2. Check A_c, B_c, Q_diag, Qf_diag, R_scalar, and MPC_HORIZON in rip_mpc_control.ino.
  3. Upload rip_mpc_control.ino to STM32.
  4. Close Arduino Serial Monitor.
  5. Hold the pendulum near upright by hand.
  6. Run: python rip_mpc_run_10s.py
  7. Press Enter in the terminal to send GO and start the 10 s experiment.

Safety:
  - This firmware refuses GO if alpha is not near upright.
  - If alpha exceeds the fallen threshold, the motor is disabled.
  - If motor pushes in the wrong direction, stop immediately and change MOTOR_SIGN.

Teaching note:
  This lightweight code computes an unconstrained finite-horizon linear MPC gain by backward Riccati recursion and then applies PWM saturation.
