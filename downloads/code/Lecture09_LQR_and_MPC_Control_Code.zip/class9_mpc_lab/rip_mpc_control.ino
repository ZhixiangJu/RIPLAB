#include <Arduino.h>
#include <math.h>

// ============================================================
// RIP Linear MPC Control Firmware
// File name: rip_mpc_control.ino
//
// Features:
//   - 200 Hz real-time loop
//   - Sensor conversion from pot/encoder to theta/alpha
//   - Low-pass-filtered angular velocities
//   - Linear finite-horizon receding-horizon controller
//   - NO DQN, NO swing-up
//   - Student manually holds pendulum near upright, then PC sends GO
//
// Note:
//   This lightweight teaching code computes an unconstrained finite-horizon
//   linear MPC feedback gain by backward Riccati recursion. The final command
//   is then saturated to PWM limits for hardware safety.
// ============================================================

// -------------------------
// Pin definition
// -------------------------
static const int PIN_POT   = A0;
static const int PIN_ENC_A = 2;
static const int PIN_ENC_B = 3;

static const int PIN_IN1  = 4;
static const int PIN_IN2  = 5;
static const int PIN_STBY = 7;
static const int PIN_PWM  = 10;

// -------------------------
// Sampling
// -------------------------
static const uint32_t BAUD = 921600;
static const uint32_t CTRL_HZ = 200;
static const uint32_t DT_US = 1000000UL / CTRL_HZ;
static const float DT_CTRL = 1.0f / (float)CTRL_HZ;

// -------------------------
// Calibration
// -------------------------
static const float PI_F = 3.14159265358979323846f;
static const int32_t POT_MOD = 4096;
static const float THETA_SIGN = +1.0f;
static const float THETA_CAL_ONE_TURN_MEAS_RAD = 6.503f;
static const float THETA_SCALE_NOMINAL = THETA_SIGN * (PI_F / 520.0f);
static const float THETA_SCALE = THETA_SCALE_NOMINAL * ((2.0f * PI_F) / THETA_CAL_ONE_TURN_MEAS_RAD);

static volatile int32_t POT_ZERO = 3132;
static volatile int32_t POT_DOWN_RAW = 1036;
static const bool POT_CW_DECREASES = true;

static volatile int32_t ENC_ZERO = 10000;
static volatile int32_t g_enc = 10000;

// -------------------------
// Linear model and MPC weights
// State: [theta, theta_dot, alpha, alpha_dot]^T
// Discrete model uses Euler approximation at DT_CTRL = 0.005 s.
// Students may replace A_c and B_c using their own identified model.
// -------------------------
static const float A_c[4][4] = {
  {0.0f, 1.0f, 0.0f, 0.0f},
  {0.0f, -11.3205f, -49.9955f, 0.4820f},
  {0.0f, 0.0f, 0.0f, 1.0f},
  {0.0f, 16.9206f, 171.2602f, -1.6510f}
};
static const float B_c[4] = {0.0f, 0.8171f, 0.0f, -1.2213f};

// Q and R for finite-horizon MPC.
static const float Q_diag[4]  = {1.0f, 0.1f, 120.0f, 1.0f};
static const float Qf_diag[4] = {2.0f, 0.2f, 200.0f, 2.0f};
static const float R_scalar = 1.0f;
static const int MPC_HORIZON = 20;

static float K_MPC[4] = {0.0f, 0.0f, 120.0f, 12.0f};

static const float MOTOR_SIGN = +1.0f;
static const int PWM_MAX = 180;
static const float START_ALPHA_MAX_RAD = 25.0f * PI_F / 180.0f;
static const float FALLEN_ALPHA_RAD = 35.0f * PI_F / 180.0f;
static const float VEL_LPF_ALPHA = 0.25f;

static bool g_armed = false;
static bool g_fallen = false;
static uint32_t g_step = 0;

static float g_theta_prev = 0.0f;
static float g_alpha_prev = 0.0f;
static float g_theta_dot = 0.0f;
static float g_alpha_dot = 0.0f;
static bool g_vel_inited = false;

// ============================================================
// Utility functions
// ============================================================
static inline int32_t mod4096(int32_t x) {
  x %= POT_MOD;
  if (x < 0) x += POT_MOD;
  return x;
}

static inline int32_t cwDistCounts(int32_t ref, int32_t x) {
  ref = mod4096(ref);
  x = mod4096(x);
  if (POT_CW_DECREASES) return mod4096(ref - x);
  else return mod4096(x - ref);
}

static inline float wrapToPi(float x) {
  while (x > PI_F) x -= 2.0f * PI_F;
  while (x < -PI_F) x += 2.0f * PI_F;
  return x;
}

static inline float alphaFromPotRawBranchCutAtDown(int32_t pot_raw) {
  const int32_t up = mod4096(POT_ZERO);
  const int32_t dn = mod4096(POT_DOWN_RAW);
  const int32_t x  = mod4096(pot_raw);

  int32_t cw_to_down = cwDistCounts(up, dn);
  if (cw_to_down <= 0 || cw_to_down >= POT_MOD) return 0.0f;

  int32_t cw_to_x = cwDistCounts(up, x);
  if (cw_to_x <= cw_to_down) {
    return PI_F * ((float)cw_to_x / (float)cw_to_down);
  }
  int32_t rem = POT_MOD - cw_to_down;
  if (rem <= 0) return 0.0f;
  return -PI_F * ((float)(POT_MOD - cw_to_x) / (float)rem);
}

static inline int clampInt(int v, int lo, int hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

// ============================================================
// Encoder ISRs
// ============================================================
void isr_enc_a() {
  bool A = digitalRead(PIN_ENC_A);
  bool B = digitalRead(PIN_ENC_B);
  if (A) g_enc += (B ? 1 : -1);
  else   g_enc += (B ? -1 : 1);
}

void isr_enc_b() {
  bool A = digitalRead(PIN_ENC_A);
  bool B = digitalRead(PIN_ENC_B);
  if (B) g_enc += (A ? -1 : 1);
  else   g_enc += (A ? 1 : -1);
}

// ============================================================
// Motor output
// ============================================================
void motorWritePWM(int pwm) {
  pwm = clampInt(pwm, -PWM_MAX, PWM_MAX);
  if (pwm == 0) {
    analogWrite(PIN_PWM, 0);
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, LOW);
    digitalWrite(PIN_STBY, LOW);
    return;
  }
  digitalWrite(PIN_STBY, HIGH);
  if (pwm > 0) {
    digitalWrite(PIN_IN1, HIGH);
    digitalWrite(PIN_IN2, LOW);
    analogWrite(PIN_PWM, pwm);
  } else {
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, HIGH);
    analogWrite(PIN_PWM, -pwm);
  }
}

void stopAndDisarm(const char* msg) {
  motorWritePWM(0);
  g_armed = false;
  Serial.print("[STOP] ");
  Serial.println(msg);
}

// ============================================================
// Small matrix functions for MPC gain calculation
// ============================================================
void computeMpcGain() {
  float A[4][4];
  float B[4];

  for (int i = 0; i < 4; ++i) {
    B[i] = B_c[i] * DT_CTRL;
    for (int j = 0; j < 4; ++j) {
      A[i][j] = (i == j ? 1.0f : 0.0f) + A_c[i][j] * DT_CTRL;
    }
  }

  float P[4][4] = {0};
  for (int i = 0; i < 4; ++i) P[i][i] = Qf_diag[i];

  float K[4] = {0, 0, 0, 0};

  for (int step = MPC_HORIZON - 1; step >= 0; --step) {
    // PB = P * B
    float PB[4] = {0, 0, 0, 0};
    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 4; ++j) PB[i] += P[i][j] * B[j];
    }

    // S = R + B'PB
    float S = R_scalar;
    for (int i = 0; i < 4; ++i) S += B[i] * PB[i];
    if (S < 1e-6f) S = 1e-6f;

    // B' P A
    float BtPA[4] = {0, 0, 0, 0};
    for (int j = 0; j < 4; ++j) {
      for (int i = 0; i < 4; ++i) BtPA[j] += B[i] * P[i][0] * A[0][j] + B[i] * 0.0f;
    }
    // compute BtPA correctly using PB^T A
    for (int j = 0; j < 4; ++j) {
      BtPA[j] = 0.0f;
      for (int i = 0; i < 4; ++i) BtPA[j] += PB[i] * A[i][j];
      K[j] = BtPA[j] / S;
    }

    // AP = A' P A
    float PA[4][4] = {0};
    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 4; ++j) {
        for (int k = 0; k < 4; ++k) PA[i][j] += P[i][k] * A[k][j];
      }
    }
    float AtPA[4][4] = {0};
    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 4; ++j) {
        for (int k = 0; k < 4; ++k) AtPA[i][j] += A[k][i] * PA[k][j];
      }
    }

    // A' P B K = (A'PB) * K, and A'PB = (B'PA)^T
    float newP[4][4] = {0};
    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 4; ++j) {
        newP[i][j] = AtPA[i][j] - BtPA[i] * K[j];
      }
      newP[i][i] += Q_diag[i];
    }

    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 4; ++j) P[i][j] = newP[i][j];
    }
  }

  for (int i = 0; i < 4; ++i) K_MPC[i] = K[i];
}

// ============================================================
// Serial command handling
// ============================================================
void handleLine(String s) {
  s.trim();

  if (s == "GO") {
    int pot_raw = analogRead(PIN_POT);
    float alpha = alphaFromPotRawBranchCutAtDown(pot_raw);

    if (fabs(alpha) > START_ALPHA_MAX_RAD) {
      Serial.print("[REFUSE] alpha_not_near_upright, alpha=");
      Serial.println(alpha, 6);
      motorWritePWM(0);
      g_armed = false;
      return;
    }

    noInterrupts();
    ENC_ZERO = g_enc;
    interrupts();

    g_step = 0;
    g_fallen = false;
    g_vel_inited = false;
    g_theta_dot = 0.0f;
    g_alpha_dot = 0.0f;
    g_armed = true;

    Serial.print("[ARMED] ENC_ZERO=");
    Serial.println((long)ENC_ZERO);
    Serial.println("HEADER,step,t_ms,tick_dt_us,armed,fallen,pwm,u_mpc,pot,enc,theta,alpha,theta_dot,alpha_dot");
    return;
  }

  if (s == "STOP" || s == "S") {
    stopAndDisarm("command");
    return;
  }
}

void setup() {
  Serial.begin(BAUD);
  delay(300);

  pinMode(PIN_POT, INPUT);
  pinMode(PIN_ENC_A, INPUT_PULLUP);
  pinMode(PIN_ENC_B, INPUT_PULLUP);
  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  pinMode(PIN_STBY, OUTPUT);
  pinMode(PIN_PWM, OUTPUT);

  analogReadResolution(12);
  analogWriteResolution(8);
  motorWritePWM(0);

  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), isr_enc_a, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), isr_enc_b, CHANGE);

  computeMpcGain();

  Serial.println("=== RIP LINEAR MPC READY ===");
  Serial.print("K_MPC=");
  for (int i = 0; i < 4; ++i) {
    Serial.print(K_MPC[i], 6);
    if (i < 3) Serial.print(",");
  }
  Serial.println();
  Serial.println("Hold pendulum near upright. Python script will send GO after Enter.");
}

void loop() {
  if (Serial.available()) {
    String s = Serial.readStringUntil('\n');
    handleLine(s);
  }

  static uint32_t last_us = 0;
  static uint32_t last_raw_print = 0;
  uint32_t now_us = micros();

  if ((uint32_t)(now_us - last_us) < DT_US) return;
  uint32_t tick_dt = now_us - last_us;
  last_us += DT_US;

  int pot_raw = analogRead(PIN_POT);

  noInterrupts();
  int32_t enc_now = g_enc;
  int32_t enc_zero = ENC_ZERO;
  interrupts();

  float theta = (float)(enc_now - enc_zero) * THETA_SCALE;
  float alpha = alphaFromPotRawBranchCutAtDown(pot_raw);

  if (!g_vel_inited) {
    g_theta_prev = theta;
    g_alpha_prev = alpha;
    g_theta_dot = 0.0f;
    g_alpha_dot = 0.0f;
    g_vel_inited = true;
  }

  float theta_dot_raw = (theta - g_theta_prev) / DT_CTRL;
  float alpha_dot_raw = wrapToPi(alpha - g_alpha_prev) / DT_CTRL;
  g_theta_dot = (1.0f - VEL_LPF_ALPHA) * g_theta_dot + VEL_LPF_ALPHA * theta_dot_raw;
  g_alpha_dot = (1.0f - VEL_LPF_ALPHA) * g_alpha_dot + VEL_LPF_ALPHA * alpha_dot_raw;
  g_theta_prev = theta;
  g_alpha_prev = alpha;

  if (!g_armed) {
    motorWritePWM(0);
    if (millis() - last_raw_print > 500) {
      last_raw_print = millis();
      Serial.print("RAW,pot="); Serial.print(pot_raw);
      Serial.print(",enc="); Serial.print((long)enc_now);
      Serial.print(",alpha="); Serial.println(alpha, 6);
    }
    return;
  }

  if (fabs(alpha) > FALLEN_ALPHA_RAD) {
    g_fallen = true;
    stopAndDisarm("fallen_alpha_limit");
    return;
  }

  float x[4] = {theta, g_theta_dot, alpha, g_alpha_dot};
  float u_mpc = 0.0f;
  for (int i = 0; i < 4; ++i) u_mpc += K_MPC[i] * x[i];
  u_mpc = -u_mpc;

  int pwm = clampInt((int)roundf(MOTOR_SIGN * u_mpc), -PWM_MAX, PWM_MAX);
  motorWritePWM(pwm);

  Serial.print("LOG,");
  Serial.print(g_step++); Serial.print(",");
  Serial.print(millis()); Serial.print(",");
  Serial.print(tick_dt); Serial.print(",");
  Serial.print(g_armed ? 1 : 0); Serial.print(",");
  Serial.print(g_fallen ? 1 : 0); Serial.print(",");
  Serial.print(pwm); Serial.print(",");
  Serial.print(u_mpc, 6); Serial.print(",");
  Serial.print(pot_raw); Serial.print(",");
  Serial.print((long)enc_now); Serial.print(",");
  Serial.print(theta, 6); Serial.print(",");
  Serial.print(alpha, 6); Serial.print(",");
  Serial.print(g_theta_dot, 6); Serial.print(",");
  Serial.println(g_alpha_dot, 6);
}
