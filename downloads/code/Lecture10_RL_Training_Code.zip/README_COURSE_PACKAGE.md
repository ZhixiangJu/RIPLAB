# RIP Reinforcement Learning Training Package

This package contains the course-specific training code and the custom rotary inverted pendulum environment used in Lecture 10.

Install Python dependencies such as Gymnasium, Stable-Baselines3, NumPy, SciPy, and Matplotlib in your own environment. Large third-party source trees from the original archive are not bundled in this website package.
