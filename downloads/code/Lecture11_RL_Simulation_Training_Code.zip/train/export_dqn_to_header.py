# train/export_dqn_to_header.py
# 生成可烧录到固件的DQN模型权重头文件
# by Zhixiang Ju
#2026.4.22

from __future__ import annotations

import os
import sys
import csv
import json
import textwrap
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# =========================
# 路径注入
# =========================
PROJECT_ROOT = Path(__file__).resolve().parents[1]

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

LOCAL_GYM_REPO = PROJECT_ROOT / "gymnasium"
if str(LOCAL_GYM_REPO) not in sys.path:
    sys.path.insert(0, str(LOCAL_GYM_REPO))

LOCAL_SB3_REPO = PROJECT_ROOT / "stable_baselines3"
if str(LOCAL_SB3_REPO) not in sys.path:
    sys.path.insert(0, str(LOCAL_SB3_REPO))


import gymnasium as gym
import torch
import torch.nn as nn
from stable_baselines3 import DQN

from rip_env.register_envs import register_all_envs
from rip_env.envs.types import (
    EnvConfig,
    RIPPhysicalParams,
    InitStateConfig,
    LimitConfig,
    NoiseConfig,
    LoggingConfig,
)


# ============================================================
# 全局配置：你直接改这里即可
# ============================================================
SEARCH_ROOTS = [
    PROJECT_ROOT / "experiments",
    PROJECT_ROOT / "train" / "experiments",
]

ROLLOUT_TEST_STEPS = 10_000
ROLLOUT_TEST_SEED = 42
REWARD_CURVE_MOVAVG = 10

# 是否优先使用 final model
PREFER_FINAL_MODEL = False

# 导出的 header 使用 generic 格式，兼容你新的固件
MACRO_PREFIX = "DQN"


# ============================================================
# 基础工具
# ============================================================
def ensure_dir(path: str | Path) -> None:
    os.makedirs(path, exist_ok=True)


def safe_read_json(path: Path) -> Optional[dict]:
    if not path.is_file():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def print_bar(msg: str) -> None:
    print("=" * 100)
    print(msg)
    print("=" * 100)


def to_c_float_str(x: float) -> str:
    if np.isnan(x) or np.isinf(x):
        raise ValueError(f"Invalid float value for export: {x}")
    return f"{float(x):.9g}f"


def write_float_1d(f, name: str, arr: np.ndarray) -> None:
    arr = np.asarray(arr, dtype=np.float32).reshape(-1)
    values = ", ".join(to_c_float_str(v) for v in arr)
    f.write(f"static const float {name}[{arr.size}] = {{{values}}};\n")


def write_float_2d(f, name: str, mat: np.ndarray) -> None:
    mat = np.asarray(mat, dtype=np.float32)
    rows, cols = mat.shape
    f.write(f"static const float {name}[{rows}][{cols}] = {{\n")
    for i in range(rows):
        row_values = ", ".join(to_c_float_str(v) for v in mat[i])
        if i < rows - 1:
            f.write(f"    {{{row_values}}},\n")
        else:
            f.write(f"    {{{row_values}}}\n")
    f.write("};\n")


def write_comment_block(f, text: str) -> None:
    f.write("/*\n")
    for line in text.splitlines():
        f.write(f" * {line}\n")
    f.write(" */\n")


def wrap_text(x: Any, width: int = 48) -> str:
    s = str(x)
    return "\n".join(textwrap.wrap(s, width=width)) if len(s) > width else s


# ============================================================
# EnvConfig 重建
# ============================================================
def dict_to_env_config(d: dict) -> EnvConfig:
    return EnvConfig(
        dt=d["dt"],
        max_steps=d["max_steps"],
        action_type=d["action_type"],
        discrete_actions=d["discrete_actions"],
        continuous_pwm_limit=d["continuous_pwm_limit"],
        observation_type=d["observation_type"],
        clip_velocity_in_obs=d["clip_velocity_in_obs"],
        physical_params=RIPPhysicalParams(**d["physical_params"]),
        init_state=InitStateConfig(**d["init_state"]),
        limits=LimitConfig(**d["limits"]),
        noise=NoiseConfig(**d["noise"]),
        logging=LoggingConfig(**d["logging"]),
    )


# ============================================================
# 模型提取
# ============================================================
def get_q_net_sequential(model: DQN) -> nn.Module:
    if not hasattr(model, "policy"):
        raise AttributeError("Loaded model has no attribute 'policy'.")

    policy = model.policy
    if not hasattr(policy, "q_net"):
        raise AttributeError("Loaded DQN policy has no attribute 'q_net'.")

    q_net_wrapper = policy.q_net

    if hasattr(q_net_wrapper, "q_net"):
        return q_net_wrapper.q_net

    return q_net_wrapper


def extract_linear_layers(net: nn.Module) -> List[nn.Linear]:
    layers: List[nn.Linear] = []

    if isinstance(net, nn.Sequential):
        for layer in net:
            if isinstance(layer, nn.Linear):
                layers.append(layer)
        return layers

    for layer in net.modules():
        if layer is net:
            continue
        if isinstance(layer, nn.Linear):
            layers.append(layer)

    return layers


# ============================================================
# 搜索案例
# ============================================================
def is_dqn_case_dir(case_dir: Path) -> bool:
    if not case_dir.is_dir():
        return False
    if not (case_dir / "run_config.json").is_file():
        return False
    if not (case_dir / "env_config_snapshot.json").is_file():
        return False

    has_final = (case_dir / "models" / "dqn_rip_final.zip").is_file()
    has_best = (case_dir / "best_model" / "best_model.zip").is_file()

    return has_final or has_best


def find_all_dqn_cases() -> List[Path]:
    cases: List[Path] = []
    seen = set()

    for root in SEARCH_ROOTS:
        if not root.is_dir():
            continue

        # experiments 下的一层子目录通常就是 case
        for child in root.iterdir():
            if not child.is_dir():
                continue
            if is_dqn_case_dir(child):
                rp = str(child.resolve())
                if rp not in seen:
                    seen.add(rp)
                    cases.append(child)

    cases.sort(key=lambda p: p.name)
    return cases


def choose_model_path(case_dir: Path) -> Path:
    final_model = case_dir / "models" / "dqn_rip_final.zip"
    best_model = case_dir / "best_model" / "best_model.zip"

    if PREFER_FINAL_MODEL and final_model.is_file():
        return final_model
    if best_model.is_file():
        return best_model
    if final_model.is_file():
        return final_model

    # 兜底：models 下找最新 zip
    model_dir = case_dir / "models"
    if model_dir.is_dir():
        zips = sorted(model_dir.glob("*.zip"))
        if len(zips) > 0:
            return zips[-1]

    raise FileNotFoundError(f"No DQN model zip found in case dir: {case_dir}")


# ============================================================
# 动作列表提取
# ============================================================
def parse_actions_from_env_config(env_cfg_json: dict) -> Optional[List[int]]:
    if env_cfg_json is None:
        return None

    action_type = env_cfg_json.get("action_type", None)
    if action_type != "discrete":
        return None

    actions = env_cfg_json.get("discrete_actions", None)
    if actions is None:
        return None

    return [int(round(float(x))) for x in actions]


# ============================================================
# 导出 generic 版 header（兼容你新的固件）
# ============================================================
def export_dqn_to_generic_header(
    model_path: Path,
    output_header_path: Path,
    env_config_json: Optional[dict],
    macro_prefix: str = "DQN",
) -> Dict[str, Any]:
    if not model_path.is_file():
        raise FileNotFoundError(f"DQN model zip not found: {model_path}")

    print(f"[INFO] Loading DQN model from:\n  {model_path}")
    model = DQN.load(str(model_path), device="cpu")

    q_net = get_q_net_sequential(model)
    linear_layers = extract_linear_layers(q_net)

    if len(linear_layers) == 0:
        raise RuntimeError("No Linear layers found in DQN q_net. Cannot export MLP weights.")

    obs_dim = int(model.observation_space.shape[0])
    act_dim = int(model.action_space.n)

    layer_dims = []
    for layer in linear_layers:
        layer_dims.append((int(layer.in_features), int(layer.out_features)))

    actions = parse_actions_from_env_config(env_config_json)
    if actions is not None and len(actions) != act_dim:
        raise ValueError(
            f"Action count mismatch: model act_dim={act_dim}, but actions len={len(actions)}"
        )

    ensure_dir(output_header_path.parent)

    prefix = macro_prefix.strip().upper()
    guard = f"{prefix}_MODEL_WEIGHTS_H"

    with open(output_header_path, "w", encoding="utf-8") as f:
        f.write("#pragma once\n\n")
        f.write(f"#ifndef {guard}\n")
        f.write(f"#define {guard}\n\n")
        f.write("#include <stdint.h>\n\n")

        write_comment_block(
            f,
            "\n".join(
                [
                    "Auto-generated from Stable-Baselines3 DQN model.",
                    f"Source model: {str(model_path.resolve())}",
                    f"Observation dim: {obs_dim}",
                    f"Action dim: {act_dim}",
                    f"Linear layer count: {len(linear_layers)}",
                    "Format: GENERIC MLP header",
                    "Hidden activations are assumed to be ReLU; last layer is linear output Q(s,a).",
                    "This header is intended to be compatible with the new firmware that supports",
                    "both LEGACY and GENERIC formats.",
                ]
            ),
        )
        f.write("\n")

        f.write(f"#define {prefix}_OBS_DIM {obs_dim}\n")
        f.write(f"#define {prefix}_ACT_DIM {act_dim}\n")
        f.write(f"#define {prefix}_LINEAR_LAYER_COUNT {len(linear_layers)}\n\n")

        for idx, (in_dim, out_dim) in enumerate(layer_dims):
            f.write(f"#define {prefix}_L{idx}_IN {in_dim}\n")
            f.write(f"#define {prefix}_L{idx}_OUT {out_dim}\n")
        f.write("\n")

        for idx, layer in enumerate(linear_layers):
            W = layer.weight.detach().cpu().numpy().astype(np.float32)
            b = layer.bias.detach().cpu().numpy().astype(np.float32)

            write_float_2d(f, f"{prefix}_W{idx}", W)
            write_float_1d(f, f"{prefix}_B{idx}", b)
            f.write("\n")

        if actions is not None:
            # 用 int16_t，更贴近你固件现有动作表定义
            arr = np.asarray(actions, dtype=np.int16).reshape(-1)
            vals = ", ".join(str(int(v)) for v in arr)
            f.write(f"static const int16_t {prefix}_ACTIONS[{prefix}_ACT_DIM] = {{{vals}}};\n\n")

        f.write("/*\n")
        f.write(" * Network structure summary:\n")
        prev = obs_dim
        for idx, (_, out_dim) in enumerate(layer_dims):
            f.write(f" *   Linear {idx}: {prev} -> {out_dim}\n")
            prev = out_dim
        f.write(" */\n\n")

        f.write(f"#endif  // {guard}\n")

    info = {
        "obs_dim": obs_dim,
        "act_dim": act_dim,
        "linear_layers": len(linear_layers),
        "layer_dims": layer_dims,
        "actions": actions,
    }
    return info


# ============================================================
# 奖励曲线图
# ============================================================
def moving_average(x: np.ndarray, w: int) -> np.ndarray:
    if len(x) == 0:
        return x
    if w <= 1:
        return x.copy()
    out = np.zeros_like(x, dtype=np.float64)
    for i in range(len(x)):
        lo = max(0, i - w + 1)
        out[i] = np.mean(x[lo:i + 1])
    return out


def load_episode_log_csv(csv_path: Path) -> Optional[dict]:
    if not csv_path.is_file():
        return None

    rows = []
    with open(csv_path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)

    if len(rows) == 0:
        return None

    episode = []
    ep_reward = []
    ep_length = []

    for row in rows:
        try:
            episode.append(int(row["episode"]))
            ep_reward.append(float(row["episode_reward"]))
            ep_length.append(int(row["episode_length"]))
        except Exception:
            continue

    if len(ep_reward) == 0:
        return None

    episode = np.asarray(episode, dtype=np.int32)
    ep_reward = np.asarray(ep_reward, dtype=np.float64)
    ep_length = np.asarray(ep_length, dtype=np.int32)
    reward_per_step = ep_reward / np.maximum(ep_length, 1)
    cum_steps = np.cumsum(ep_length)

    return {
        "episode": episode,
        "episode_reward": ep_reward,
        "episode_length": ep_length,
        "reward_per_step": reward_per_step,
        "cum_steps": cum_steps,
    }


def plot_reward_curve(case_dir: Path, episode_log: Optional[dict]) -> Path:
    out_path = case_dir / "reward_per_step_curve.png"

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.grid(True)

    if episode_log is None:
        ax.text(0.5, 0.5, "No episode_log.csv found", ha="center", va="center", fontsize=14)
        ax.set_title("Reward Curve (Unavailable)")
        fig.savefig(out_path, dpi=180, bbox_inches="tight")
        plt.close(fig)
        return out_path

    x = episode_log["cum_steps"]
    y = episode_log["reward_per_step"]
    y_ma = moving_average(y, REWARD_CURVE_MOVAVG)

    ax.plot(x, y, ".", alpha=0.7, label="episode reward / step")
    ax.plot(x, y_ma, "-", linewidth=2.0, label=f"moving avg ({REWARD_CURVE_MOVAVG})")

    ax.set_xlabel("cumulative timesteps")
    ax.set_ylabel("reward per step")
    ax.set_title("Reward-per-step Curve")
    ax.legend(loc="best")

    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return out_path


# ============================================================
# 10000 步 rollout 测试
# ============================================================
def build_rollout_env(env_config_json: dict) -> gym.Env:
    cfg = dict_to_env_config(env_config_json)

    # 改成测试用设置
    cfg.max_steps = ROLLOUT_TEST_STEPS
    cfg.logging.enabled = False
    cfg.logging.save_step_log = False
    cfg.logging.flush_every_step = False

    # 不要测试时再往原日志目录写
    cfg.logging.log_dir = str(PROJECT_ROOT / "tmp_rollout_logs")

    env = gym.make(
        "CartPoleRIP-v0",
        env_config=cfg,
    )
    return env


def run_rollout_and_plot(case_dir: Path, model_path: Path, env_config_json: dict) -> Path:
    out_path = case_dir / "rollout_10000_steps.png"

    register_all_envs()
    env = build_rollout_env(env_config_json)
    model = DQN.load(str(model_path), device="cpu")

    obs, info = env.reset(seed=ROLLOUT_TEST_SEED)

    theta_list: List[float] = []
    alpha_list: List[float] = []
    pwm_list: List[float] = []
    reward_list: List[float] = []
    done_list: List[int] = []

    actual_steps = 0

    for _ in range(ROLLOUT_TEST_STEPS):
        action, _ = model.predict(obs, deterministic=True)
        obs, reward, terminated, truncated, info = env.step(action)

        state = info.get("state", None)
        pwm = info.get("pwm", 0.0)

        if state is not None:
            theta_list.append(float(state[0]))
            alpha_list.append(float(state[2]))
        else:
            theta_list.append(np.nan)
            alpha_list.append(np.nan)

        pwm_list.append(float(pwm))
        reward_list.append(float(reward))
        done_list.append(int(terminated or truncated))

        actual_steps += 1
        if terminated or truncated:
            break

    env.close()

    tt = np.arange(actual_steps, dtype=np.float64) * float(env_config_json["dt"])

    fig, axs = plt.subplots(4, 1, figsize=(11, 10), sharex=False)

    axs[0].plot(tt, theta_list, linewidth=1.2)
    axs[0].grid(True)
    axs[0].set_ylabel("theta (rad)")
    axs[0].set_title(f"10000-step deterministic rollout (actual steps = {actual_steps})")

    axs[1].plot(tt, alpha_list, linewidth=1.2)
    axs[1].grid(True)
    axs[1].set_ylabel("alpha (rad)")

    axs[2].step(tt, pwm_list, where="post", linewidth=1.0)
    axs[2].grid(True)
    axs[2].set_ylabel("PWM")

    axs[3].plot(tt, reward_list, linewidth=1.0, label="reward")
    axs[3].step(tt, done_list, where="post", linewidth=1.0, label="done", alpha=0.7)
    axs[3].grid(True)
    axs[3].set_ylabel("reward / done")
    axs[3].set_xlabel("time (s)")
    axs[3].legend(loc="best")

    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)

    return out_path


# ============================================================
# 训练摘要表格图片
# ============================================================
def build_network_structure_string(layer_dims: List[Tuple[int, int]]) -> str:
    if len(layer_dims) == 0:
        return "N/A"
    parts = [str(layer_dims[0][0])]
    for _, out_dim in layer_dims:
        parts.append(str(out_dim))
    return " -> ".join(parts)


def plot_summary_table(
    case_dir: Path,
    run_cfg_json: Optional[dict],
    env_cfg_json: Optional[dict],
    export_info: Dict[str, Any],
    model_path: Path,
) -> Path:
    out_path = case_dir / "training_summary_table.png"

    layer_dims = export_info["layer_dims"]
    actions = export_info["actions"]

    rows = []

    rows.append(("Experiment", case_dir.name))
    rows.append(("Model Path", str(model_path)))
    rows.append(("Exported Header", str(case_dir / "model_weights.h")))
    rows.append(("Observation Dim", export_info["obs_dim"]))
    rows.append(("Action Dim", export_info["act_dim"]))
    rows.append(("Linear Layer Count", export_info["linear_layers"]))
    rows.append(("Network Structure", build_network_structure_string(layer_dims)))

    if env_cfg_json is not None:
        rows.append(("Action Type", env_cfg_json.get("action_type", "N/A")))
        rows.append(("Discrete Actions", actions if actions is not None else "N/A"))
        rows.append(("Observation Type", env_cfg_json.get("observation_type", "N/A")))
        rows.append(("dt", env_cfg_json.get("dt", "N/A")))
        rows.append(("max_steps", env_cfg_json.get("max_steps", "N/A")))

    if run_cfg_json is not None:
        wanted_keys = [
            "seed",
            "total_timesteps",
            "learning_rate",
            "buffer_size",
            "learning_starts",
            "batch_size",
            "gamma",
            "train_freq",
            "gradient_steps",
            "target_update_interval",
            "exploration_fraction",
            "exploration_initial_eps",
            "exploration_final_eps",
            "net_arch",
            "activation_fn_name",
            "n_envs",
            "eval_freq",
            "n_eval_episodes",
        ]
        for k in wanted_keys:
            if k in run_cfg_json:
                rows.append((k, run_cfg_json[k]))

    n_rows = len(rows)
    fig_h = max(8, 0.42 * n_rows)

    fig, ax = plt.subplots(figsize=(13, fig_h))
    ax.axis("off")

    cell_text = []
    for k, v in rows:
        cell_text.append([wrap_text(k, 24), wrap_text(v, 56)])

    table = ax.table(
        cellText=cell_text,
        colLabels=["Item", "Value"],
        cellLoc="left",
        colLoc="left",
        loc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.0, 1.5)

    ax.set_title("Training / Environment / Model Summary", fontsize=14, pad=20)

    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return out_path


# ============================================================
# 单案例处理
# ============================================================
def process_one_case(case_dir: Path) -> None:
    print_bar(f"[CASE] {case_dir}")

    run_cfg_path = case_dir / "run_config.json"
    env_cfg_path = case_dir / "env_config_snapshot.json"
    episode_log_path = case_dir / "env_logs" / "episode_log.csv"

    run_cfg_json = safe_read_json(run_cfg_path)
    env_cfg_json = safe_read_json(env_cfg_path)

    if env_cfg_json is None:
        print(f"[WARN] Missing env_config_snapshot.json, skip case: {case_dir}")
        return

    model_path = choose_model_path(case_dir)
    header_path = case_dir / "model_weights.h"

    export_info = export_dqn_to_generic_header(
        model_path=model_path,
        output_header_path=header_path,
        env_config_json=env_cfg_json,
        macro_prefix=MACRO_PREFIX,
    )

    episode_log = load_episode_log_csv(episode_log_path)
    reward_curve_path = plot_reward_curve(case_dir, episode_log)
    rollout_fig_path = run_rollout_and_plot(case_dir, model_path, env_cfg_json)
    summary_table_path = plot_summary_table(
        case_dir=case_dir,
        run_cfg_json=run_cfg_json,
        env_cfg_json=env_cfg_json,
        export_info=export_info,
        model_path=model_path,
    )

    summary_json = {
        "case_dir": str(case_dir),
        "model_path": str(model_path),
        "model_weights_h": str(header_path),
        "reward_curve_png": str(reward_curve_path),
        "rollout_10000_png": str(rollout_fig_path),
        "training_summary_table_png": str(summary_table_path),
        "export_info": export_info,
    }

    with open(case_dir / "export_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary_json, f, ensure_ascii=False, indent=2, default=str)

    print("[DONE]")
    print(f"  model_weights.h         -> {header_path}")
    print(f"  reward curve            -> {reward_curve_path}")
    print(f"  rollout 10000 steps     -> {rollout_fig_path}")
    print(f"  summary table           -> {summary_table_path}")
    print(f"  export summary json     -> {case_dir / 'export_summary.json'}")


# ============================================================
# main
# ============================================================
def main():
    print_bar("[START] Scan all DQN experiment cases")

    register_all_envs()

    cases = find_all_dqn_cases()
    if len(cases) == 0:
        print("[INFO] No DQN experiment case found.")
        print("[INFO] Checked roots:")
        for root in SEARCH_ROOTS:
            print(f"  - {root}")
        return

    print(f"[INFO] Found {len(cases)} DQN case(s).")
    for case_dir in cases:
        print(f"  - {case_dir}")

    ok = 0
    bad = 0

    for case_dir in cases:
        try:
            process_one_case(case_dir)
            ok += 1
        except Exception as e:
            bad += 1
            print_bar(f"[ERROR] Failed to process case: {case_dir}")
            print(f"{type(e).__name__}: {e}")

    print_bar("[FINISH]")
    print(f"[INFO] success = {ok}")
    print(f"[INFO] failed  = {bad}")


if __name__ == "__main__":
    main()