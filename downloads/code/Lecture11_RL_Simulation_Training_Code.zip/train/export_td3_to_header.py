# train/export_td3_to_header.py
# Export TD3 actor to STM32 header
# No PPO import, no PPO call.
# by Zhixiang Ju
# 2026.4.25

from __future__ import annotations

import os
import sys
import json
import csv
import textwrap
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ============================================================
# 1. Path injection
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

LOCAL_SB3_REPO = PROJECT_ROOT / "stable_baselines3"
LOCAL_GYM_REPO = PROJECT_ROOT / "gymnasium"

for p in [
    str(LOCAL_SB3_REPO),
    str(LOCAL_GYM_REPO),
    str(PROJECT_ROOT),
]:
    if p in sys.path:
        sys.path.remove(p)

sys.path.insert(0, str(LOCAL_SB3_REPO))
sys.path.insert(1, str(LOCAL_GYM_REPO))
sys.path.insert(2, str(PROJECT_ROOT))

print("=" * 100)
print("[PATH CHECK]")
print(f"PROJECT_ROOT      = {PROJECT_ROOT}")
print(f"LOCAL_SB3_REPO    = {LOCAL_SB3_REPO}")
print(f"LOCAL_GYM_REPO    = {LOCAL_GYM_REPO}")
print(f"Python executable = {sys.executable}")
print("=" * 100)


# ============================================================
# 2. Imports
# ============================================================

import gymnasium as gym
import torch
import torch.nn as nn

from stable_baselines3.td3.td3 import TD3

import stable_baselines3
print("[IMPORT CHECK]")
print(f"stable_baselines3 imported from: {stable_baselines3.__file__}")
print(f"TD3 class: {TD3}")
print("=" * 100)

from rip_env.register_envs import register_all_envs
from rip_env.envs.types import (
    EnvConfig,
    RIPPhysicalParams,
    InitStateConfig,
    LimitConfig,
    NoiseConfig,
    LoggingConfig,
)

from train.configs.td3_config import build_reward_fn, build_done_fn


# ============================================================
# 3. User config
# ============================================================

SEARCH_ROOTS = [
    PROJECT_ROOT / "train" / "experiments",
    PROJECT_ROOT / "experiments",
]

PREFER_FINAL_MODEL = False
HEADER_NAME = "td3_model_weights.h"
MACRO_PREFIX = "TD3"

ROLLOUT_TEST_STEPS = 10_000
ROLLOUT_TEST_SEED = 42
REWARD_CURVE_MOVAVG = 10

WRITE_INLINE_INFERENCE_FUNCTION = True


# ============================================================
# 4. Basic tools
# ============================================================

def ensure_dir(path: str | Path) -> None:
    os.makedirs(path, exist_ok=True)


def print_bar(msg: str) -> None:
    print("=" * 100)
    print(msg)
    print("=" * 100)


def safe_read_json(path: Path) -> Optional[dict]:
    if not path.is_file():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def to_c_float_str(x: float) -> str:
    x = float(x)
    if np.isnan(x) or np.isinf(x):
        raise ValueError(f"Invalid float value: {x}")
    return f"{x:.9g}f"


def write_comment_block(f, text: str) -> None:
    f.write("/*\n")
    for line in text.splitlines():
        f.write(f" * {line}\n")
    f.write(" */\n")


def write_float_1d(f, name: str, arr: np.ndarray) -> None:
    arr = np.asarray(arr, dtype=np.float32).reshape(-1)
    values = ", ".join(to_c_float_str(v) for v in arr)
    f.write(f"static const float {name}[{arr.size}] = {{{values}}};\n")


def write_float_2d(f, name: str, mat: np.ndarray) -> None:
    mat = np.asarray(mat, dtype=np.float32)
    rows, cols = mat.shape

    f.write(f"static const float {name}[{rows}][{cols}] = {{\n")
    for i in range(rows):
        row_values = ", ".join(to_c_float_str(v) for v in mat[i])
        comma = "," if i < rows - 1 else ""
        f.write(f"    {{{row_values}}}{comma}\n")
    f.write("};\n")


def wrap_text(x: Any, width: int = 70) -> str:
    s = str(x)
    if len(s) <= width:
        return s
    return "\n".join(textwrap.wrap(s, width=width))


# ============================================================
# 5. EnvConfig loading
# ============================================================

def dict_to_env_config(d: dict) -> EnvConfig:
    return EnvConfig(
        dt=d["dt"],
        max_steps=d["max_steps"],
        action_type=d["action_type"],
        discrete_actions=d["discrete_actions"],
        continuous_pwm_limit=d["continuous_pwm_limit"],
        observation_type=d["observation_type"],
        clip_velocity_in_obs=d["clip_velocity_in_obs"],
        physical_params=RIPPhysicalParams(**d["physical_params"]),
        init_state=InitStateConfig(**d["init_state"]),
        limits=LimitConfig(**d["limits"]),
        noise=NoiseConfig(**d["noise"]),
        logging=LoggingConfig(**d["logging"]),
    )


# ============================================================
# 6. TD3 actor extraction
# ============================================================

def extract_td3_actor_layers(model: TD3) -> Tuple[List[nn.Linear], str]:
    """
    SB3 TD3 actor usually has:

        model.actor.mu = Sequential(
            Linear, ReLU,
            Linear, ReLU,
            Linear, Tanh
        )

    导出时：
        hidden activation = ReLU
        output activation = Tanh
    """

    actor = model.actor

    if not hasattr(actor, "mu"):
        raise AttributeError("TD3 actor has no attribute 'mu'.")

    mu = actor.mu

    layers: List[nn.Linear] = []
    has_final_tanh = False

    for m in mu.modules():
        if isinstance(m, nn.Linear):
            layers.append(m)
        if isinstance(m, nn.Tanh):
            has_final_tanh = True

    if len(layers) == 0:
        raise RuntimeError("No Linear layers found in TD3 actor.mu.")

    output_activation = "Tanh" if has_final_tanh else "Clip"

    return layers, output_activation


# ============================================================
# 7. Find TD3 cases
# ============================================================

def is_td3_case_dir(case_dir: Path) -> bool:
    if not case_dir.is_dir():
        return False

    run_config = case_dir / "run_config.json"
    env_config = case_dir / "env_config_snapshot.json"

    if not run_config.is_file() or not env_config.is_file():
        return False

    try:
        rc = safe_read_json(run_config)
        if rc is not None:
            algo = str(rc.get("algorithm", "")).lower()
            exp_name = str(rc.get("experiment_name", case_dir.name)).lower()
            if "td3" not in algo and "td3" not in exp_name and "td3" not in case_dir.name.lower():
                return False
    except Exception:
        if "td3" not in case_dir.name.lower():
            return False

    best_model = case_dir / "best_model" / "best_model.zip"
    final_model = case_dir / "models" / "td3_rip_final.zip"

    if best_model.is_file() or final_model.is_file():
        return True

    model_dir = case_dir / "models"
    if model_dir.is_dir():
        for p in model_dir.glob("*.zip"):
            if "td3" in p.name.lower():
                return True

    return False


def find_all_td3_cases() -> List[Path]:
    cases: List[Path] = []
    seen = set()

    for root in SEARCH_ROOTS:
        if not root.is_dir():
            continue

        for child in root.iterdir():
            if not child.is_dir():
                continue

            if is_td3_case_dir(child):
                rp = str(child.resolve())
                if rp not in seen:
                    seen.add(rp)
                    cases.append(child)

    cases.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return cases


def choose_model_path(case_dir: Path) -> Path:
    final_model = case_dir / "models" / "td3_rip_final.zip"
    best_model = case_dir / "best_model" / "best_model.zip"

    if PREFER_FINAL_MODEL and final_model.is_file():
        return final_model

    if best_model.is_file():
        return best_model

    if final_model.is_file():
        return final_model

    model_dir = case_dir / "models"
    if model_dir.is_dir():
        zips = sorted(model_dir.glob("*.zip"), key=lambda p: p.stat().st_mtime)
        if len(zips) > 0:
            return zips[-1]

    raise FileNotFoundError(f"No TD3 model found in: {case_dir}")


# ============================================================
# 8. Header inference function
# ============================================================

def write_inline_inference_function(
    f,
    prefix: str,
    layer_dims: List[Tuple[int, int]],
    output_activation: str,
) -> None:
    max_dim = 0
    for in_dim, out_dim in layer_dims:
        max_dim = max(max_dim, in_dim, out_dim)

    f.write("\n")
    f.write("/* ============================================================\n")
    f.write(" * Inline TD3 Actor inference for STM32F446RE\n")
    f.write(" * actor: Linear -> ReLU -> Linear -> ReLU -> Linear -> Tanh\n")
    f.write(" * ============================================================ */\n")
    f.write("#include <math.h>\n\n")

    f.write(f"#define {prefix}_MAX_LAYER_DIM {max_dim}\n\n")

    f.write(f"static inline float {prefix}_clip_float(float x, float lo, float hi)\n")
    f.write("{\n")
    f.write("    if (x < lo) return lo;\n")
    f.write("    if (x > hi) return hi;\n")
    f.write("    return x;\n")
    f.write("}\n\n")

    f.write(f"static inline float {prefix}_relu(float x)\n")
    f.write("{\n")
    f.write("    return x > 0.0f ? x : 0.0f;\n")
    f.write("}\n\n")

    f.write(f"static inline void {prefix}_linear_forward(\n")
    f.write("    const float *input,\n")
    f.write("    float *output,\n")
    f.write("    int in_dim,\n")
    f.write("    int out_dim,\n")
    f.write("    const float *W,\n")
    f.write("    const float *B\n")
    f.write(")\n")
    f.write("{\n")
    f.write("    for (int i = 0; i < out_dim; ++i) {\n")
    f.write("        float acc = B[i];\n")
    f.write("        for (int j = 0; j < in_dim; ++j) {\n")
    f.write("            acc += W[i * in_dim + j] * input[j];\n")
    f.write("        }\n")
    f.write("        output[i] = acc;\n")
    f.write("    }\n")
    f.write("}\n\n")

    f.write(f"static inline float {prefix}_predict_action_norm(const float obs[{prefix}_OBS_DIM])\n")
    f.write("{\n")
    f.write(f"    float buf_a[{prefix}_MAX_LAYER_DIM];\n")
    f.write(f"    float buf_b[{prefix}_MAX_LAYER_DIM];\n\n")

    # layer 0
    f.write(
        f"    {prefix}_linear_forward(obs, buf_a, "
        f"{prefix}_L0_IN, {prefix}_L0_OUT, "
        f"&{prefix}_W0[0][0], {prefix}_B0);\n"
    )

    if len(layer_dims) > 1:
        f.write(f"    for (int i = 0; i < {prefix}_L0_OUT; ++i) buf_a[i] = {prefix}_relu(buf_a[i]);\n\n")

    for idx in range(1, len(layer_dims)):
        is_last = idx == len(layer_dims) - 1
        input_buf = "buf_a" if idx % 2 == 1 else "buf_b"
        output_buf = "buf_b" if idx % 2 == 1 else "buf_a"

        f.write(
            f"    {prefix}_linear_forward({input_buf}, {output_buf}, "
            f"{prefix}_L{idx}_IN, {prefix}_L{idx}_OUT, "
            f"&{prefix}_W{idx}[0][0], {prefix}_B{idx});\n"
        )

        if not is_last:
            f.write(
                f"    for (int i = 0; i < {prefix}_L{idx}_OUT; ++i) "
                f"{output_buf}[i] = {prefix}_relu({output_buf}[i]);\n\n"
            )

    final_buf = "buf_a" if (len(layer_dims) - 1) % 2 == 0 else "buf_b"

    f.write("\n")
    f.write(f"    float action = {final_buf}[0];\n")

    if output_activation.lower() == "tanh":
        f.write("    action = tanhf(action);\n")

    f.write(f"    action = {prefix}_clip_float(action, -1.0f, 1.0f);\n")
    f.write("    return action;\n")
    f.write("}\n\n")

    f.write(f"static inline float {prefix}_predict_pwm_float(const float obs[{prefix}_OBS_DIM])\n")
    f.write("{\n")
    f.write(f"    float action_norm = {prefix}_predict_action_norm(obs);\n")
    f.write(f"    return action_norm * {prefix}_CONTINUOUS_PWM_LIMIT;\n")
    f.write("}\n\n")

    f.write(f"static inline int16_t {prefix}_predict_pwm_int16(const float obs[{prefix}_OBS_DIM])\n")
    f.write("{\n")
    f.write(f"    float pwm_f = {prefix}_predict_pwm_float(obs);\n")
    f.write("    if (pwm_f >= 0.0f) {\n")
    f.write("        return (int16_t)(pwm_f + 0.5f);\n")
    f.write("    } else {\n")
    f.write("        return (int16_t)(pwm_f - 0.5f);\n")
    f.write("    }\n")
    f.write("}\n")


# ============================================================
# 9. Export actor
# ============================================================

def export_td3_actor_to_header(
    model_path: Path,
    output_header_path: Path,
    env_config_json: Optional[dict],
    macro_prefix: str = "TD3",
) -> Dict[str, Any]:

    if not model_path.is_file():
        raise FileNotFoundError(f"TD3 model zip not found: {model_path}")

    print(f"[INFO] Loading TD3 model: {model_path}")
    model = TD3.load(str(model_path), device="cpu")

    linear_layers, output_activation = extract_td3_actor_layers(model)

    obs_dim = int(model.observation_space.shape[0])
    act_dim = int(model.action_space.shape[0])

    if act_dim != 1:
        raise ValueError(f"This exporter supports 1D continuous action only, got act_dim={act_dim}")

    layer_dims: List[Tuple[int, int]] = []
    for layer in linear_layers:
        layer_dims.append((int(layer.in_features), int(layer.out_features)))

    continuous_pwm_limit = 150.0
    action_type = "unknown"
    observation_type = "unknown"

    if env_config_json is not None:
        continuous_pwm_limit = float(env_config_json.get("continuous_pwm_limit", 150.0))
        action_type = str(env_config_json.get("action_type", "unknown"))
        observation_type = str(env_config_json.get("observation_type", "unknown"))

    prefix = macro_prefix.strip().upper()
    guard = f"{prefix}_MODEL_WEIGHTS_H"

    ensure_dir(output_header_path.parent)

    with open(output_header_path, "w", encoding="utf-8") as f:
        f.write("#pragma once\n\n")
        f.write(f"#ifndef {guard}\n")
        f.write(f"#define {guard}\n\n")
        f.write("#include <stdint.h>\n\n")

        write_comment_block(
            f,
            "\n".join(
                [
                    "Auto-generated from local Stable-Baselines3 TD3 model.",
                    "Only TD3 Actor network is exported.",
                    "Critic networks are NOT exported.",
                    "",
                    f"Source model: {model_path.resolve()}",
                    f"Observation dim: {obs_dim}",
                    f"Action dim: {act_dim}",
                    f"Linear layer count: {len(linear_layers)}",
                    f"Hidden activation: ReLU",
                    f"Output activation: {output_activation}",
                    f"Action type: {action_type}",
                    f"Observation type: {observation_type}",
                    f"continuous_pwm_limit: {continuous_pwm_limit}",
                    "",
                    "STM32 inference:",
                    "  obs -> TD3 actor -> tanh/clip[-1,1] -> pwm = action * continuous_pwm_limit",
                    "",
                    "If observation_type='trig_hist1_act1', STM32 obs must be:",
                    "  [sin(theta), cos(theta), theta_dot, sin(alpha), cos(alpha), alpha_dot, last_action_norm]",
                    "where last_action_norm = previous_pwm / continuous_pwm_limit.",
                ]
            ),
        )

        f.write("\n")
        f.write(f"#define {prefix}_OBS_DIM {obs_dim}\n")
        f.write(f"#define {prefix}_STATE_DIM {obs_dim}\n")
        f.write(f"#define {prefix}_ACT_DIM {act_dim}\n")
        f.write(f"#define {prefix}_LINEAR_LAYER_COUNT {len(linear_layers)}\n")
        f.write(f"#define {prefix}_CONTINUOUS_PWM_LIMIT {to_c_float_str(continuous_pwm_limit)}\n\n")

        for idx, (in_dim, out_dim) in enumerate(layer_dims):
            f.write(f"#define {prefix}_L{idx}_IN {in_dim}\n")
            f.write(f"#define {prefix}_L{idx}_OUT {out_dim}\n")
        f.write("\n")

        for idx, layer in enumerate(linear_layers):
            W = layer.weight.detach().cpu().numpy().astype(np.float32)
            B = layer.bias.detach().cpu().numpy().astype(np.float32)

            write_float_2d(f, f"{prefix}_W{idx}", W)
            write_float_1d(f, f"{prefix}_B{idx}", B)
            f.write("\n")

        # Compatibility macros for your previous deploy style
        f.write("/* Compatibility aliases */\n")
        f.write(f"#define {prefix}_PI_H1 {prefix}_L0_OUT\n")
        f.write(f"#define {prefix}_PI_H2 {prefix}_L1_OUT\n")
        f.write(f"#define {prefix}_PI_W1 {prefix}_W0\n")
        f.write(f"#define {prefix}_PI_b1 {prefix}_B0\n")
        f.write(f"#define {prefix}_PI_W2 {prefix}_W1\n")
        f.write(f"#define {prefix}_PI_b2 {prefix}_B1\n")
        f.write(f"#define {prefix}_PI_W3 {prefix}_W2\n")
        f.write(f"#define {prefix}_PI_b3 {prefix}_B2\n\n")

        f.write("/*\n")
        f.write(" * Actor network structure:\n")
        for idx, (in_dim, out_dim) in enumerate(layer_dims):
            if idx < len(layer_dims) - 1:
                f.write(f" *   Layer {idx}: Linear {in_dim} -> {out_dim}, activation = ReLU\n")
            else:
                f.write(f" *   Layer {idx}: Linear {in_dim} -> {out_dim}, output activation = {output_activation}\n")
        f.write(" */\n")

        if WRITE_INLINE_INFERENCE_FUNCTION:
            write_inline_inference_function(
                f=f,
                prefix=prefix,
                layer_dims=layer_dims,
                output_activation=output_activation,
            )

        f.write(f"\n#endif  // {guard}\n")

    export_info = {
        "model_path": str(model_path),
        "output_header_path": str(output_header_path),
        "obs_dim": obs_dim,
        "act_dim": act_dim,
        "linear_layer_count": len(linear_layers),
        "layer_dims": layer_dims,
        "hidden_activation": "ReLU",
        "output_activation": output_activation,
        "continuous_pwm_limit": continuous_pwm_limit,
        "action_type": action_type,
        "observation_type": observation_type,
    }

    return export_info


# ============================================================
# 10. Reward curve
# ============================================================

def moving_average(x: np.ndarray, window: int) -> np.ndarray:
    if len(x) == 0:
        return x
    if window <= 1:
        return x.copy()

    y = np.zeros_like(x, dtype=np.float64)
    for i in range(len(x)):
        lo = max(0, i - window + 1)
        y[i] = np.mean(x[lo:i + 1])
    return y


def load_episode_log_csv(csv_path: Path) -> Optional[dict]:
    if not csv_path.is_file():
        return None

    episodes = []
    rewards = []
    lengths = []

    with open(csv_path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)

        for row in reader:
            try:
                episodes.append(int(row["episode"]))
                rewards.append(float(row["episode_reward"]))
                lengths.append(int(row["episode_length"]))
            except Exception:
                pass

    if len(rewards) == 0:
        return None

    episodes = np.asarray(episodes, dtype=np.int32)
    rewards = np.asarray(rewards, dtype=np.float64)
    lengths = np.asarray(lengths, dtype=np.int32)

    reward_per_step = rewards / np.maximum(lengths, 1)
    cum_steps = np.cumsum(lengths)

    return {
        "episode": episodes,
        "episode_reward": rewards,
        "episode_length": lengths,
        "reward_per_step": reward_per_step,
        "cum_steps": cum_steps,
    }


def plot_reward_curve(case_dir: Path, episode_log: Optional[dict]) -> Path:
    out_path = case_dir / "td3_reward_per_step_curve.png"

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.grid(True)

    if episode_log is None:
        ax.text(
            0.5,
            0.5,
            "No env_logs/episode_log.csv found",
            ha="center",
            va="center",
            fontsize=14,
        )
        ax.set_title("TD3 Reward Curve Unavailable")
    else:
        x = episode_log["cum_steps"]
        y = episode_log["reward_per_step"]
        y_ma = moving_average(y, REWARD_CURVE_MOVAVG)

        ax.plot(x, y, ".", alpha=0.6, label="episode reward / step")
        ax.plot(x, y_ma, "-", linewidth=2.0, label=f"moving avg {REWARD_CURVE_MOVAVG}")

        ax.set_xlabel("cumulative env steps")
        ax.set_ylabel("reward per step")
        ax.set_title("TD3 Training Reward Curve")
        ax.legend(loc="best")

    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)

    return out_path


# ============================================================
# 11. Rollout using training reward
# ============================================================

def build_rollout_env(env_config_json: dict) -> gym.Env:
    cfg = dict_to_env_config(env_config_json)

    cfg.max_steps = ROLLOUT_TEST_STEPS
    cfg.logging.enabled = False
    cfg.logging.save_step_log = False
    cfg.logging.flush_every_step = False

    env = gym.make(
        "CartPoleRIP-v0",
        env_config=cfg,
        reward_fn=build_reward_fn(),
        done_fn=build_done_fn(),
    )

    return env


def run_rollout_and_plot(
    case_dir: Path,
    model_path: Path,
    env_config_json: dict,
) -> Path:

    out_path = case_dir / "td3_rollout_10000_steps.png"

    register_all_envs()

    env = build_rollout_env(env_config_json)
    model = TD3.load(str(model_path), device="cpu")

    obs, info = env.reset(seed=ROLLOUT_TEST_SEED)

    theta_list = []
    theta_dot_list = []
    alpha_list = []
    alpha_dot_list = []
    action_list = []
    pwm_list = []
    reward_list = []
    done_list = []

    actual_steps = 0

    for _ in range(ROLLOUT_TEST_STEPS):
        action, _ = model.predict(obs, deterministic=True)
        action_norm = float(np.asarray(action, dtype=np.float32).reshape(-1)[0])

        obs, reward, terminated, truncated, info = env.step(action)

        state = info.get("state", None)
        if state is not None:
            theta_list.append(float(state[0]))
            theta_dot_list.append(float(state[1]))
            alpha_list.append(float(state[2]))
            alpha_dot_list.append(float(state[3]))
        else:
            theta_list.append(np.nan)
            theta_dot_list.append(np.nan)
            alpha_list.append(np.nan)
            alpha_dot_list.append(np.nan)

        pwm_list.append(float(info.get("pwm", np.nan)))
        action_list.append(action_norm)
        reward_list.append(float(reward))
        done_list.append(float(terminated or truncated))

        actual_steps += 1

        if terminated or truncated:
            break

    env.close()

    dt = float(env_config_json.get("dt", 0.005))
    t = np.arange(actual_steps, dtype=np.float64) * dt

    fig, axs = plt.subplots(7, 1, figsize=(12, 16), sharex=True)

    axs[0].plot(t, theta_list)
    axs[0].grid(True)
    axs[0].set_ylabel("theta / rad")
    axs[0].set_title(f"TD3 deterministic rollout using training reward, steps = {actual_steps}")

    axs[1].plot(t, alpha_list)
    axs[1].grid(True)
    axs[1].set_ylabel("alpha / rad")

    axs[2].plot(t, theta_dot_list, label="theta_dot")
    axs[2].plot(t, alpha_dot_list, label="alpha_dot")
    axs[2].grid(True)
    axs[2].set_ylabel("angular velocity")
    axs[2].legend(loc="best")

    axs[3].plot(t, action_list)
    axs[3].grid(True)
    axs[3].set_ylabel("action_norm")

    axs[4].plot(t, pwm_list)
    axs[4].grid(True)
    axs[4].set_ylabel("PWM")

    axs[5].plot(t, reward_list)
    axs[5].grid(True)
    axs[5].set_ylabel("training reward")

    axs[6].step(t, done_list, where="post")
    axs[6].grid(True)
    axs[6].set_ylabel("done")
    axs[6].set_xlabel("time / s")

    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)

    return out_path


# ============================================================
# 12. Summary table
# ============================================================

def build_network_string(layer_dims: List[Tuple[int, int]]) -> str:
    if len(layer_dims) == 0:
        return "N/A"

    parts = [str(layer_dims[0][0])]
    for _, out_dim in layer_dims:
        parts.append(str(out_dim))

    return " -> ".join(parts)


def plot_summary_table(
    case_dir: Path,
    run_cfg_json: Optional[dict],
    env_cfg_json: Optional[dict],
    export_info: Dict[str, Any],
    model_path: Path,
) -> Path:

    out_path = case_dir / "td3_training_summary_table.png"

    rows = []
    rows.append(("Experiment", case_dir.name))
    rows.append(("Model", str(model_path)))
    rows.append(("Header", str(case_dir / HEADER_NAME)))
    rows.append(("Obs dim", export_info["obs_dim"]))
    rows.append(("Act dim", export_info["act_dim"]))
    rows.append(("Actor structure", build_network_string(export_info["layer_dims"])))
    rows.append(("Hidden activation", export_info["hidden_activation"]))
    rows.append(("Output activation", export_info["output_activation"]))
    rows.append(("PWM limit", export_info["continuous_pwm_limit"]))
    rows.append(("Observation type", export_info["observation_type"]))
    rows.append(("Action type", export_info["action_type"]))
    rows.append(("Rollout reward", "train.configs.td3_config.build_reward_fn()"))
    rows.append(("Rollout done", "train.configs.td3_config.build_done_fn()"))

    if env_cfg_json is not None:
        for k in [
            "dt",
            "max_steps",
            "clip_velocity_in_obs",
        ]:
            rows.append((k, env_cfg_json.get(k, "N/A")))

    if run_cfg_json is not None:
        for k in [
            "algorithm",
            "total_timesteps",
            "seed",
            "buffer_size",
            "learning_starts",
            "batch_size",
            "actor_learning_rate",
            "critic_learning_rate",
            "gamma",
            "tau",
            "policy_delay",
            "target_policy_noise",
            "target_noise_clip",
            "action_noise_sigma",
            "net_arch_pi",
            "net_arch_qf",
            "activation_fn_name",
            "eval_freq",
            "n_eval_episodes",
        ]:
            if k in run_cfg_json:
                rows.append((k, run_cfg_json[k]))

    fig_h = max(8, 0.45 * len(rows))
    fig, ax = plt.subplots(figsize=(13, fig_h))
    ax.axis("off")

    cell_text = [[wrap_text(k, 30), wrap_text(v, 70)] for k, v in rows]

    table = ax.table(
        cellText=cell_text,
        colLabels=["Item", "Value"],
        cellLoc="left",
        colLoc="left",
        loc="center",
    )

    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.0, 1.5)

    ax.set_title("TD3 Export / Training / Environment Summary", fontsize=14, pad=20)

    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)

    return out_path


# ============================================================
# 13. Process one case
# ============================================================

def process_one_case(case_dir: Path) -> None:
    print_bar(f"[CASE] {case_dir}")

    run_cfg_path = case_dir / "run_config.json"
    env_cfg_path = case_dir / "env_config_snapshot.json"
    episode_log_path = case_dir / "env_logs" / "episode_log.csv"

    run_cfg_json = safe_read_json(run_cfg_path)
    env_cfg_json = safe_read_json(env_cfg_path)

    if env_cfg_json is None:
        print(f"[SKIP] Missing env_config_snapshot.json: {case_dir}")
        return

    model_path = choose_model_path(case_dir)
    header_path = case_dir / HEADER_NAME

    export_info = export_td3_actor_to_header(
        model_path=model_path,
        output_header_path=header_path,
        env_config_json=env_cfg_json,
        macro_prefix=MACRO_PREFIX,
    )

    episode_log = load_episode_log_csv(episode_log_path)
    reward_curve_path = plot_reward_curve(case_dir, episode_log)

    rollout_path = run_rollout_and_plot(
        case_dir=case_dir,
        model_path=model_path,
        env_config_json=env_cfg_json,
    )

    summary_table_path = plot_summary_table(
        case_dir=case_dir,
        run_cfg_json=run_cfg_json,
        env_cfg_json=env_cfg_json,
        export_info=export_info,
        model_path=model_path,
    )

    export_summary = {
        "case_dir": str(case_dir),
        "model_path": str(model_path),
        "header_path": str(header_path),
        "reward_curve_path": str(reward_curve_path),
        "rollout_path": str(rollout_path),
        "summary_table_path": str(summary_table_path),
        "rollout_uses_training_reward": True,
        "export_info": export_info,
    }

    export_summary_path = case_dir / "td3_export_summary.json"

    with open(export_summary_path, "w", encoding="utf-8") as f:
        json.dump(export_summary, f, ensure_ascii=False, indent=2, default=str)

    print("[DONE]")
    print(f"  td3_model_weights.h    : {header_path}")
    print(f"  td3_export_summary.json: {export_summary_path}")
    print(f"  reward curve           : {reward_curve_path}")
    print(f"  rollout 10000 steps    : {rollout_path}")
    print(f"  summary table          : {summary_table_path}")


# ============================================================
# 14. Main
# ============================================================

def main():
    print_bar("[START] Export TD3 Actor to STM32 header")

    register_all_envs()

    cases = find_all_td3_cases()

    if len(cases) == 0:
        print("[ERROR] No TD3 experiment case found.")
        print("Checked roots:")
        for root in SEARCH_ROOTS:
            print(f"  - {root}")
        return

    print(f"[INFO] Found {len(cases)} TD3 case(s):")
    for c in cases:
        print(f"  - {c}")

    ok = 0
    bad = 0

    for case_dir in cases:
        try:
            process_one_case(case_dir)
            ok += 1
        except Exception as e:
            bad += 1
            print_bar(f"[ERROR] Failed case: {case_dir}")
            print(f"{type(e).__name__}: {e}")

    print_bar("[FINISH]")
    print(f"success = {ok}")
    print(f"failed  = {bad}")


if __name__ == "__main__":
    main()