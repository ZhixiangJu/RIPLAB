#训练启动代码
#by Zhixiang Ju
#2026.4.22

import os
import sys
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# 项目根目录
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 本地 clone 下来的 gymnasium 仓库根目录
LOCAL_GYM_REPO = PROJECT_ROOT / "gymnasium"
if str(LOCAL_GYM_REPO) not in sys.path:
    sys.path.insert(0, str(LOCAL_GYM_REPO))

# 本地 clone 下来的 stable_baselines3 仓库根目录
LOCAL_SB3_REPO = PROJECT_ROOT / "stable_baselines3"
if str(LOCAL_SB3_REPO) not in sys.path:
    sys.path.insert(0, str(LOCAL_SB3_REPO))

import gymnasium as gym
from stable_baselines3 import DQN
from stable_baselines3.common.callbacks import EvalCallback, CheckpointCallback, CallbackList
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.monitor import Monitor

from rip_env.register_envs import register_all_envs
from train.configs.dqn_config import (
    DQNRunConfig,
    build_env_config,
    build_reward_fn,
    build_done_fn,
    build_dqn_kwargs,
)


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def dump_json(path: str, obj) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=str)


def make_env_fn(env_config, reward_fn, done_fn):
    def _init():
        env = gym.make(
            "CartPoleRIP-v0",
            env_config=env_config,
            reward_fn=reward_fn,
            done_fn=done_fn,
        )
        env = Monitor(env)
        return env
    return _init


def main():
    register_all_envs()

    run_cfg = DQNRunConfig()
    env_cfg = build_env_config(run_cfg)
    reward_fn = build_reward_fn()
    done_fn = build_done_fn()

    run_dir = run_cfg.run_dir()
    model_dir = run_cfg.model_dir()
    best_model_dir = run_cfg.best_model_dir()
    ensure_dir(run_dir)
    ensure_dir(model_dir)
    ensure_dir(best_model_dir)

    dump_json(os.path.join(run_dir, "run_config.json"), run_cfg.__dict__)
    dump_json(os.path.join(run_dir, "env_config_snapshot.json"), env_cfg.to_dict())

    train_env = make_vec_env(
        make_env_fn(env_cfg, reward_fn, done_fn),
        n_envs=run_cfg.n_envs,
        seed=run_cfg.seed,
    )

    import copy

    eval_env_cfg = copy.deepcopy(env_cfg)
    eval_env_cfg.logging.enabled = False
    eval_env_cfg.logging.save_step_log = False
    eval_env_cfg.logging.flush_every_step = False

    eval_env = gym.make(
    "CartPoleRIP-v0",
    env_config=eval_env_cfg,
    reward_fn=reward_fn,
    done_fn=done_fn,
      )
    eval_env = Monitor(eval_env)

    dqn_kwargs = build_dqn_kwargs(run_cfg)

    model = DQN(
        policy="MlpPolicy",
        env=train_env,
        **dqn_kwargs,
    )

    callbacks = []

    checkpoint_callback = CheckpointCallback(
        save_freq=max(1000 // max(run_cfg.n_envs, 1), 1),
        save_path=model_dir,
        name_prefix="dqn_rip_checkpoint",
        save_replay_buffer=run_cfg.save_replay_buffer,
        save_vecnormalize=False,
    )
    callbacks.append(checkpoint_callback)

    eval_callback = EvalCallback(
        eval_env=eval_env,
        best_model_save_path=best_model_dir if run_cfg.save_best_model else None,
        log_path=os.path.join(run_dir, "eval_logs"),
        eval_freq=max(run_cfg.eval_freq // max(run_cfg.n_envs, 1), 1),
        n_eval_episodes=run_cfg.n_eval_episodes,
        deterministic=True,
        render=False,
    )
    callbacks.append(eval_callback)

    callback = CallbackList(callbacks)

    model.learn(
        total_timesteps=run_cfg.total_timesteps,
        callback=callback,
        progress_bar=True,
    )

    final_model_path = os.path.join(model_dir, "dqn_rip_final")
    model.save(final_model_path)

    eval_env.close()
    train_env.close()

    print("=" * 80)
    print("DQN training finished.")
    print(f"Run dir       : {run_dir}")
    print(f"Final model   : {final_model_path}.zip")
    print(f"Best model dir: {best_model_dir}")
    print(f"use_lpf_velocity: {getattr(env_cfg, 'use_lpf_velocity', False)}")
    print(f"velocity_lpf    : {getattr(env_cfg, 'velocity_lpf', None)}")
    print("=" * 80)


if __name__ == "__main__":
    main()