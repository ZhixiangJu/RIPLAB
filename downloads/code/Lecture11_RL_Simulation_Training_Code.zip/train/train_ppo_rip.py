# train/train_ppo_v1.py
# PPO training script for rotary inverted pendulum
# Upright-only balance stage, continuous-action PPO version translated from ppo_no_swingup.m into the current Python/SB3 framework.
#
# Key:
#   physical env dt = 0.005 s, 200 Hz
#   PPO policy action_repeat = 1
#   effective policy frequency = 200 Hz
#   continuous normalized action, no swing-up
#
# by Zhixiang Ju

from __future__ import annotations

import os
import sys
import json
import csv
from pathlib import Path
from dataclasses import asdict
from typing import Dict

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ============================================================
# 1. Path injection
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

LOCAL_GYM_REPO = PROJECT_ROOT / "gymnasium"
LOCAL_SB3_REPO = PROJECT_ROOT / "stable_baselines3"

for p in [
    str(LOCAL_SB3_REPO),
    str(LOCAL_GYM_REPO),
    str(PROJECT_ROOT),
]:
    if p in sys.path:
        sys.path.remove(p)

sys.path.insert(0, str(LOCAL_SB3_REPO))
sys.path.insert(1, str(LOCAL_GYM_REPO))
sys.path.insert(2, str(PROJECT_ROOT))

print("=" * 100)
print("[PATH CHECK]")
print(f"PROJECT_ROOT      = {PROJECT_ROOT}")
print(f"LOCAL_GYM_REPO    = {LOCAL_GYM_REPO}")
print(f"LOCAL_SB3_REPO    = {LOCAL_SB3_REPO}")
print(f"Python executable = {sys.executable}")
print("=" * 100)


# ============================================================
# 2. Imports
# ============================================================

import gymnasium as gym

try:
    from stable_baselines3.ppo.ppo import PPO
except Exception:
    from stable_baselines3.ppo import PPO
from stable_baselines3.ppo.policies import MlpPolicy
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback, CallbackList
from stable_baselines3.common.monitor import Monitor

from rip_env.register_envs import register_all_envs

from train.configs.ppo_config_v1 import (
    PPORunConfig,
    build_env_config,
    build_reward_fn,
    build_done_fn,
    build_ppo_kwargs,
)


# ============================================================
# 3. Utilities
# ============================================================

def ensure_dir(path: str | Path) -> None:
    os.makedirs(path, exist_ok=True)


def dump_json(path: str | Path, obj) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=str)


def wrap_to_pi(x: float) -> float:
    while x > np.pi:
        x -= 2.0 * np.pi
    while x < -np.pi:
        x += 2.0 * np.pi
    return float(x)


# ============================================================
# 4. Action repeat wrapper
# ============================================================

class ActionRepeatWrapper(gym.Wrapper):
    """
    Apply the same action for several physical env steps.

    Example:
        physical dt = 0.005 s
        repeat = 4
        policy dt = 0.02 s
    """

    def __init__(self, env, repeat: int = 4):
        super().__init__(env)
        self.repeat = int(repeat)
        if self.repeat < 1:
            raise ValueError("repeat must be >= 1")

    def step(self, action):
        total_reward = 0.0

        final_obs = None
        final_info = {}
        terminated_final = False
        truncated_final = False
        inner_steps = 0

        for _ in range(self.repeat):
            obs, reward, terminated, truncated, info = self.env.step(action)

            total_reward += float(reward)
            final_obs = obs
            final_info = info
            inner_steps += 1

            if terminated or truncated:
                terminated_final = bool(terminated)
                truncated_final = bool(truncated)
                break

        final_info = dict(final_info)
        final_info["action_repeat"] = self.repeat
        final_info["inner_steps"] = inner_steps
        final_info["policy_reward_sum"] = total_reward

        return final_obs, total_reward, terminated_final, truncated_final, final_info


# ============================================================
# 5. Eval callback
# ============================================================

class PPOControlEvalCallback(BaseCallback):
    def __init__(
        self,
        eval_env,
        run_cfg: PPORunConfig,
        run_dir: str,
        best_model_dir: str,
        eval_freq: int,
        n_eval_episodes: int,
        max_eval_policy_steps: int,
        pwm_limit: float,
        verbose: int = 1,
    ):
        super().__init__(verbose)

        self.eval_env = eval_env
        self.run_cfg = run_cfg
        self.run_dir = run_dir
        self.best_model_dir = best_model_dir

        self.eval_freq = int(eval_freq)
        self.n_eval_episodes = int(n_eval_episodes)
        self.max_eval_policy_steps = int(max_eval_policy_steps)
        self.pwm_limit = float(pwm_limit)

        self.best_score = -1e18
        self.history = []

        ensure_dir(best_model_dir)
        ensure_dir(os.path.join(run_dir, "eval_logs"))

        self.csv_path = os.path.join(run_dir, "eval_logs", "ppo_eval_metrics.csv")

        with open(self.csv_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "timesteps",
                "mean_reward",
                "mean_policy_length",
                "mean_theta_abs",
                "mean_alpha_abs",
                "mean_alpha_dot_abs",
                "mean_pwm_abs_norm",
                "terminated_rate",
                "score",
            ])

    def _on_step(self) -> bool:
        if self.num_timesteps % self.eval_freq != 0:
            return True

        metrics = self.evaluate()
        self.history.append(metrics)

        with open(self.csv_path, "a", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                self.num_timesteps,
                metrics["mean_reward"],
                metrics["mean_policy_length"],
                metrics["mean_theta_abs"],
                metrics["mean_alpha_abs"],
                metrics["mean_alpha_dot_abs"],
                metrics["mean_pwm_abs_norm"],
                metrics["terminated_rate"],
                metrics["score"],
            ])

        if self.verbose:
            print(
                f"[PPO EVAL] steps={self.num_timesteps} | "
                f"reward={metrics['mean_reward']:.3f} | "
                f"len={metrics['mean_policy_length']:.1f} | "
                f"theta_abs={metrics['mean_theta_abs']:.3f} | "
                f"alpha_abs={metrics['mean_alpha_abs']:.3f} | "
                f"alpha_dot_abs={metrics['mean_alpha_dot_abs']:.3f} | "
                f"pwm_abs={metrics['mean_pwm_abs_norm']:.3f} | "
                f"terminated_rate={metrics['terminated_rate']:.2f} | "
                f"score={metrics['score']:.3f}"
            )

        if metrics["score"] > self.best_score:
            self.best_score = metrics["score"]
            best_path = os.path.join(self.best_model_dir, "best_model")
            self.model.save(best_path)
            print(f"[PPO BEST] saved: {best_path}.zip | score={self.best_score:.3f}")

        self.plot_history()

        return True

    def evaluate(self) -> Dict[str, float]:
        rewards = []
        lengths = []
        theta_abs_all = []
        alpha_abs_all = []
        alpha_dot_abs_all = []
        pwm_abs_all = []
        terminated_flags = []

        for ep in range(self.n_eval_episodes):
            obs, info = self.eval_env.reset(seed=self.run_cfg.seed + 1000 + ep)

            ep_reward = 0.0
            ep_len = 0

            theta_abs = []
            alpha_abs = []
            alpha_dot_abs = []
            pwm_abs = []

            terminated_early = False

            for _ in range(self.max_eval_policy_steps):
                action, _ = self.model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, info = self.eval_env.step(action)

                ep_reward += float(reward)
                ep_len += 1

                state = info.get("state", None)
                if state is not None:
                    theta_abs.append(abs(float(state[0])))
                    alpha_abs.append(abs(wrap_to_pi(float(state[2]))))
                    alpha_dot_abs.append(abs(float(state[3])))

                pwm = float(info.get("pwm", 0.0))
                pwm_abs.append(abs(pwm) / max(self.pwm_limit, 1e-6))

                if terminated:
                    terminated_early = True
                    break

                if truncated:
                    terminated_early = False
                    break

            rewards.append(ep_reward)
            lengths.append(ep_len)

            theta_abs_all.append(float(np.mean(theta_abs)) if len(theta_abs) > 0 else 999.0)
            alpha_abs_all.append(float(np.mean(alpha_abs)) if len(alpha_abs) > 0 else 999.0)
            alpha_dot_abs_all.append(float(np.mean(alpha_dot_abs)) if len(alpha_dot_abs) > 0 else 999.0)
            pwm_abs_all.append(float(np.mean(pwm_abs)) if len(pwm_abs) > 0 else 999.0)
            terminated_flags.append(1.0 if terminated_early else 0.0)

        mean_reward = float(np.mean(rewards))
        mean_length = float(np.mean(lengths))
        mean_theta_abs = float(np.mean(theta_abs_all))
        mean_alpha_abs = float(np.mean(alpha_abs_all))
        mean_alpha_dot_abs = float(np.mean(alpha_dot_abs_all))
        mean_pwm_abs_norm = float(np.mean(pwm_abs_all))
        terminated_rate = float(np.mean(terminated_flags))

        # Score now also penalizes alpha_dot to avoid windmill best model.
        score = (
            mean_reward
            + 0.05 * mean_length
            - 10.0 * mean_theta_abs
            - 24.0 * mean_alpha_abs
            - 2.0 * mean_alpha_dot_abs
            - 4.0 * mean_pwm_abs_norm
            - 40.0 * terminated_rate
        )

        return {
            "mean_reward": mean_reward,
            "mean_policy_length": mean_length,
            "mean_theta_abs": mean_theta_abs,
            "mean_alpha_abs": mean_alpha_abs,
            "mean_alpha_dot_abs": mean_alpha_dot_abs,
            "mean_pwm_abs_norm": mean_pwm_abs_norm,
            "terminated_rate": terminated_rate,
            "score": score,
        }

    def plot_history(self) -> None:
        if len(self.history) == 0:
            return

        x = np.arange(1, len(self.history) + 1) * self.eval_freq

        reward = np.array([m["mean_reward"] for m in self.history], dtype=np.float64)
        score = np.array([m["score"] for m in self.history], dtype=np.float64)
        alpha_abs = np.array([m["mean_alpha_abs"] for m in self.history], dtype=np.float64)
        theta_abs = np.array([m["mean_theta_abs"] for m in self.history], dtype=np.float64)
        alpha_dot_abs = np.array([m["mean_alpha_dot_abs"] for m in self.history], dtype=np.float64)
        terminated_rate = np.array([m["terminated_rate"] for m in self.history], dtype=np.float64)

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.grid(True)

        ax.plot(x, reward, label="mean_reward")
        ax.plot(x, score, label="control_score")
        ax.plot(x, alpha_abs, label="mean_alpha_abs")
        ax.plot(x, theta_abs, label="mean_theta_abs")
        ax.plot(x, alpha_dot_abs, label="mean_alpha_dot_abs")
        ax.plot(x, terminated_rate, label="terminated_rate")

        ax.set_xlabel("PPO policy timesteps")
        ax.set_title("PPO evaluation metrics")
        ax.legend(loc="best")

        fig.savefig(
            os.path.join(self.run_dir, "ppo_eval_curve.png"),
            dpi=180,
            bbox_inches="tight",
        )
        plt.close(fig)


# ============================================================
# 6. Rollout plot
# ============================================================

def rollout_and_plot(
    model_path: str,
    env_config,
    reward_fn,
    done_fn,
    out_path: str,
    action_repeat: int,
    seed: int = 42,
    rollout_policy_steps: int = 1000,
) -> None:
    env_config.logging.enabled = False
    env_config.logging.save_step_log = False
    env_config.logging.flush_every_step = False

    env = gym.make(
        "CartPoleRIP-v0",
        env_config=env_config,
        reward_fn=reward_fn,
        done_fn=done_fn,
    )

    env = ActionRepeatWrapper(env, repeat=action_repeat)

    model = PPO.load(model_path, device="cpu")

    obs, info = env.reset(seed=seed)

    theta_list = []
    theta_dot_list = []
    alpha_list = []
    alpha_dot_list = []
    action_list = []
    pwm_list = []
    reward_list = []
    done_list = []
    time_list = []

    policy_dt = float(env_config.dt) * int(action_repeat)

    for k in range(rollout_policy_steps):
        action, _ = model.predict(obs, deterministic=True)
        action_norm = float(np.asarray(action).reshape(-1)[0])

        obs, reward, terminated, truncated, info = env.step(action)

        state = info.get("state", None)
        if state is not None:
            theta_list.append(float(state[0]))
            theta_dot_list.append(float(state[1]))
            alpha_list.append(float(state[2]))
            alpha_dot_list.append(float(state[3]))
        else:
            theta_list.append(np.nan)
            theta_dot_list.append(np.nan)
            alpha_list.append(np.nan)
            alpha_dot_list.append(np.nan)

        action_list.append(action_norm)
        pwm_list.append(float(info.get("pwm", np.nan)))
        reward_list.append(float(reward))
        done_list.append(float(terminated or truncated))
        time_list.append(k * policy_dt)

        if terminated or truncated:
            break

    env.close()

    fig, axs = plt.subplots(7, 1, figsize=(12, 16), sharex=True)

    axs[0].plot(time_list, theta_list)
    axs[0].grid(True)
    axs[0].set_ylabel("theta / rad")
    axs[0].set_title(f"PPO deterministic rollout, policy steps={len(reward_list)}")

    axs[1].plot(time_list, alpha_list)
    axs[1].grid(True)
    axs[1].set_ylabel("alpha / rad")

    axs[2].plot(time_list, theta_dot_list, label="theta_dot")
    axs[2].plot(time_list, alpha_dot_list, label="alpha_dot")
    axs[2].grid(True)
    axs[2].legend(loc="best")
    axs[2].set_ylabel("angular velocity")

    axs[3].plot(time_list, action_list)
    axs[3].grid(True)
    axs[3].set_ylabel("action_norm")

    axs[4].plot(time_list, pwm_list)
    axs[4].grid(True)
    axs[4].set_ylabel("PWM")

    axs[5].plot(time_list, reward_list)
    axs[5].grid(True)
    axs[5].set_ylabel("reward")

    axs[6].step(time_list, done_list, where="post")
    axs[6].grid(True)
    axs[6].set_ylabel("done")
    axs[6].set_xlabel("time / s")

    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)

    print(f"[ROLLOUT] saved: {out_path}")


# ============================================================
# 7. Main
# ============================================================

def main():
    register_all_envs()

    run_cfg = PPORunConfig()
    run_cfg.root_log_dir = str(PROJECT_ROOT / "train" / "experiments")

    env_cfg = build_env_config(run_cfg)
    reward_fn = build_reward_fn()
    done_fn = build_done_fn()

    run_dir = run_cfg.run_dir()
    model_dir = run_cfg.model_dir()
    best_model_dir = run_cfg.best_model_dir()
    eval_log_dir = run_cfg.eval_log_dir()

    for p in [run_dir, model_dir, best_model_dir, eval_log_dir]:
        ensure_dir(p)

    dump_json(os.path.join(run_dir, "run_config.json"), run_cfg.__dict__)

    if hasattr(env_cfg, "to_dict"):
        dump_json(os.path.join(run_dir, "env_config_snapshot.json"), env_cfg.to_dict())
    else:
        dump_json(os.path.join(run_dir, "env_config_snapshot.json"), asdict(env_cfg))

    train_env = gym.make(
        "CartPoleRIP-v0",
        env_config=env_cfg,
        reward_fn=reward_fn,
        done_fn=done_fn,
    )

    train_env = ActionRepeatWrapper(train_env, repeat=run_cfg.action_repeat)
    train_env = Monitor(train_env)

    import copy

    eval_env_cfg = copy.deepcopy(env_cfg)
    eval_env_cfg.logging.enabled = False
    eval_env_cfg.logging.save_step_log = False
    eval_env_cfg.logging.flush_every_step = False

    eval_reward_fn = build_reward_fn()

    eval_env = gym.make(
        "CartPoleRIP-v0",
        env_config=eval_env_cfg,
        reward_fn=eval_reward_fn,
        done_fn=done_fn,
    )

    eval_env = ActionRepeatWrapper(eval_env, repeat=run_cfg.action_repeat)
    eval_env = Monitor(eval_env)

    ppo_kwargs = build_ppo_kwargs(run_cfg)

    max_eval_policy_steps = int(np.ceil(env_cfg.max_steps / run_cfg.action_repeat))

    print("=" * 100)
    print("[PPO V1 CONTINUOUS UPRIGHT-ONLY BALANCE TRAINING START]")
    print(f"run_dir                = {run_dir}")
    print(f"obs_space              = {train_env.observation_space}")
    print(f"action_space           = {train_env.action_space}")
    print(f"physical_dt            = {env_cfg.dt}")
    print(f"action_repeat          = {run_cfg.action_repeat}")
    print(f"policy_dt              = {env_cfg.dt * run_cfg.action_repeat}")
    print(f"physical_max_steps     = {env_cfg.max_steps}")
    print(f"policy_max_steps       = {max_eval_policy_steps}")
    print(f"total_timesteps        = {run_cfg.total_timesteps}")
    print(f"n_steps                = {run_cfg.n_steps}")
    print(f"batch_size             = {run_cfg.batch_size}")
    print(f"n_epochs               = {run_cfg.n_epochs}")
    print(f"learning_rate          = {run_cfg.learning_rate}")
    print(f"gamma                  = {run_cfg.gamma}")
    print(f"gae_lambda             = {run_cfg.gae_lambda}")
    print(f"clip_range             = {run_cfg.clip_range}")
    print(f"target_kl              = {run_cfg.target_kl}")
    print(f"ent_coef               = {run_cfg.ent_coef}")
    print(f"vf_coef                = {run_cfg.vf_coef}")
    print(f"max_grad_norm          = {run_cfg.max_grad_norm}")
    print(f"net_arch_pi            = {run_cfg.net_arch_pi}")
    print(f"net_arch_vf            = {run_cfg.net_arch_vf}")
    print(f"log_std_init           = {run_cfg.log_std_init}")
    print(f"pwm_limit              = {env_cfg.continuous_pwm_limit}")
    print("=" * 100)

    model = PPO(
        policy=MlpPolicy,
        env=train_env,
        **ppo_kwargs,
    )

    checkpoint_callback = CheckpointCallback(
        save_freq=max(run_cfg.checkpoint_freq, 1),
        save_path=model_dir,
        name_prefix="ppo_v1_continuous_checkpoint",
        save_replay_buffer=False,
        save_vecnormalize=False,
    )

    eval_callback = PPOControlEvalCallback(
        eval_env=eval_env,
        run_cfg=run_cfg,
        run_dir=run_dir,
        best_model_dir=best_model_dir,
        eval_freq=run_cfg.eval_freq,
        n_eval_episodes=run_cfg.n_eval_episodes,
        max_eval_policy_steps=max_eval_policy_steps,
        pwm_limit=env_cfg.continuous_pwm_limit,
        verbose=run_cfg.verbose,
    )

    callback = CallbackList([
        checkpoint_callback,
        eval_callback,
    ])

    model.learn(
        total_timesteps=run_cfg.total_timesteps,
        callback=callback,
        log_interval=10,
        progress_bar=True,
    )

    final_model_path = os.path.join(model_dir, "ppo_v1_final")
    model.save(final_model_path)

    print("=" * 100)
    print("[PPO V1 CONTINUOUS UPRIGHT-ONLY BALANCE TRAINING FINISHED]")
    print(f"Run dir     : {run_dir}")
    print(f"Final model : {final_model_path}.zip")
    print(f"Best model  : {os.path.join(best_model_dir, 'best_model.zip')}")
    print("=" * 100)

    best_zip = os.path.join(best_model_dir, "best_model.zip")
    if os.path.isfile(best_zip):
        rollout_model = best_zip
    else:
        rollout_model = final_model_path + ".zip"

    rollout_and_plot(
        model_path=rollout_model,
        env_config=copy.deepcopy(env_cfg),
        reward_fn=build_reward_fn(),
        done_fn=done_fn,
        out_path=os.path.join(run_dir, "ppo_v1_continuous_rollout_1000_policy_steps.png"),
        action_repeat=run_cfg.action_repeat,
        seed=run_cfg.seed,
        rollout_policy_steps=1000,
    )

    eval_env.close()
    train_env.close()


if __name__ == "__main__":
    main()