# train/train_td3_rip.py
# TD3 training script for rotary inverted pendulum
# Paper-aligned version:
#   separate actor/critic learning rates
#   gradient clipping = 1.0
#   no PPO import, no PPO call
#
# by Zhixiang Ju
# 2026.4.25

from __future__ import annotations

import os
import sys
import json
import csv
from pathlib import Path
from dataclasses import asdict
from typing import Dict

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ============================================================
# 1. Path injection
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

LOCAL_GYM_REPO = PROJECT_ROOT / "gymnasium"
LOCAL_SB3_REPO = PROJECT_ROOT / "stable_baselines3"

for p in [
    str(LOCAL_SB3_REPO),
    str(LOCAL_GYM_REPO),
    str(PROJECT_ROOT),
]:
    if p in sys.path:
        sys.path.remove(p)

sys.path.insert(0, str(LOCAL_SB3_REPO))
sys.path.insert(1, str(LOCAL_GYM_REPO))
sys.path.insert(2, str(PROJECT_ROOT))

print("=" * 100)
print("[PATH CHECK]")
print(f"PROJECT_ROOT      = {PROJECT_ROOT}")
print(f"LOCAL_GYM_REPO    = {LOCAL_GYM_REPO}")
print(f"LOCAL_SB3_REPO    = {LOCAL_SB3_REPO}")
print(f"Python executable = {sys.executable}")
print("=" * 100)


# ============================================================
# 2. Imports
# ============================================================

import gymnasium as gym
import torch as th
import torch.nn.functional as F
import torch.nn.utils as torch_utils

from stable_baselines3.td3.td3 import TD3
from stable_baselines3.td3.policies import TD3Policy
from stable_baselines3.common.noise import NormalActionNoise
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback, CallbackList
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.utils import polyak_update

from rip_env.register_envs import register_all_envs

from train.configs.td3_config_v2 import (
    TD3RunConfig,
    build_env_config,
    build_reward_fn,
    build_done_fn,
    build_td3_kwargs,
)


# ============================================================
# 3. Utilities
# ============================================================

def ensure_dir(path: str | Path) -> None:
    os.makedirs(path, exist_ok=True)


def dump_json(path: str | Path, obj) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=str)


# ============================================================
# 4. Paper-aligned TD3 class
# ============================================================

class TD3PaperAligned(TD3):
    """
    Local SB3 TD3 subclass.

    Changes compared with default TD3:
        1. actor optimizer lr = actor_learning_rate
        2. critic optimizer lr = critic_learning_rate
        3. critic gradient clipping = critic_grad_clip
        4. actor gradient clipping = actor_grad_clip
    """

    def __init__(
        self,
        *args,
        actor_learning_rate: float = 1e-4,
        critic_learning_rate: float = 1e-3,
        actor_grad_clip: float = 1.0,
        critic_grad_clip: float = 1.0,
        **kwargs,
    ):
        self.actor_learning_rate_custom = float(actor_learning_rate)
        self.critic_learning_rate_custom = float(critic_learning_rate)
        self.actor_grad_clip_custom = float(actor_grad_clip)
        self.critic_grad_clip_custom = float(critic_grad_clip)

        super().__init__(*args, **kwargs)

        self._set_separate_optimizer_lrs()

    def _set_separate_optimizer_lrs(self) -> None:
        for group in self.actor.optimizer.param_groups:
            group["lr"] = self.actor_learning_rate_custom

        for group in self.critic.optimizer.param_groups:
            group["lr"] = self.critic_learning_rate_custom

    def train(self, gradient_steps: int, batch_size: int = 100) -> None:
        # Switch to train mode
        self.policy.set_training_mode(True)

        actor_losses = []
        critic_losses = []

        for _ in range(gradient_steps):
            self._n_updates += 1

            replay_data = self.replay_buffer.sample(batch_size, env=self._vec_normalize_env)

            with th.no_grad():
                # Select action according to policy and add clipped noise
                noise = replay_data.actions.clone().data.normal_(0, self.target_policy_noise)
                noise = noise.clamp(-self.target_noise_clip, self.target_noise_clip)

                next_actions = (self.actor_target(replay_data.next_observations) + noise).clamp(-1, 1)

                # Compute the next Q-values: min over all critics targets
                next_q_values = th.cat(
                    self.critic_target(replay_data.next_observations, next_actions),
                    dim=1,
                )
                next_q_values, _ = th.min(next_q_values, dim=1, keepdim=True)

                target_q_values = replay_data.rewards + (1 - replay_data.dones) * self.gamma * next_q_values

            # Get current Q-values estimates for each critic network
            current_q_values = self.critic(replay_data.observations, replay_data.actions)

            # Compute critic loss
            critic_loss = sum(
                F.mse_loss(current_q, target_q_values) for current_q in current_q_values
            )
            critic_losses.append(float(critic_loss.item()))

            # Optimize the critics
            self.critic.optimizer.zero_grad()
            critic_loss.backward()
            torch_utils.clip_grad_norm_(self.critic.parameters(), self.critic_grad_clip_custom)
            self.critic.optimizer.step()

            # Delayed policy updates
            if self._n_updates % self.policy_delay == 0:
                actor_loss = -self.critic.q1_forward(
                    replay_data.observations,
                    self.actor(replay_data.observations),
                ).mean()
                actor_losses.append(float(actor_loss.item()))

                self.actor.optimizer.zero_grad()
                actor_loss.backward()
                torch_utils.clip_grad_norm_(self.actor.parameters(), self.actor_grad_clip_custom)
                self.actor.optimizer.step()

                polyak_update(self.critic.parameters(), self.critic_target.parameters(), self.tau)
                polyak_update(self.actor.parameters(), self.actor_target.parameters(), self.tau)

                # Update batch norm stats if present
                if hasattr(self, "critic_batch_norm_stats") and hasattr(self, "critic_batch_norm_stats_target"):
                    polyak_update(self.critic_batch_norm_stats, self.critic_batch_norm_stats_target, 1.0)

                if hasattr(self, "actor_batch_norm_stats") and hasattr(self, "actor_batch_norm_stats_target"):
                    polyak_update(self.actor_batch_norm_stats, self.actor_batch_norm_stats_target, 1.0)

        self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")

        if len(actor_losses) > 0:
            self.logger.record("train/actor_loss", np.mean(actor_losses))

        if len(critic_losses) > 0:
            self.logger.record("train/critic_loss", np.mean(critic_losses))

        # Keep custom learning rates fixed
        self._set_separate_optimizer_lrs()


# ============================================================
# 5. Custom eval callback
# ============================================================

class TD3ControlEvalCallback(BaseCallback):
    """
    Save best model using control-oriented score, not raw reward only.
    """

    def __init__(
        self,
        eval_env,
        run_cfg: TD3RunConfig,
        run_dir: str,
        best_model_dir: str,
        eval_freq: int,
        n_eval_episodes: int,
        max_eval_steps: int,
        pwm_limit: float,
        verbose: int = 1,
    ):
        super().__init__(verbose)

        self.eval_env = eval_env
        self.run_cfg = run_cfg
        self.run_dir = run_dir
        self.best_model_dir = best_model_dir

        self.eval_freq = int(eval_freq)
        self.n_eval_episodes = int(n_eval_episodes)

        self.max_eval_steps = int(max_eval_steps)
        self.pwm_limit = float(pwm_limit)

        self.best_score = -1e18
        self.history = []

        ensure_dir(best_model_dir)
        ensure_dir(os.path.join(run_dir, "eval_logs"))

        self.csv_path = os.path.join(run_dir, "eval_logs", "td3_eval_metrics.csv")
        with open(self.csv_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "timesteps",
                "mean_reward",
                "mean_length",
                "mean_theta_abs",
                "mean_alpha_abs",
                "mean_pwm_abs_norm",
                "done_rate",
                "score",
            ])

    def _on_step(self) -> bool:
        if self.num_timesteps % self.eval_freq != 0:
            return True

        metrics = self.evaluate()
        self.history.append(metrics)

        with open(self.csv_path, "a", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                self.num_timesteps,
                metrics["mean_reward"],
                metrics["mean_length"],
                metrics["mean_theta_abs"],
                metrics["mean_alpha_abs"],
                metrics["mean_pwm_abs_norm"],
                metrics["done_rate"],
                metrics["score"],
            ])

        if self.verbose:
            print(
                f"[TD3 EVAL] steps={self.num_timesteps} | "
                f"reward={metrics['mean_reward']:.3f} | "
                f"len={metrics['mean_length']:.1f} | "
                f"theta_abs={metrics['mean_theta_abs']:.3f} | "
                f"alpha_abs={metrics['mean_alpha_abs']:.3f} | "
                f"pwm_abs={metrics['mean_pwm_abs_norm']:.3f} | "
                f"done_rate={metrics['done_rate']:.2f} | "
                f"score={metrics['score']:.3f}"
            )

        if metrics["score"] > self.best_score:
            self.best_score = metrics["score"]
            best_path = os.path.join(self.best_model_dir, "best_model")
            self.model.save(best_path)
            print(f"[TD3 BEST] saved: {best_path}.zip | score={self.best_score:.3f}")

        self.plot_history()

        return True

    def evaluate(self) -> Dict[str, float]:
        rewards = []
        lengths = []
        theta_abs_all = []
        alpha_abs_all = []
        pwm_abs_all = []
        done_flags = []

        for ep in range(self.n_eval_episodes):
            obs, info = self.eval_env.reset(seed=self.run_cfg.seed + ep)

            ep_reward = 0.0
            ep_len = 0

            theta_abs = []
            alpha_abs = []
            pwm_abs = []

            ended_early = False

            for _ in range(self.max_eval_steps):
                action, _ = self.model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, info = self.eval_env.step(action)

                ep_reward += float(reward)
                ep_len += 1

                state = info.get("state", None)
                if state is not None:
                    theta_abs.append(abs(float(state[0])))
                    alpha_abs.append(abs(float(state[2])))

                pwm = float(info.get("pwm", 0.0))
                pwm_abs.append(abs(pwm) / max(self.pwm_limit, 1e-6))

                if terminated or truncated:
                    ended_early = True
                    break

            rewards.append(ep_reward)
            lengths.append(ep_len)

            theta_abs_all.append(float(np.mean(theta_abs)) if len(theta_abs) > 0 else 999.0)
            alpha_abs_all.append(float(np.mean(alpha_abs)) if len(alpha_abs) > 0 else 999.0)
            pwm_abs_all.append(float(np.mean(pwm_abs)) if len(pwm_abs) > 0 else 999.0)
            done_flags.append(1.0 if ended_early else 0.0)

        mean_reward = float(np.mean(rewards))
        mean_length = float(np.mean(lengths))
        mean_theta_abs = float(np.mean(theta_abs_all))
        mean_alpha_abs = float(np.mean(alpha_abs_all))
        mean_pwm_abs_norm = float(np.mean(pwm_abs_all))
        done_rate = float(np.mean(done_flags))

        score = (
            mean_reward
            + 0.02 * mean_length
            - 2.0 * mean_theta_abs
            - 12.0 * mean_alpha_abs
            - 2.0 * mean_pwm_abs_norm
            - 20.0 * done_rate
        )

        return {
            "mean_reward": mean_reward,
            "mean_length": mean_length,
            "mean_theta_abs": mean_theta_abs,
            "mean_alpha_abs": mean_alpha_abs,
            "mean_pwm_abs_norm": mean_pwm_abs_norm,
            "done_rate": done_rate,
            "score": score,
        }

    def plot_history(self) -> None:
        if len(self.history) == 0:
            return

        x = np.arange(len(self.history)) * self.eval_freq

        reward = np.array([m["mean_reward"] for m in self.history], dtype=np.float64)
        score = np.array([m["score"] for m in self.history], dtype=np.float64)
        alpha_abs = np.array([m["mean_alpha_abs"] for m in self.history], dtype=np.float64)
        theta_abs = np.array([m["mean_theta_abs"] for m in self.history], dtype=np.float64)
        done_rate = np.array([m["done_rate"] for m in self.history], dtype=np.float64)

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.grid(True)

        ax.plot(x, reward, label="mean_reward")
        ax.plot(x, score, label="control_score")
        ax.plot(x, alpha_abs, label="mean_alpha_abs")
        ax.plot(x, theta_abs, label="mean_theta_abs")
        ax.plot(x, done_rate, label="done_rate")

        ax.set_xlabel("timesteps")
        ax.set_title("TD3 evaluation metrics")
        ax.legend(loc="best")

        fig.savefig(
            os.path.join(self.run_dir, "td3_eval_curve.png"),
            dpi=180,
            bbox_inches="tight",
        )
        plt.close(fig)


# ============================================================
# 6. Rollout plot
# ============================================================

def rollout_and_plot(
    model_path: str,
    env_config,
    reward_fn,
    done_fn,
    out_path: str,
    seed: int = 42,
) -> None:
    env_config.logging.enabled = False
    env_config.logging.save_step_log = False
    env_config.logging.flush_every_step = False

    env = gym.make(
        "CartPoleRIP-v0",
        env_config=env_config,
        reward_fn=reward_fn,
        done_fn=done_fn,
    )

    model = TD3.load(model_path, device="cpu")

    obs, info = env.reset(seed=seed)

    theta_list = []
    theta_dot_list = []
    alpha_list = []
    alpha_dot_list = []
    action_list = []
    pwm_list = []
    reward_list = []
    done_list = []

    for _ in range(env_config.max_steps * 2):
        action, _ = model.predict(obs, deterministic=True)
        action_norm = float(np.asarray(action).reshape(-1)[0])

        obs, reward, terminated, truncated, info = env.step(action)

        state = info.get("state", None)
        if state is not None:
            theta_list.append(float(state[0]))
            theta_dot_list.append(float(state[1]))
            alpha_list.append(float(state[2]))
            alpha_dot_list.append(float(state[3]))
        else:
            theta_list.append(np.nan)
            theta_dot_list.append(np.nan)
            alpha_list.append(np.nan)
            alpha_dot_list.append(np.nan)

        action_list.append(action_norm)
        pwm_list.append(float(info.get("pwm", np.nan)))
        reward_list.append(float(reward))
        done_list.append(float(terminated or truncated))

        if terminated or truncated:
            break

    env.close()

    n = len(reward_list)
    t = np.arange(n) * float(env_config.dt)

    fig, axs = plt.subplots(7, 1, figsize=(12, 16), sharex=True)

    axs[0].plot(t, theta_list)
    axs[0].grid(True)
    axs[0].set_ylabel("theta / rad")
    axs[0].set_title(f"TD3 deterministic rollout, steps={n}")

    axs[1].plot(t, alpha_list)
    axs[1].grid(True)
    axs[1].set_ylabel("alpha / rad")

    axs[2].plot(t, theta_dot_list, label="theta_dot")
    axs[2].plot(t, alpha_dot_list, label="alpha_dot")
    axs[2].grid(True)
    axs[2].legend(loc="best")
    axs[2].set_ylabel("angular velocity")

    axs[3].plot(t, action_list)
    axs[3].grid(True)
    axs[3].set_ylabel("action_norm")

    axs[4].plot(t, pwm_list)
    axs[4].grid(True)
    axs[4].set_ylabel("PWM")

    axs[5].plot(t, reward_list)
    axs[5].grid(True)
    axs[5].set_ylabel("reward")

    axs[6].step(t, done_list, where="post")
    axs[6].grid(True)
    axs[6].set_ylabel("done")
    axs[6].set_xlabel("time / s")

    fig.tight_layout()
    fig.savefig(out_path, dpi=180, bbox_inches="tight")
    plt.close(fig)

    print(f"[ROLLOUT] saved: {out_path}")


# ============================================================
# 7. Main
# ============================================================

def main():
    register_all_envs()

    run_cfg = TD3RunConfig()
    run_cfg.root_log_dir = str(PROJECT_ROOT / "train" / "experiments")

    env_cfg = build_env_config(run_cfg)
    reward_fn = build_reward_fn()
    done_fn = build_done_fn()

    run_dir = run_cfg.run_dir()
    model_dir = run_cfg.model_dir()
    best_model_dir = run_cfg.best_model_dir()
    eval_log_dir = run_cfg.eval_log_dir()

    for p in [run_dir, model_dir, best_model_dir, eval_log_dir]:
        ensure_dir(p)

    dump_json(os.path.join(run_dir, "run_config.json"), run_cfg.__dict__)

    if hasattr(env_cfg, "to_dict"):
        dump_json(os.path.join(run_dir, "env_config_snapshot.json"), env_cfg.to_dict())
    else:
        dump_json(os.path.join(run_dir, "env_config_snapshot.json"), asdict(env_cfg))

    train_env = gym.make(
        "CartPoleRIP-v0",
        env_config=env_cfg,
        reward_fn=reward_fn,
        done_fn=done_fn,
    )
    train_env = Monitor(train_env)

    import copy
    eval_env_cfg = copy.deepcopy(env_cfg)
    eval_env_cfg.logging.enabled = False
    eval_env_cfg.logging.save_step_log = False
    eval_env_cfg.logging.flush_every_step = False

    eval_env = gym.make(
        "CartPoleRIP-v0",
        env_config=eval_env_cfg,
        reward_fn=build_reward_fn(),
        done_fn=done_fn,
    )
    eval_env = Monitor(eval_env)

    n_actions = int(train_env.action_space.shape[-1])
    action_noise = NormalActionNoise(
        mean=np.zeros(n_actions),
        sigma=run_cfg.action_noise_sigma * np.ones(n_actions),
    )

    td3_kwargs = build_td3_kwargs(run_cfg)

    print("=" * 100)
    print("[TD3 PAPER-ALIGNED TRAINING START]")
    print(f"run_dir          = {run_dir}")
    print(f"obs_space        = {train_env.observation_space}")
    print(f"action_space     = {train_env.action_space}")
    print(f"total_timesteps  = {run_cfg.total_timesteps}")
    print(f"buffer_size      = {run_cfg.buffer_size}")
    print(f"batch_size       = {run_cfg.batch_size}")
    print(f"net_arch_pi      = {run_cfg.net_arch_pi}")
    print(f"net_arch_qf      = {run_cfg.net_arch_qf}")
    print(f"actor_lr         = {run_cfg.actor_learning_rate}")
    print(f"critic_lr        = {run_cfg.critic_learning_rate}")
    print(f"actor_grad_clip  = {run_cfg.actor_grad_clip}")
    print(f"critic_grad_clip = {run_cfg.critic_grad_clip}")
    print(f"max_steps        = {env_cfg.max_steps}")
    print(f"pwm_limit        = {env_cfg.continuous_pwm_limit}")
    print("=" * 100)

    model = TD3PaperAligned(
        policy=TD3Policy,
        env=train_env,
        action_noise=action_noise,
        actor_learning_rate=run_cfg.actor_learning_rate,
        critic_learning_rate=run_cfg.critic_learning_rate,
        actor_grad_clip=run_cfg.actor_grad_clip,
        critic_grad_clip=run_cfg.critic_grad_clip,
        **td3_kwargs,
    )

    checkpoint_callback = CheckpointCallback(
        save_freq=max(run_cfg.checkpoint_freq, 1),
        save_path=model_dir,
        name_prefix="td3_rip_checkpoint",
        save_replay_buffer=False,
        save_vecnormalize=False,
    )

    eval_callback = TD3ControlEvalCallback(
        eval_env=eval_env,
        run_cfg=run_cfg,
        run_dir=run_dir,
        best_model_dir=best_model_dir,
        eval_freq=run_cfg.eval_freq,
        n_eval_episodes=run_cfg.n_eval_episodes,
        max_eval_steps=env_cfg.max_steps,
        pwm_limit=env_cfg.continuous_pwm_limit,
        verbose=run_cfg.verbose,
    )

    callback = CallbackList([checkpoint_callback, eval_callback])

    model.learn(
        total_timesteps=run_cfg.total_timesteps,
        callback=callback,
        log_interval=10,
        progress_bar=True,
    )

    final_model_path = os.path.join(model_dir, "td3_rip_final")
    model.save(final_model_path)

    print("=" * 100)
    print("[TD3 TRAINING FINISHED]")
    print(f"Run dir     : {run_dir}")
    print(f"Final model : {final_model_path}.zip")
    print(f"Best model  : {os.path.join(best_model_dir, 'best_model.zip')}")
    print("=" * 100)

    best_zip = os.path.join(best_model_dir, "best_model.zip")
    if os.path.isfile(best_zip):
        rollout_model = best_zip
    else:
        rollout_model = final_model_path + ".zip"

    rollout_and_plot(
        model_path=rollout_model,
        env_config=copy.deepcopy(env_cfg),
        reward_fn=build_reward_fn(),
        done_fn=done_fn,
        out_path=os.path.join(run_dir, "td3_rollout.png"),
        seed=run_cfg.seed,
    )

    eval_env.close()
    train_env.close()


if __name__ == "__main__":
    main()