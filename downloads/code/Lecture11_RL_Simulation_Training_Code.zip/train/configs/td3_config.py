# train/configs/td3_config.py
# TD3 config for rotary inverted pendulum
# Task: downward swing-up -> upright balance
#
# Paper-aligned TD3 setup:
#   obs = [sin(theta), cos(theta), theta_dot, sin(alpha), cos(alpha), alpha_dot, last_action_norm]
#   action = continuous normalized action in [-1, 1]
#   actor/critic = 64,64 ReLU
#   replay buffer = 1e6
#   batch size = 128
#   actor lr = 1e-4
#   critic lr = 1e-3
#   sample time = 0.005 s
#   episode length = 5 s
#
# by Zhixiang Ju
# 2026.4.25

from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any

import numpy as np
from torch import nn

from rip_env.envs.types import (
    EnvConfig,
    RIPPhysicalParams,
    InitStateConfig,
    LimitConfig,
    NoiseConfig,
    LoggingConfig,
)
from rip_env.envs.done_fns import build_done_fn as build_done_fn_from_dict


# ============================================================
# Utilities
# ============================================================

def now_str() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def get_activation_fn(name: str):
    table = {
        "ReLU": nn.ReLU,
        "Tanh": nn.Tanh,
        "ELU": nn.ELU,
        "LeakyReLU": nn.LeakyReLU,
    }

    if name not in table:
        raise ValueError(f"Unsupported activation function: {name}")

    return table[name]


# ============================================================
# TD3 run config
# ============================================================

@dataclass
class TD3RunConfig:
    experiment_name: str = field(default_factory=lambda: f"td3_paper_aligned_{now_str()}")
    root_log_dir: str = "./train/experiments"

    algorithm: str = "TD3"

    seed: int = 42

    # Paper scale:
    # 1000 episodes * 1000 steps = 1,000,000 steps
    total_timesteps: int = 1_000_000

    # Replay buffer
    buffer_size: int = 1_000_000
    learning_starts: int = 10_000
    batch_size: int = 128

    # Separate learning rates
    actor_learning_rate: float = 1e-4
    critic_learning_rate: float = 1e-3

    # TD3 core
    gamma: float = 0.99
    tau: float = 0.005

    train_freq: int = 1
    gradient_steps: int = 1

    policy_delay: int = 2
    target_policy_noise: float = 0.2
    target_noise_clip: float = 0.5

    # Gradient clipping
    actor_grad_clip: float = 1.0
    critic_grad_clip: float = 1.0

    # Exploration noise
    action_noise_sigma: float = 0.10

    # Network
    net_arch_pi: tuple = (64, 64)
    net_arch_qf: tuple = (64, 64)
    activation_fn_name: str = "ReLU"

    # Logging / eval
    eval_freq: int = 20_000
    n_eval_episodes: int = 5
    checkpoint_freq: int = 100_000
    save_best_model: bool = True
    verbose: int = 1

    def run_dir(self) -> str:
        return os.path.join(self.root_log_dir, self.experiment_name)

    def model_dir(self) -> str:
        return os.path.join(self.run_dir(), "models")

    def best_model_dir(self) -> str:
        return os.path.join(self.run_dir(), "best_model")

    def eval_log_dir(self) -> str:
        return os.path.join(self.run_dir(), "eval_logs")


# ============================================================
# Environment config
# ============================================================

def build_env_config(run_cfg: TD3RunConfig) -> EnvConfig:
    run_dir = run_cfg.run_dir()

    env_cfg = EnvConfig(
        # Paper sample time
        dt=0.005,

        # Paper episode length:
        # 5 s / 0.005 s = 1000 steps
        max_steps=1000,

        action_type="continuous",

        # TD3 不使用这个列表，仅保留 EnvConfig 兼容
        discrete_actions=[-150, -120, -90, -60, -30, 30, 60, 90, 120, 150],

        # 部署时仍然映射到 PWM ±150
        continuous_pwm_limit=150.0,

        # Paper observation:
        # [sin(theta), cos(theta), theta_dot, sin(alpha), cos(alpha), alpha_dot, last_action_norm]
        observation_type="trig_hist1_act1",
        clip_velocity_in_obs=True,

        physical_params=RIPPhysicalParams(),

        # Paper reset is uniform:
        # theta in [-pi/4, pi/4]
        # alpha around downward ±pi/4
        #
        # 当前 EnvConfig 是 mean/std 接口。
        # 这里使用 uniform 区间等效标准差：45 deg / sqrt(3)。
        # 如果后续你愿意改 env.reset，可以再严格实现 uniform reset。
        init_state=InitStateConfig(
            mode="downward",

            theta_mean_deg=0.0,
            theta_std_deg=float(45.0 / np.sqrt(3.0)),

            theta_dot_mean=0.0,
            theta_dot_std=0.0,

            alpha_mean_deg=180.0,
            alpha_std_deg=float(45.0 / np.sqrt(3.0)),

            alpha_dot_mean=0.0,
            alpha_dot_std=0.0,
        ),

        limits=LimitConfig(
            theta_limit=12.0 * np.pi,
            theta_dot_limit=45.0,
            alpha_dot_limit=40.0,

            # swing-up 任务不能因为 alpha 离竖直远而终止
            terminate_on_alpha_abs_deg=False,
            alpha_abs_limit_deg=45.0,
        ),

        noise=NoiseConfig(
            enabled=False,
            theta_sigma=0.0,
            alpha_sigma=0.0,
            theta_dot_sigma=0.0,
            alpha_dot_sigma=0.0,
        ),

        logging=LoggingConfig(
            enabled=True,
            log_dir=os.path.join(run_dir, "env_logs"),
            episode_csv_name="episode_log.csv",
            step_csv_name="step_log.csv",
            episode_jsonl_name="episode_log.jsonl",

            save_step_log=False,
            flush_every_step=False,
            write_config_json=True,
        ),
    )

    return env_cfg


# ============================================================
# Done function
# ============================================================

def build_done_fn():
    done_cfg = {
        "theta_limit": 12.0 * np.pi,
        "theta_dot_limit": 45.0,
        "alpha_dot_limit": 40.0,

        "terminate_on_alpha_abs_deg": False,
        "alpha_abs_limit_deg": 45.0,
    }

    return build_done_fn_from_dict(done_cfg)


# ============================================================
# Reward helper
# ============================================================

def _get_env_step_count(env) -> int:
    candidate_names = [
        "step_count",
        "current_step",
        "_step_count",
        "_current_step",
        "elapsed_steps",
        "_elapsed_steps",
        "t",
        "_t",
    ]

    for name in candidate_names:
        if hasattr(env, name):
            try:
                return int(getattr(env, name))
            except Exception:
                pass

    return 999999


def wrap_to_pi(x: float) -> float:
    while x > np.pi:
        x -= 2.0 * np.pi
    while x < -np.pi:
        x += 2.0 * np.pi
    return float(x)


# ============================================================
# Reward function
# ============================================================

def build_reward_fn():
    """
    TD3 paper-style reward:

        r = P_k - (
            A_THETA     * theta^2
          + A_ALPHA     * alpha^2
          + A_THETA_DOT * theta_dot^2
          + A_ALPHA_DOT * alpha_dot^2
          + A_U         * u^2
          + A_DU        * delta_u^2
        )

    User-specified weights:
        A_THETA     = 0.001
        A_ALPHA     = 8.0
        A_THETA_DOT = 0.001
        A_ALPHA_DOT = 0.005
        A_U         = 0.001
        A_DU        = 0.001
    """

    BASE_REWARD = 1.0

    A_THETA = 0.001
    A_ALPHA = 8.0
    A_THETA_DOT = 0.001
    A_ALPHA_DOT = 0.005
    A_U = 0.5
    A_DU = 0.0

    # P_k gate
    P_THETA_MAX = np.pi / 3.0
    P_THETA_DOT_MAX = 5.0
    P_ALPHA_MAX = np.deg2rad(12.0)
    P_ALPHA_DOT_MAX = 2.0

    def _reward_fn(state, action, next_state, env) -> float:
        theta, theta_dot, alpha, alpha_dot = next_state

        pwm = env._action_to_pwm(action)
        u = float(pwm / max(env.continuous_pwm_limit, 1e-6))
        u = float(np.clip(u, -1.0, 1.0))

        step_count = _get_env_step_count(env)

        # reset reward memory at episode start
        if (not hasattr(env, "td3_prev_u")) or step_count <= 1:
            env.td3_prev_u = 0.0

        u_prev = float(env.td3_prev_u)
        du = u - u_prev
        env.td3_prev_u = u

        alpha_wrap = wrap_to_pi(float(alpha))

        # P_k: only when roughly controlled near upright
        if (
            abs(theta) < P_THETA_MAX
            and abs(theta_dot) < P_THETA_DOT_MAX
            and abs(alpha_wrap) < P_ALPHA_MAX
            and abs(alpha_dot) < P_ALPHA_DOT_MAX
        ):
            p_k = BASE_REWARD
        else:
            p_k = 0.0

        cost = (
            A_THETA * (theta ** 2)
            + A_ALPHA * (alpha_wrap ** 2)
            + A_THETA_DOT * (theta_dot ** 2)
            + A_ALPHA_DOT * (alpha_dot ** 2)
            + A_U * (u ** 2)
            + A_DU * (du ** 2)
        )

        reward = p_k - cost

        return float(reward)

    return _reward_fn


# ============================================================
# TD3 kwargs
# ============================================================

def build_policy_kwargs(run_cfg: TD3RunConfig) -> Dict[str, Any]:
    return {
        "net_arch": {
            "pi": list(run_cfg.net_arch_pi),
            "qf": list(run_cfg.net_arch_qf),
        },
        "activation_fn": get_activation_fn(run_cfg.activation_fn_name),
    }


def build_td3_kwargs(run_cfg: TD3RunConfig) -> Dict[str, Any]:
    """
    注意：
    这里的 learning_rate 只是给 SB3 初始化用。
    真正的 actor_lr / critic_lr 会在 train_td3_rip.py 里的
    TD3PaperAligned 类中分别设置。
    """
    return {
        "learning_rate": run_cfg.actor_learning_rate,
        "buffer_size": run_cfg.buffer_size,
        "learning_starts": run_cfg.learning_starts,
        "batch_size": run_cfg.batch_size,
        "tau": run_cfg.tau,
        "gamma": run_cfg.gamma,
        "train_freq": (run_cfg.train_freq, "step"),
        "gradient_steps": run_cfg.gradient_steps,
        "policy_delay": run_cfg.policy_delay,
        "target_policy_noise": run_cfg.target_policy_noise,
        "target_noise_clip": run_cfg.target_noise_clip,
        "policy_kwargs": build_policy_kwargs(run_cfg),
        "verbose": run_cfg.verbose,
        "seed": run_cfg.seed,
    }