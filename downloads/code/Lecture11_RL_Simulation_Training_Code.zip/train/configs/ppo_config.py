# train/configs/ppo_config_v1.py
# PPO config for rotary inverted pendulum, upright-only balance stage, continuous-action version.
#
# This file rewrites the MATLAB script ppo_no_swingup.m into the current
# Python/SB3 training framework, but uses continuous PPO actions instead of the v2 discrete action table.
#
# Key alignment with the MATLAB code:
#   - no swing-up: initial state is near the upright equilibrium alpha=0
#   - physical dt = 0.005 s
#   - PPO acts every physical step: action_repeat = 1
#   - continuous normalized action in [-1, 1], mapped to PWM by continuous_pwm_limit
#   - observation: [sin(theta), cos(theta), theta_dot, sin(alpha), cos(alpha), alpha_dot]
#   - reward: 10*cos(alpha) - 0.001*alpha_dot^2 - 0.0001*theta_dot^2
#             - 5.0 * I(|alpha| > 15 deg)
#   - done: |alpha| > 45 deg, |theta_dot| > 45, |alpha_dot| > 40, |theta| > 12*pi
#
# by Zhixiang Ju

from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any

import numpy as np
from torch import nn

from rip_env.envs.types import (
    EnvConfig,
    RIPPhysicalParams,
    InitStateConfig,
    LimitConfig,
    NoiseConfig,
    LoggingConfig,
)
from rip_env.envs.done_fns import build_done_fn as build_done_fn_from_dict


# ============================================================
# Utilities
# ============================================================

def now_str() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def get_activation_fn(name: str):
    table = {
        "ReLU": nn.ReLU,
        "Tanh": nn.Tanh,
        "ELU": nn.ELU,
        "LeakyReLU": nn.LeakyReLU,
    }
    if name not in table:
        raise ValueError(f"Unsupported activation function: {name}")
    return table[name]


def wrap_to_pi(x: float) -> float:
    while x > np.pi:
        x -= 2.0 * np.pi
    while x < -np.pi:
        x += 2.0 * np.pi
    return float(x)


def _get_env_step_count(env) -> int:
    names = [
        "step_count", "current_step", "_step_count", "_current_step",
        "elapsed_steps", "_elapsed_steps", "t", "_t",
    ]
    for name in names:
        if hasattr(env, name):
            try:
                return int(getattr(env, name))
            except Exception:
                pass
    return 999999


# ============================================================
# PPO run config
# ============================================================

@dataclass
class PPORunConfig:
    experiment_name: str = field(default_factory=lambda: f"ppo_v1_continuous_upright_balance_{now_str()}")
    root_log_dir: str = "./train/experiments"

    algorithm: str = "PPO"
    seed: int = 42

    # ------------------------------------------------------------
    # Physical and policy time scale
    # ------------------------------------------------------------
    physical_dt: float = 0.005

    # MATLAB PPO acts every physical step.
    action_repeat: int = 1
    policy_dt: float = 0.005

    # MATLAB env.maxSteps = 6000.
    max_physical_steps: int = 6000

    # ------------------------------------------------------------
    # PPO training scale, aligned with MATLAB script
    # ------------------------------------------------------------
    total_timesteps: int = 2_000_000

    # MATLAB conf.horizon = 256.
    n_steps: int = 256

    # MATLAB minibatch = 64, update_epochs = 10.
    batch_size: int = 64
    n_epochs: int = 10

    # MATLAB actor LR = 3e-4, critic LR = 1e-3.
    # SB3 uses one optimizer for actor/critic, so use actor LR as default.
    learning_rate: float = 3e-4

    # MATLAB gamma = 0.95, lam = 0.95.
    gamma: float = 0.95
    gae_lambda: float = 0.95

    clip_range: float = 0.2
    target_kl: float | None = None

    # MATLAB entropy_coef = 0.002, max_grad_norm = 5.0.
    ent_coef: float = 0.002
    vf_coef: float = 0.5
    max_grad_norm: float = 5.0
    normalize_advantage: bool = True

    # ------------------------------------------------------------
    # Network: two hidden layers, H=64
    # ------------------------------------------------------------
    net_arch_pi: tuple = (64, 64)
    net_arch_vf: tuple = (64, 64)
    activation_fn_name: str = "Tanh"

    # Continuous PPO Gaussian policy initial log standard deviation.
    log_std_init: float = -0.35

    # ------------------------------------------------------------
    # Env/reward constants from MATLAB
    # ------------------------------------------------------------
    pwm_limit: float = 150.0
    # v1 is continuous action. The env maps normalized action [-1, 1]
    # to PWM by continuous_pwm_limit. Keep this empty for clarity.
    discrete_actions: tuple = ()

    init_theta_std_deg: float = 3.0
    init_alpha_std_deg: float = 5.0

    theta_limit: float = 12.0 * np.pi
    theta_dot_limit: float = 45.0
    alpha_dot_limit: float = 40.0
    alpha_abs_limit_deg: float = 45.0

    reward_k_cos: float = 10.0
    reward_k_alpha_dot: float = 0.001
    reward_k_theta_dot: float = 0.0001
    reward_angle_penalty_deg: float = 15.0
    reward_angle_penalty_value: float = 5.0

    # ------------------------------------------------------------
    # Logging / eval
    # ------------------------------------------------------------
    eval_freq: int = 20_000
    n_eval_episodes: int = 5
    checkpoint_freq: int = 20_000
    save_best_model: bool = True
    verbose: int = 1
    tensorboard_log: bool = False

    def run_dir(self) -> str:
        return os.path.join(self.root_log_dir, self.experiment_name)

    def model_dir(self) -> str:
        return os.path.join(self.run_dir(), "models")

    def best_model_dir(self) -> str:
        return os.path.join(self.run_dir(), "best_model")

    def eval_log_dir(self) -> str:
        return os.path.join(self.run_dir(), "eval_logs")

    def tensorboard_dir(self) -> str:
        return os.path.join(self.run_dir(), "tb")


# ============================================================
# Environment config
# ============================================================

def build_env_config(run_cfg: PPORunConfig) -> EnvConfig:
    run_dir = run_cfg.run_dir()

    env_cfg = EnvConfig(
        dt=run_cfg.physical_dt,
        max_steps=run_cfg.max_physical_steps,

        # v1: continuous-action PPO.
        # The policy outputs a normalized continuous action in [-1, 1],
        # and the environment scales it by continuous_pwm_limit.
        action_type="continuous",
        discrete_actions=list(run_cfg.discrete_actions),
        continuous_pwm_limit=float(run_cfg.pwm_limit),

        # MATLAB stateDim = 6:
        # [sin(theta), cos(theta), thetaDot, sin(alpha), cos(alpha), alphaDot]
        observation_type="trig",
        clip_velocity_in_obs=True,

        physical_params=RIPPhysicalParams(),

        # Upright-only initialization, no swing-up.
        # This uses the balance_random_small mode already supported by cartpole_rip.py:
        # uniform bounded perturbation around upright.
        init_state=InitStateConfig(
            mode="balance_random_small",
            theta_mean_deg=0.0,
            theta_std_deg=run_cfg.init_theta_std_deg,
            theta_dot_mean=0.0,
            theta_dot_std=0.0,
            alpha_mean_deg=0.0,
            alpha_std_deg=run_cfg.init_alpha_std_deg,
            alpha_dot_mean=0.0,
            alpha_dot_std=0.0,
        ),

        limits=LimitConfig(
            theta_limit=run_cfg.theta_limit,
            theta_dot_limit=run_cfg.theta_dot_limit,
            alpha_dot_limit=run_cfg.alpha_dot_limit,
            terminate_on_alpha_abs_deg=True,
            alpha_abs_limit_deg=run_cfg.alpha_abs_limit_deg,
        ),

        noise=NoiseConfig(
            enabled=False,
            theta_sigma=0.0,
            alpha_sigma=0.0,
            theta_dot_sigma=0.0,
            alpha_dot_sigma=0.0,
        ),

        logging=LoggingConfig(
            enabled=True,
            log_dir=os.path.join(run_dir, "env_logs"),
            episode_csv_name="episode_log.csv",
            step_csv_name="step_log.csv",
            episode_jsonl_name="episode_log.jsonl",
            save_step_log=False,
            flush_every_step=False,
            write_config_json=True,
        ),
    )

    return env_cfg


# ============================================================
# Done function
# ============================================================

def build_done_fn():
    done_cfg = {
        "theta_limit": 12.0 * np.pi,
        "theta_dot_limit": 45.0,
        "alpha_dot_limit": 40.0,
        "terminate_on_alpha_abs_deg": True,
        "alpha_abs_limit_deg": 45.0,
    }
    return build_done_fn_from_dict(done_cfg)


# ============================================================
# Reward function
# ============================================================

def build_reward_fn():
    """
    Upright-only balance reward, directly aligned with ppo_no_swingup.m:

        r = 10*cos(alpha)
            - 0.001*alpha_dot^2
            - 0.0001*theta_dot^2
            - 5.0 * I(|alpha| > 15 deg)

    MATLAB clips thetaDot and alphaDot before reward computation.  We keep the
    same behavior here.
    """

    K_COS = 10.0
    K_ALPHA_DOT = 0.001
    K_THETA_DOT = 0.0001
    ANG_PEN_DEG = 15.0
    ANG_PEN_VAL = 5.0
    THETA_DOT_LIM = 45.0
    ALPHA_DOT_LIM = 40.0

    def _reward_fn(state, action, next_state, env) -> float:
        _theta, theta_dot, alpha_raw, alpha_dot = next_state

        alpha = wrap_to_pi(float(alpha_raw))
        theta_dot = float(np.clip(float(theta_dot), -THETA_DOT_LIM, THETA_DOT_LIM))
        alpha_dot = float(np.clip(float(alpha_dot), -ALPHA_DOT_LIM, ALPHA_DOT_LIM))

        reward = (
            K_COS * float(np.cos(alpha))
            - K_ALPHA_DOT * (alpha_dot ** 2)
            - K_THETA_DOT * (theta_dot ** 2)
            - ANG_PEN_VAL * float(abs(alpha) > np.deg2rad(ANG_PEN_DEG))
        )

        return float(reward)

    return _reward_fn


# ============================================================
# PPO kwargs
# ============================================================

def build_policy_kwargs(run_cfg: PPORunConfig) -> Dict[str, Any]:
    return {
        "net_arch": {
            "pi": list(run_cfg.net_arch_pi),
            "vf": list(run_cfg.net_arch_vf),
        },
        "activation_fn": get_activation_fn(run_cfg.activation_fn_name),
        "log_std_init": run_cfg.log_std_init,
    }


def build_ppo_kwargs(run_cfg: PPORunConfig) -> Dict[str, Any]:
    kwargs = {
        "learning_rate": run_cfg.learning_rate,
        "n_steps": run_cfg.n_steps,
        "batch_size": run_cfg.batch_size,
        "n_epochs": run_cfg.n_epochs,
        "gamma": run_cfg.gamma,
        "gae_lambda": run_cfg.gae_lambda,
        "clip_range": run_cfg.clip_range,
        "ent_coef": run_cfg.ent_coef,
        "vf_coef": run_cfg.vf_coef,
        "max_grad_norm": run_cfg.max_grad_norm,
        "normalize_advantage": run_cfg.normalize_advantage,
        "policy_kwargs": build_policy_kwargs(run_cfg),
        "verbose": run_cfg.verbose,
        "seed": run_cfg.seed,
        "tensorboard_log": run_cfg.tensorboard_dir() if run_cfg.tensorboard_log else None,
    }

    if run_cfg.target_kl is not None:
        kwargs["target_kl"] = run_cfg.target_kl

    return kwargs
