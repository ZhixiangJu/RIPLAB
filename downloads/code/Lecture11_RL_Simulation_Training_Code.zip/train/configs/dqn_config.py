# train/configs/dqn_config.py

from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any

import numpy as np
from torch import nn

from rip_env.envs.types import (
    EnvConfig,
    RIPPhysicalParams,
    InitStateConfig,
    LimitConfig,
    NoiseConfig,
    LoggingConfig,
)
from rip_env.envs.reward_fns import build_weighted_reward_fn
from rip_env.envs.done_fns import build_done_fn as build_done_fn_from_dict


def now_str() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


@dataclass
class DQNRunConfig:
    experiment_name: str = field(default_factory=lambda: f"dqn_rip_{now_str()}")
    root_log_dir: str = "./experiments"

    total_timesteps: int = 5_000_000
    seed: int = 42
    n_envs: int = 1

    learning_rate: float = 1e-6
    buffer_size: int = 30_000
    learning_starts: int = 2_000
    batch_size: int = 512
    gamma: float = 0.95
    train_freq: int = 1
    gradient_steps: int = 1
    target_update_interval: int = 2000

    # 注意：
    # exploration_fraction 现在保留仅为兼容 SB3 原接口，
    # 实际 epsilon 更新已在 dqn.py 中改为指数衰减，不再使用线性 schedule。
    exploration_fraction: float = 0.25
    exploration_initial_eps: float = 1.0
    exploration_final_eps: float = 0.001
    exploration_decay: float = 400000.0

    net_arch: tuple = (64, 64)
    activation_fn_name: str = "ReLU"

    tensorboard_log: bool = False
    save_replay_buffer: bool = False

    eval_freq: int = 20_000
    n_eval_episodes: int = 5
    save_best_model: bool = True
    verbose: int = 1

    def run_dir(self) -> str:
        return os.path.join(self.root_log_dir, self.experiment_name)

    def tensorboard_dir(self) -> str:
        return os.path.join(self.run_dir(), "tb")

    def model_dir(self) -> str:
        return os.path.join(self.run_dir(), "models")

    def best_model_dir(self) -> str:
        return os.path.join(self.run_dir(), "best_model")


def get_activation_fn(name: str):
    table = {
        "ReLU": nn.ReLU,
        "Tanh": nn.Tanh,
        "ELU": nn.ELU,
        "LeakyReLU": nn.LeakyReLU,
    }
    if name not in table:
        raise ValueError(f"Unsupported activation function: {name}")
    return table[name]


def build_env_config(run_cfg: DQNRunConfig) -> EnvConfig:
    run_dir = run_cfg.run_dir()

    env_cfg = EnvConfig(
        dt=0.005,
        max_steps=2000,
        action_type="discrete",
        discrete_actions=[-150, -120, -90, -60, -30, 30, 60, 90, 120, 150],
        continuous_pwm_limit=150.0,
        observation_type="trig",
        clip_velocity_in_obs=True,
        physical_params=RIPPhysicalParams(
            g=9.81,
            R=4.29,
            l1=0.15189,
        ),
        init_state=InitStateConfig(
            mode="downward",
            theta_mean_deg=0.0,
            theta_std_deg=5.0,
            theta_dot_mean=0.0,
            theta_dot_std=0.0,
            alpha_mean_deg=180.0,
            alpha_std_deg=8.0,
            alpha_dot_mean=0.0,
            alpha_dot_std=0.0,
        ),
        limits=LimitConfig(
            theta_limit=12.0 * np.pi,
            theta_dot_limit=45.0,
            alpha_dot_limit=40.0,
            terminate_on_alpha_abs_deg=False,
            alpha_abs_limit_deg=90.0,
        ),
        noise=NoiseConfig(
            enabled=False,
            theta_sigma=0.0,
            alpha_sigma=0.0,
            theta_dot_sigma=0.0,
            alpha_dot_sigma=0.0,
        ),
        logging=LoggingConfig(
            enabled=True,
            log_dir=os.path.join(run_dir, "env_logs"),
            episode_csv_name="episode_log.csv",
            step_csv_name="step_log.csv",
            episode_jsonl_name="episode_log.jsonl",
            save_step_log=False,
            flush_every_step=False,
            write_config_json=True,
        ),
    )

    # Only DQN explicitly uses LPF velocity estimation to align with MATLAB.
    # TD3/PPO configs should keep the default False unless you intentionally enable it.
    env_cfg.use_lpf_velocity = True
    env_cfg.velocity_lpf = 0.25

    return env_cfg


def build_reward_fn():
    reward_cfg = {
        "k_cos_alpha": 10.0,
        "k_alpha_dot": 0.001,
        "k_theta_dot": 0.0001,
        "k_theta": 0.0,
        "alpha_penalty_deg": 15.0,
        "alpha_penalty_value": 5.0,
        "action_l2": 0.0,
    }
    return build_weighted_reward_fn(reward_cfg)


def build_done_fn():
    done_cfg = {
        "theta_limit": 12.0 * np.pi,
        "theta_dot_limit": 45.0,
        "alpha_dot_limit": 40.0,
        "terminate_on_alpha_abs_deg": False,
        "alpha_abs_limit_deg": 90.0,
    }
    return build_done_fn_from_dict(done_cfg)


def build_policy_kwargs(run_cfg: DQNRunConfig) -> Dict[str, Any]:
    return {
        "net_arch": list(run_cfg.net_arch),
        "activation_fn": get_activation_fn(run_cfg.activation_fn_name),
    }


def build_dqn_kwargs(run_cfg: DQNRunConfig) -> Dict[str, Any]:
    return {
        "learning_rate": run_cfg.learning_rate,
        "buffer_size": run_cfg.buffer_size,
        "learning_starts": run_cfg.learning_starts,
        "batch_size": run_cfg.batch_size,
        "gamma": run_cfg.gamma,
        "train_freq": run_cfg.train_freq,
        "gradient_steps": run_cfg.gradient_steps,
        "target_update_interval": run_cfg.target_update_interval,
        "exploration_fraction": run_cfg.exploration_fraction,
        "exploration_initial_eps": run_cfg.exploration_initial_eps,
        "exploration_final_eps": run_cfg.exploration_final_eps,
        "exploration_decay": run_cfg.exploration_decay,
        "verbose": run_cfg.verbose,
        "policy_kwargs": build_policy_kwargs(run_cfg),
        "tensorboard_log": run_cfg.tensorboard_dir() if run_cfg.tensorboard_log else None,
        "seed": run_cfg.seed,
    }