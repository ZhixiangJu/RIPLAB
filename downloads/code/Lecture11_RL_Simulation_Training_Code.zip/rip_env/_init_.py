# rip_env/__init__.py

from .register_envs import register_all_envs

__all__ = ["register_all_envs"]