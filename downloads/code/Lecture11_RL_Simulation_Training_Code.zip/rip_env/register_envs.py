# rip_env/register_envs.py

from gymnasium.envs.registration import register

_ALREADY_REGISTERED = False

def register_all_envs() -> None:
    global _ALREADY_REGISTERED
    if _ALREADY_REGISTERED:
        return

    register(
        id="CartPoleRIP-v0",
        entry_point="rip_env.envs.cartpole_rip:CartPoleRIPEenv",
    )

    _ALREADY_REGISTERED = True