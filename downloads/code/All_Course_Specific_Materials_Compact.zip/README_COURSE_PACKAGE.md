# AI-Enabled Control Engineering Compact Materials

This compact package contains course-specific slides, source files, images, and RIP lab code for Classes 6--12. Large vendored third-party library trees are excluded.
